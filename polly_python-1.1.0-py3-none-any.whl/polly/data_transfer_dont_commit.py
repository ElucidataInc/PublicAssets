import stat
import hashlib
import itertools
import math
import functools
from collections import defaultdict, deque
from concurrent.futures import ThreadPoolExecutor
from threading import Lock
import os
from os import PathLike
import pathlib
from typing import Optional, Union
from urllib.parse import (
    parse_qs,
    quote,
    unquote,
    urlencode,
    urlparse,
    urlunparse,
)
from tenacity import (
    retry,
    retry_if_not_result,
    stop_after_attempt,
    wait_exponential,
)
from urllib.request import pathname2url, url2pathname
from tqdm import tqdm
from boto3.s3.transfer import TransferConfig
from s3transfer.utils import (
    ChunksizeAdjuster,
    OSUtils,
)
from botocore.exceptions import (
    ClientError,
)

# TODO: Separate functions for copying files and copying directories
# copy_files should return physical key/uri
# copy directory should return list of physical keys/uris

s3_transfer_config = TransferConfig()

s3_client = None

MAX_COPY_FILE_LIST_RETRIES = 3
MAX_CONCURRENCY = 20

# When uploading files at least this size, compare the ETags first and skip the upload
# if they're equal; copy the remote file onto itself if the metadata changes.
UPLOAD_ETAG_OPTIMIZATION_THRESHOLD = 1024


def copy_file_list(file_list, message=None, callback=None):
    """
    Takes a list of tuples (src, dest, size) and copies them in parallel.
    URLs must be regular files, not directories.
    Returns versioned URLs for S3 destinations and regular file URLs for files.
    """
    for src, dest, _ in file_list:
        if src.looks_like_dir() or dest.looks_like_dir():
            raise ValueError("Directories are not allowed")

    return _copy_file_list_internal(
        file_list, [None] * len(file_list), message, callback
    )


def sanity_check_relative_path(rel_path):
    for part in rel_path.split("/"):
        if part in ("", ".", ".."):
            raise ValueError("Invalid relative path: %r" % rel_path)


def _copy_file_list_last_retry(retry_state):
    return retry_state.fn(
        *retry_state.args,
        **{**retry_state.kwargs, "exceptions_to_ignore": ()},
    )


def copy_file(
    source_path: str,
    dest_path: str,
    size: Optional[int] = None,
    message: Optional[str] = None,
    callback=None,
    disable_tqdm=False,
):
    """
    Copies a single file or directory to/from S3 (or from S3 to S3)

    source and destination paths can be file/directory URIs
    E.g. 's3://foo/bar', './myfile.txt'

    If src is a file, dest can be a file or a directory.
    If src is a directory, dest must be a directory.

    If a file with the same ETag is already present on S3 then
    it is not copied
    """
    src = PhysicalKey.from_pathlike(source_path)
    dest = PhysicalKey.from_pathlike(dest_path)

    def sanity_check(rel_path):
        for part in rel_path.split("/"):
            if part in ("", ".", ".."):
                raise ValueError("Invalid relative path: %r" % rel_path)

    url_list = []
    if src.looks_like_dir():
        if not dest.looks_like_dir():
            raise ValueError("Destination path must end in /")
        if size is not None:
            raise ValueError("`size` does not make sense for directories")

        for rel_path, size in list_url(src):
            sanity_check(rel_path)
            url_list.append((src.join(rel_path), dest.join(rel_path), size))
        if not url_list:
            raise Exception("No objects to download.")
    else:
        if dest.looks_like_dir():
            dest = dest.join(src.basename())
        if size is None:
            size, version_id = get_size_and_version(src)
            if src.version_id is None:
                src = PhysicalKey(src.bucket, src.path, version_id)
        url_list.append((src, dest, size))

    return _copy_file_list_internal(
        url_list, [None] * len(url_list), message, callback, disable_tqdm=disable_tqdm
    )


class URLParseError(ValueError):
    pass


def fix_url(url):
    """Convert non-URL paths to file:// URLs"""
    # If it has a scheme, we assume it's a URL.
    # On Windows, we ignore schemes that look like drive letters, e.g. C:/users/foo
    if not url:
        raise ValueError("Empty URL")

    url = str(url)

    parsed = urlparse(url)
    if parsed.scheme and not os.path.splitdrive(url)[0]:
        return url

    # `expanduser()` expands any leading "~" or "~user" path components, as a user convenience
    # `resolve()` _tries_ to make the URI absolute - but doesn't guarantee anything.
    # In particular, on Windows, non-existent files won't be resolved.
    # `absolute()` makes the URI absolute, though it can still contain '..'
    fixed_url = pathlib.Path(url).expanduser().resolve().absolute().as_uri()

    # pathlib likes to remove trailing slashes, so add it back if needed.
    if url[-1:] in (os.sep, os.altsep) and not fixed_url.endswith("/"):
        fixed_url += "/"

    return fixed_url


class PhysicalKey:
    __slots__ = ("bucket", "path", "version_id")

    def __init__(self, bucket: Optional[str], path: str, version_id: Optional[str]):
        """
        For internal use only; call from_path or from_url instead.
        """
        if bucket is not None and not isinstance(bucket, str):
            raise ValueError("Bucket must be None or a string")
        if not isinstance(path, str):
            raise ValueError("Path must be a string")
        if version_id is not None and not isinstance(version_id, str):
            raise ValueError("Version ID must be None or a string")

        if bucket is None:
            if path is None:
                raise ValueError("Local keys must have a path")
            if version_id is not None:
                raise ValueError("Local keys cannot have a version ID")
            if os.name == "nt":
                if "\\" in path:
                    raise ValueError("Paths must use / as a separator")
        else:
            if path.startswith("/"):
                raise ValueError("S3 paths must not start with '/'")

        self.bucket = bucket
        self.path = path
        self.version_id = version_id

    @classmethod
    def from_pathlike(cls, path: Union[str, PathLike]):
        return cls.from_url(fix_url(path))

    @classmethod
    def from_url(cls, url):
        parsed = urlparse(url)

        if parsed.scheme == "s3":
            if not parsed.netloc:
                raise URLParseError("Missing bucket")
            bucket = parsed.netloc
            assert not parsed.path or parsed.path.startswith("/")
            path = unquote(parsed.path)[1:]
            # Parse the version ID the way the Java SDK does:
            # https://github.com/aws/aws-sdk-java/blob/master/aws-java-sdk-s3/src/main/java/com/amazonaws/services/s3/AmazonS3URI.java#L192
            query = parse_qs(parsed.query)
            version_id = query.pop("versionId", [None])[0]
            if query:
                raise URLParseError(f"Unexpected S3 query string: {parsed.query!r}")
            return cls(bucket, path, version_id)
        elif parsed.scheme == "file":
            if parsed.netloc not in ("", "localhost"):
                raise URLParseError("Unexpected hostname")
            if not parsed.path:
                raise URLParseError("Missing path")
            if not parsed.path.startswith("/"):
                raise URLParseError("Relative paths are not allowed")
            if parsed.query:
                raise URLParseError("Unexpected query")
            path = url2pathname(parsed.path)
            if parsed.path.endswith("/") and not path.endswith(os.path.sep):
                # On Windows, url2pathname loses the trailing `/`.
                path += os.path.sep
            return cls.from_path(path)
        else:
            raise URLParseError(f"Unexpected scheme: {parsed.scheme!r}")

    @classmethod
    def from_path(cls, path):
        path = os.fspath(path)
        new_path = os.path.realpath(path)
        # Use '/' as the path separator.
        if os.path.sep != "/":
            new_path = new_path.replace(os.path.sep, "/")
        # Add back a trailing '/' if the original path has it.
        if path.endswith(os.path.sep) or (
            os.path.altsep is not None and path.endswith(os.path.altsep)
        ):
            new_path += "/"
        return cls(None, new_path, None)

    def is_local(self):
        return self.bucket is None

    def looks_like_dir(self):
        return self.basename() == ""

    def join(self, rel_path):
        if self.version_id is not None:
            raise ValueError("Cannot append paths to URLs with a version ID")

        if os.name == "nt" and "\\" in rel_path:
            raise ValueError("Paths must use / as a separator")

        if self.path:
            new_path = self.path.rstrip("/") + "/" + rel_path.lstrip("/")
        else:
            new_path = rel_path.lstrip("/")
        return PhysicalKey(self.bucket, new_path, None)

    def basename(self):
        return self.path.rsplit("/", 1)[-1]

    def __eq__(self, other):
        return (
            isinstance(other, self.__class__)
            and self.bucket == other.bucket
            and self.path == other.path
            and self.version_id == other.version_id
        )

    def __repr__(self):
        return (
            f"{self.__class__.__name__}({self.bucket!r}, {self.path!r},"
            f" {self.version_id!r})"
        )

    def __str__(self):
        if self.bucket is None:
            return urlunparse(
                (
                    "file",
                    "",
                    pathname2url(self.path.replace("/", os.path.sep)),
                    None,
                    None,
                    None,
                )
            )
        else:
            if self.version_id is None:
                params = {}
            else:
                params = {"versionId": self.version_id}
            return urlunparse(
                (
                    "s3",
                    self.bucket,
                    quote(self.path),
                    None,
                    urlencode(params),
                    None,
                )
            )


def read_file_chunks(file, chunksize=s3_transfer_config.io_chunksize):
    return itertools.takewhile(bool, map(file.read, itertools.repeat(chunksize)))


def _calculate_etag(file_path):
    """
    Attempts to calculate a local file's ETag the way S3 does:
    - Normal uploads: MD5 of the file
    - Multi-part uploads: MD5 of the (binary) MD5s of the parts, dash, number of parts
    We can't know how the file was actually uploaded - but we're assuming it was done using
    the default settings, which we get from `s3_transfer_config`.
    """
    size = pathlib.Path(file_path).stat().st_size
    with open(file_path, "rb") as fd:
        if size < s3_transfer_config.multipart_threshold:
            contents = fd.read()
            etag = hashlib.md5(contents).hexdigest()
        else:
            adjuster = ChunksizeAdjuster()
            chunksize = adjuster.adjust_chunksize(
                s3_transfer_config.multipart_chunksize, size
            )

            hashes = []
            for contents in read_file_chunks(fd, chunksize):
                hashes.append(hashlib.md5(contents).digest())
            etag = "%s-%d" % (hashlib.md5(b"".join(hashes)).hexdigest(), len(hashes))
    return '"%s"' % etag


class _WorkerContext:
    def __init__(self, progress, done, submit_task):
        self.progress = progress
        self.done = done
        self.submit_task = submit_task


def _s3_query_object(pk: PhysicalKey, *, head=False):
    params = dict(Bucket=pk.bucket, Key=pk.path)
    if pk.version_id is not None:
        params.update(VersionId=pk.version_id)
    return (s3_client.head_object if head else s3_client.get_object)(**params)


def get_size_and_version(src: PhysicalKey):
    """
    Gets size and version for the object at a given URL.

    Returns:
        size, version(str)
    """
    if src.looks_like_dir():
        raise Exception("Invalid path: %r; cannot be a directory" % src.path)

    version = None
    if src.is_local():
        src_file = pathlib.Path(src.path)
        if not src_file.is_file():
            raise Exception("Not a file: %r" % str(src_file))
        size = src_file.stat().st_size
    else:
        resp = _s3_query_object(src, head=True)
        size = resp["ContentLength"]
        version = resp.get("VersionId")
    return size, version


def list_url(src: PhysicalKey):
    if src.is_local():
        src_file = pathlib.Path(src.path)

        for f in src_file.rglob("*"):
            try:
                if f.is_file():
                    size = f.stat().st_size
                    yield f.relative_to(src_file).as_posix(), size
            except FileNotFoundError:
                # If a file does not exist, is it really a file?
                pass
    else:
        if src.version_id is not None:
            raise ValueError(f"Directories cannot have version IDs: {src}")
        src_path = src.path
        if not src.looks_like_dir():
            src_path += "/"
        list_obj_params = dict(Bucket=src.bucket, Prefix=src_path)
        paginator = s3_client.get_paginator("list_objects_v2")
        for response in paginator.paginate(**list_obj_params):
            for obj in response.get("Contents", []):
                key = obj["Key"]
                if not key.startswith(src_path):
                    raise ValueError("Unexpected key: %r" % key)
                yield key[len(src_path) :], obj["Size"]


def _upload_or_copy_file(ctx, size, src_path, dest_bucket, dest_path):
    # Optimization: check if the remote file already exists and has the right ETag,
    # and skip the upload.
    if size >= UPLOAD_ETAG_OPTIMIZATION_THRESHOLD:
        try:
            params = dict(Bucket=dest_bucket, Key=dest_path)
            resp = s3_client.head_object(**params)
        except ClientError:
            # Destination doesn't exist, so fall through to the normal upload.
            pass
        else:
            # Check the ETag.
            dest_size = resp["ContentLength"]
            dest_etag = resp["ETag"]
            dest_version_id = resp.get("VersionId")
            if size == dest_size and resp.get("ServerSideEncryption") != "aws:kms":
                src_etag = _calculate_etag(src_path)
                if src_etag == dest_etag:
                    # Nothing more to do. We should not attempt to copy the object because
                    # that would cause the "copy object to itself" error.
                    ctx.progress(size)
                    ctx.done(PhysicalKey(dest_bucket, dest_path, dest_version_id))
                    return  # Optimization succeeded.

    # If the optimization didn't happen, do the normal upload.
    _upload_file(ctx, size, src_path, dest_bucket, dest_path)


def _upload_file(ctx, size, src_path, dest_bucket, dest_key):
    if size < s3_transfer_config.multipart_threshold:
        with OSUtils().open_file_chunk_reader(src_path, 0, size, [ctx.progress]) as fd:
            resp = s3_client.put_object(
                Body=fd,
                Bucket=dest_bucket,
                Key=dest_key,
            )

        version_id = resp.get("VersionId")  # Absent in unversioned buckets.
        ctx.done(PhysicalKey(dest_bucket, dest_key, version_id))
    else:
        resp = s3_client.create_multipart_upload(
            Bucket=dest_bucket,
            Key=dest_key,
        )
        upload_id = resp["UploadId"]

        adjuster = ChunksizeAdjuster()
        chunksize = adjuster.adjust_chunksize(
            s3_transfer_config.multipart_chunksize, size
        )

        chunk_offsets = list(range(0, size, chunksize))

        lock = Lock()
        remaining = len(chunk_offsets)
        parts = [None] * remaining

        def upload_part(i, start, end):
            nonlocal remaining
            part_id = i + 1
            with OSUtils().open_file_chunk_reader(
                src_path, start, end - start, [ctx.progress]
            ) as fd:
                part = s3_client.upload_part(
                    Body=fd,
                    Bucket=dest_bucket,
                    Key=dest_key,
                    UploadId=upload_id,
                    PartNumber=part_id,
                )
            with lock:
                ctx.progress(end - start)
                parts[i] = {"PartNumber": part_id, "ETag": part["ETag"]}
                remaining -= 1
                done = remaining == 0

            if done:
                resp = s3_client.complete_multipart_upload(
                    Bucket=dest_bucket,
                    Key=dest_key,
                    UploadId=upload_id,
                    MultipartUpload={"Parts": parts},
                )
                version_id = resp.get("VersionId")  # Absent in unversioned buckets.
                ctx.done(PhysicalKey(dest_bucket, dest_key, version_id))

        for i, start in enumerate(chunk_offsets):
            end = min(start + chunksize, size)
            ctx.submit_task(upload_part, i, start, end)


def _copy_remote_file(
    ctx, size, src_bucket, src_key, src_version, dest_bucket, dest_key, extra_args=None
):
    src_params = dict(Bucket=src_bucket, Key=src_key)
    if src_version is not None:
        src_params.update(VersionId=src_version)

    if size < s3_transfer_config.multipart_threshold:
        params = dict(
            CopySource=src_params,
            Bucket=dest_bucket,
            Key=dest_key,
        )

        if extra_args:
            params.update(extra_args)

        resp = s3_client.copy_object(**params)
        ctx.progress(size)
        version_id = resp.get("VersionId")  # Absent in unversioned buckets.
        ctx.done(PhysicalKey(dest_bucket, dest_key, version_id))
    else:
        resp = s3_client.create_multipart_upload(
            Bucket=dest_bucket,
            Key=dest_key,
        )
        upload_id = resp["UploadId"]

        adjuster = ChunksizeAdjuster()
        chunksize = adjuster.adjust_chunksize(
            s3_transfer_config.multipart_chunksize, size
        )

        chunk_offsets = list(range(0, size, chunksize))

        lock = Lock()
        remaining = len(chunk_offsets)
        parts = [None] * remaining

        def upload_part(i, start, end):
            nonlocal remaining
            part_id = i + 1
            part = s3_client.upload_part_copy(
                CopySource=src_params,
                CopySourceRange=f"bytes={start}-{end-1}",
                Bucket=dest_bucket,
                Key=dest_key,
                UploadId=upload_id,
                PartNumber=part_id,
            )
            with lock:
                parts[i] = {
                    "PartNumber": part_id,
                    "ETag": part["CopyPartResult"]["ETag"],
                }
                remaining -= 1
                done = remaining == 0

            ctx.progress(end - start)

            if done:
                resp = s3_client.complete_multipart_upload(
                    Bucket=dest_bucket,
                    Key=dest_key,
                    UploadId=upload_id,
                    MultipartUpload={"Parts": parts},
                )
                version_id = resp.get("VersionId")  # Absent in unversioned buckets.
                ctx.done(PhysicalKey(dest_bucket, dest_key, version_id))

        for i, start in enumerate(chunk_offsets):
            end = min(start + chunksize, size)
            ctx.submit_task(upload_part, i, start, end)


def _download_file(ctx, size, src_bucket, src_key, src_version, dest_path):
    dest_file = pathlib.Path(dest_path)
    if dest_file.is_reserved():
        raise ValueError("Cannot download to %r: reserved file name" % dest_path)

    params = dict(Bucket=src_bucket, Key=src_key)

    dest_file.parent.mkdir(parents=True, exist_ok=True)

    with dest_file.open("wb") as f:
        fileno = f.fileno()
        is_regular_file = stat.S_ISREG(os.stat(fileno).st_mode)

    if src_version is not None:
        params.update(VersionId=src_version)

    part_size = s3_transfer_config.multipart_chunksize
    is_multi_part = (
        is_regular_file
        and size >= s3_transfer_config.multipart_threshold
        and size > part_size
    )
    part_numbers = range(math.ceil(size / part_size)) if is_multi_part else (None,)
    remaining_counter = len(part_numbers)
    remaining_counter_lock = Lock()

    def download_part(part_number):
        nonlocal remaining_counter

        with dest_file.open("r+b") as chunk_f:
            if part_number is not None:
                start = part_number * part_size
                end = min(start + part_size, size) - 1
                part_params = dict(params, Range=f"bytes={start}-{end}")
                chunk_f.seek(start)
            else:
                part_params = params

            resp = s3_client.get_object(**part_params)
            body = resp["Body"]
            while True:
                chunk = body.read(s3_transfer_config.io_chunksize)
                if not chunk:
                    break
                ctx.progress(chunk_f.write(chunk))

        with remaining_counter_lock:
            remaining_counter -= 1
            done = remaining_counter == 0
        if done:
            ctx.done(PhysicalKey.from_path(dest_path))

    for part_number in part_numbers:
        ctx.submit_task(download_part, part_number)


@retry(
    stop=stop_after_attempt(MAX_COPY_FILE_LIST_RETRIES - 1),
    wait=wait_exponential(multiplier=1, min=1, max=10),
    retry=retry_if_not_result(all),
    retry_error_callback=_copy_file_list_last_retry,
)
def _copy_file_list_internal(
    file_list,
    results,
    message,
    callback,
    exceptions_to_ignore=(ClientError,),
    disable_tqdm=False,
):
    """
    Takes a list of tuples (src, dest, size) and copies the data in parallel.
    `results` is the list where results will be stored.
    Returns versioned URLs for S3 destinations and regular file URLs for files.
    """
    if not file_list:
        return []

    print("copy files: started")

    assert len(file_list) == len(results)

    total_size = sum(
        size for (_, _, size), result in zip(file_list, results) if result is None
    )

    lock = Lock()
    futures = deque()
    future_to_idx = {}
    idx_to_futures = defaultdict(list)

    stopped = False

    with tqdm(
        desc=message, total=total_size, unit="B", unit_scale=True, disable=disable_tqdm
    ) as progress, ThreadPoolExecutor(MAX_CONCURRENCY) as executor:

        def progress_callback(bytes_transferred):
            if stopped:
                raise Exception("Interrupted")
            with lock:
                progress.update(bytes_transferred)

        def run_task(idx, func, *args):
            future = executor.submit(func, *args)
            with lock:
                futures.append(future)
                future_to_idx[future] = idx
                idx_to_futures[idx].append(future)

        def worker(idx, src, dest, size):
            if stopped:
                raise Exception("Interrupted")

            def done_callback(value):
                assert value is not None
                with lock:
                    assert results[idx] is None
                    results[idx] = value
                if callback is not None:
                    callback(src, dest, size)

            ctx = _WorkerContext(
                progress=progress_callback,
                done=done_callback,
                submit_task=functools.partial(run_task, idx),
            )

            if dest.version_id:
                raise ValueError("Cannot set VersionId on destination")

            if src.is_local():
                if dest.is_local():
                    raise NotImplementedError(
                        "Cannot copy from one local path to another"
                    )
                else:
                    if dest.version_id:
                        raise ValueError("Cannot set VersionId on destination")
                    _upload_or_copy_file(ctx, size, src.path, dest.bucket, dest.path)
            else:
                if dest.is_local():
                    _download_file(
                        ctx, size, src.bucket, src.path, src.version_id, dest.path
                    )
                else:
                    _copy_remote_file(
                        ctx,
                        size,
                        src.bucket,
                        src.path,
                        src.version_id,
                        dest.bucket,
                        dest.path,
                    )

        try:
            for idx, (args, result) in enumerate(zip(file_list, results)):
                if result is not None:
                    continue
                run_task(idx, worker, idx, *args)

            # ThreadPoolExecutor does not appear to have a way to just wait for everything to complete.
            # Shutting it down will cause it to wait - but will prevent any new tasks from starting.
            # So, manually wait for all tasks to complete.
            # This will also raise any exception that happened in a worker thread.
            while True:
                with lock:
                    if not futures:
                        break
                    future = futures.popleft()
                if future.cancelled():
                    continue
                try:
                    future.result()
                except exceptions_to_ignore:
                    with lock:
                        idx = future_to_idx[future]
                        futures_to_cancel = idx_to_futures[idx]
                        for f in futures_to_cancel:
                            f.cancel()
                        futures_to_cancel.clear()
        finally:
            # Make sure all tasks exit quickly if the main thread exits before they're done.
            stopped = True

    print("copy files: finished")

    return results
