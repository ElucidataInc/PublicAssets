import sys

sys.tracebacklimit = 0


class ElasticException(Exception):
    def __str__(self):
        return f"{self.error.get('reason')}: {self.error.get('details')}"


class UnauthorizedException(Exception):
    def __str__(self):
        return "Expired or Invalid Token"


class PayloadTooLargeError(Exception):
    def __str__(self):
        return "Payload Too Large"


def error_handler(response):
    if response.status_code == 400 and "error" in response.json():
        error = response.json().get("error")
        custom_error = type(
            error.get("type"),  # Name of the Class
            (ElasticException,),  # Inherit the __str__ from this class
            {"error": error},  # Pass the error as attribute
        )
        raise custom_error
    elif response.status_code == 401:
        raise UnauthorizedException

    response.raise_for_status()
