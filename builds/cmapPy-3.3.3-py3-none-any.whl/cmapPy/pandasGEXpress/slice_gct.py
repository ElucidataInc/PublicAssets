msg = "slice_gct.py is deprecated. Please use subset.py instead."
raise(DeprecationWarning(msg))