msg = "concat_gctoo.py is deprecated. Please use concat.py instead."
raise(DeprecationWarning(msg))