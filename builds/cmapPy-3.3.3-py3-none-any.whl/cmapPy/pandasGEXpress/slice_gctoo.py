msg = "slice_gctoo.py is deprecated. Please use subset_gctoo.py instead."
raise(DeprecationWarning(msg))