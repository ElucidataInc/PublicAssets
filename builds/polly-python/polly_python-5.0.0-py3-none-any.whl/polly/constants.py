# statuscodes
OK = 200
CREATED = 201
COMPUTE_ENV_VARIABLE = "POLLY_TYPE"

# Multipart S3 upload parameters
KB = 1024
MB = KB * KB

MULTIPART_THRESHOLD = 25 * MB
MAX_CONCURRENCY = 32

MIN_REQUIRED_KEYS_FOR_JOBS = ["cpu", "memory", "machineType", "image", "tag", "name"]

MACHINES_FOR_JOBS = (
    {
        "gp": "4 vCPU, 16GB RAM",
        "ci2xlarge": "16 vCPU, 32GB RAM",
        "ci3xlarge": "36 vCPU, 72GB RAM",
        "mi2xlarge": "4 vCPU, 32GB RAM",
        "mi3xlarge": "8 vCPU, 64GB RAM",
        "mi4xlarge": "16 vCPU, 122GB RAM",
        "mi5xlarge": "32 vCPU, 250GB RAM",
        "mi6xlarge": "64 vCPU, 500GB RAM",
        "mi7xlarge": "64 vCPU, 970GB RAM",
        "mix5xlarge": "16vCPU, 512GB RAM",
        "mix6xlarge": "24vCPU, 768GB RAM",
        "mix7xlarge": "64vCPU, 1024GB RAM",
        "gpusmall": "1 GPU, 4 vCPU, 16GB RAM",
        "gpumedium": "4 GPU, 32 vCPU, 240GB RAM",
        "gpularge": "8 GPU, 64 vCPU, 480GB RAM",
        "gpuxlarge": "8 GPU, 96 vCPU, 760GB RAM",
    },
)

DATA_LOG_MODES = ["latest", "all"]
MIXPANEL_KEY = "91fa77fcf07f7b672b5c5c6c09d8a14c"

POLLY_PYTHON_LATEST_VERSION_FILE = (
    "https://elucidatainc.github.io/PublicAssets/polly_python_latest_version.txt"
)
