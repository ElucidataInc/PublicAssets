import os
import re
import json

from cloudpathlib import S3Client
from botocore.exceptions import ClientError
from os import environ
from polly.errors import (
    error_handler,
    InvalidParameterException,
    MissingKeyException,
    InvalidPathException,
    OperationFailedException,
    AccessDeniedError,
)
import string


def get_platform_value_from_env(
    variable: str, default_val: str, passed_val: str
) -> str:
    """
    Get variable value of passed variable
    from os env variables
    """
    if passed_val:
        default_val = passed_val
    elif environ.get(variable, None) is not None:
        POLLY_TYPE = os.getenv(variable)
        env_val = re.search("https://(.+?).elucidata.io", POLLY_TYPE)
        default_val = env_val.group(1)
    return default_val


def make_path(prefix: any, postfix: any) -> str:
    """
    Function to make and return a valid path
    """
    if not prefix:
        raise InvalidParameterException("prefix")
    if not postfix:
        raise InvalidParameterException(
            'path can\'t be empty. if u want to push to root then make path as "/"'
        )
    return os.path.normpath(f"{prefix}/{postfix}")


def get_sts_creds(sts_dict: dict) -> dict:
    """
    Function to check and return temporary sts creds
    """
    if sts_dict and isinstance(sts_dict, dict):
        if "data" in sts_dict:
            data = sts_dict.get("data")
            if "attributes" in data[0]:
                attributes = data[0].get("attributes")
                if "credentials" in attributes:
                    return attributes.get("credentials")
                else:
                    raise MissingKeyException("credentials")
            else:
                raise MissingKeyException("attributes")
        else:
            raise MissingKeyException("data")
    else:
        raise InvalidParameterException("sts_dict")


def upload_to_S3(cloud_path: str, local_path: str, credentials: dict) -> None:
    """
    Uploads a file or folder to a specified S3 cloud path.
    """
    access_key_id = credentials["AccessKeyId"]
    secret_access_key = credentials["SecretAccessKey"]
    session_token = credentials["SessionToken"]

    # use these extras for all CloudPaths
    client = S3Client(
        aws_access_key_id=access_key_id,
        aws_secret_access_key=secret_access_key,
        aws_session_token=session_token,
        extra_args={"ContentType": "text/html"},
    )

    # Behavior:
    # 1. Validation of cloud_path:
    #    - If any part of the cloud_path contains directory names starting with special characters,
    #      the function will not consider them as valid unless they already exist in the S3 bucket.
    #    - The function will iterate through the cloud_path, checking each segment. If it encounters
    #      a segment starting with a special character that does not already exist in the S3 bucket,
    #      it will raise an error.

    # Example:
    # - Given a cloud_path of 'a/b/c/#/d/e':
    #   1. if path not exists already, The function first checks if the path '{s3}/a/b/c/#/d' exists and that 'e'
    #      does not start with a special character.
    #   2. If '{s3}/a/b/c/#/d' not exists, it checks '{s3}/a/b/c/#' and ensures 'd' does not start with a special character.
    #   3. This process continues until a exist path is found or the directory start with special character.
    # - If the cloud_path is invalid, the function raises an exception.
    # - Once a valid path is determined, the file or folder is uploaded to this path in the S3 bucket.
    client.set_as_default_client()
    source_path = client.CloudPath(cloud_path)
    splt_char = os.path.sep
    punctuation_chars = set(string.punctuation)
    if not source_path.exists():
        # if path is S3://UserDataBucket/12345/path
        # then path split will be [S3, , UserDataBucket, 12345, path]
        path_split = cloud_path.split("/")
        # s3 path have length = 4, so ignore that and checking path after that
        while len(path_split) > 4:
            cloud_path = splt_char.join(path_split[: len(path_split) - 1])
            if (
                path_split[len(path_split) - 1]
                and path_split[len(path_split) - 1][0] in punctuation_chars
            ):
                raise InvalidParameterException(
                    f"path can't start with {path_split[len(path_split) - 1][0]}"
                )
            new_source_path = client.CloudPath(cloud_path)
            if new_source_path.exists():
                break
            path_split = cloud_path.split("/")
        source_path.mkdir()

    try:
        source_path.upload_from(local_path, force_overwrite_to_cloud=True)
    except ClientError as e:
        raise OperationFailedException(e)


def download_from_S3(
    cloud_path: str,
    workspace_path: str,
    credentials: dict,
    destination_path: str,
    copy_workspace_path: bool = True,
) -> None:
    """
    Function to download file/folder from workspaces
    """
    access_key_id = credentials["AccessKeyId"]
    secret_access_key = credentials["SecretAccessKey"]
    session_token = credentials["SessionToken"]
    client = S3Client(
        aws_access_key_id=access_key_id,
        aws_secret_access_key=secret_access_key,
        aws_session_token=session_token,
    )
    source_path = client.CloudPath(cloud_path)
    if not source_path.exists():
        raise InvalidPathException
    isFile = source_path.is_file()
    if isFile:
        try:
            source_path.copy(destination_path, force_overwrite_to_cloud=True)
        except ClientError as e:
            raise OperationFailedException(e)
    else:
        source_path = client.CloudPath(cloud_path)
        if not source_path.is_dir():
            raise InvalidPathException
        try:
            # If copy_workspace_path is True, append workspace_path to destination_path to copy the directory structure.
            # ex- make_path('/home/user/project/', 'folder1/folder2') = '/home/user/project/folder1/folder2'
            if copy_workspace_path is True:
                destination_path = f"{make_path(destination_path, workspace_path)}"

            source_path.copytree(destination_path, force_overwrite_to_cloud=True)
        except ClientError as e:
            raise OperationFailedException(e)


def get_workspace_payload(
    cloud_path: str, credentials: dict, source_key: str, source_path: str
):
    """
    Function to return payload for create_copy function
    """
    access_key_id = credentials["AccessKeyId"]
    secret_access_key = credentials["SecretAccessKey"]
    session_token = credentials["SessionToken"]
    client = S3Client(
        aws_access_key_id=access_key_id,
        aws_secret_access_key=secret_access_key,
        aws_session_token=session_token,
    )
    source_path = client.CloudPath(cloud_path)
    if not source_path.exists():
        raise InvalidPathException
    isFile = source_path.is_file()
    if isFile:
        payload = {
            "data": [
                {
                    "attributes": {
                        "s3_key": source_key,
                    },
                    "id": "",
                    "type": "file",
                }
            ]
        }
    else:
        if not source_key.endswith("/"):
            source_key += "/"
        payload = {
            "data": [
                {
                    "attributes": {
                        "s3_key": source_key,
                    },
                    "id": "",
                    "type": "folder",
                }
            ]
        }
    return payload


def get_user_details(session, base_url):
    """
    Function to get user details
    """
    me_url = f"{base_url}/users/me"
    details = session.get(me_url)
    error_handler(details)
    user_details = details.json().get("data", {}).get("attributes")
    user_details["user_id"] = int(details.json().get("data", {}).get("id"))
    return user_details


def workspaces_permission_check(self, workspace_id) -> bool:
    """
    Function to check access of a user for a given workspace id.
    """
    permission_url = f"{self.resource_url_search}"
    payload = {
        "query": {
            "bool": {
                "must": [
                    {"term": {"id": workspace_id}},
                    {
                        "nested": {
                            "path": "permissions",
                            "query": {"match": {"permissions.user_id": "{user_id}"}},
                        }
                    },
                ]
            }
        }
    }
    response = self.session.post(permission_url, data=json.dumps(payload))
    error_handler(response)

    hits_total_value = response.json()["hits"]["total"].get("value", 0)

    if hits_total_value == 0:
        raise AccessDeniedError(
            detail=f"Not enough permissions over the workspace-id {workspace_id}"
        )

    hits = response.json()["hits"]["hits"]

    if not hits:
        raise AccessDeniedError(
            detail=f"Not enough permissions over the workspace-id {workspace_id}"
        )

    permission = response.json()["hits"]["hits"][0]["_source"]["permissions"][0].get(
        "access"
    )

    if permission != "read":
        return True
    else:
        raise AccessDeniedError(
            detail=f"Read-only permission over the " f"workspace-id {workspace_id}"
        )


def parseInt(sin):
    """
    parsed the value passed as int  as done by js.
    python equivalent of js parseInt
    example:
        parseInt("100n")  = 100
        parseInt("400m")  = 400

    Arguments:
        sin -- value to be parsed as int

    Returns:
        int
    """
    m = re.search(r"^(\d+)[.,]?\d*?", str(sin))
    parsed_int = int(m.groups()[-1]) if m and not callable(sin) else None
    return parsed_int
