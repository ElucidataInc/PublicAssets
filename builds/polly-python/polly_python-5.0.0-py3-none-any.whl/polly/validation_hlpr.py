def get_indexing_configs():
    """Get Indexing Configs default value"""
    indexing_configs_dict = {}
    indexing_configs_dict["file_metadata"] = True
    indexing_configs_dict["col_metadata"] = True
    indexing_configs_dict["row_metadata"] = True
    indexing_configs_dict["data_required"] = True
    return indexing_configs_dict


def get_dataset_level_validation_config():
    """Get dataset level validation config"""
    dataset = {}
    dataset["validate"] = True
    dataset["scope"] = "advanced"
    dataset["force_ingest"] = False
    return dataset


def get_sample_level_validation_configs():
    """Get sample level validation config"""
    sample = {}
    sample["validate"] = True
    sample["scope"] = "advanced"
    sample["force_ingest"] = False
    return sample
