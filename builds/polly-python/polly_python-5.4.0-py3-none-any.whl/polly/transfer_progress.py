"""
Byte-level progress bars for workspace file transfers.

Workspace uploads and downloads run through cloudpathlib, which has no
progress-reporting hook of its own. Rather than reimplement cloudpathlib's
directory traversal - and risk diverging from its overwrite, mkdir and
validation semantics - this module subclasses its ``S3Client`` and injects
boto3's ``Callback`` into the two leaf transfer calls. cloudpathlib keeps doing
all of the walking; we only observe the bytes going past, so a folder transfer
reports one continuous bar across every file in the tree.

``ProgressS3Client._upload_file`` / ``_download_file`` mirror cloudpathlib's own
implementations verbatim apart from that added ``Callback``. They are
byte-identical across every cloudpathlib release this package supports
(0.19.0 - 0.24.0), and tests/test_transfer_progress.py asserts the hook still
fires, so an upgrade that reworks them fails loudly rather than silently
dropping the bars.

Bars are written to stderr and can be turned off process-wide by setting
``POLLY_DISABLE_PROGRESS=1``.
"""

import os
from pathlib import Path
from threading import Lock
from typing import Optional, Union

from cloudpathlib import S3Client
from tqdm import tqdm

_DISABLE_ENV_VAR = "POLLY_DISABLE_PROGRESS"

# Instance attributes of cloudpathlib's S3Client that the overrides below read.
# Checked at construction time so a future cloudpathlib can only cost us the
# progress bar, never the transfer itself.
_REQUIRED_CLIENT_ATTRS = (
    "s3",
    "boto3_ul_extra_args",
    "boto3_dl_extra_args",
    "boto3_transfer_config",
    "content_type_method",
)


def progress_disabled() -> bool:
    """True when the user has opted out of progress bars."""
    return os.environ.get(_DISABLE_ENV_VAR, "").strip().lower() in (
        "1",
        "true",
        "yes",
    )


class TransferProgress:
    """
    A tqdm bar measured in bytes, safe to update from boto3's transfer threads.

    Also records the running total in ``transferred`` so that callers - and
    tests - can inspect what was actually reported without scraping terminal
    output.
    """

    def __init__(
        self,
        total_bytes: int = 0,
        desc: Optional[str] = None,
        disable: Optional[bool] = None,
    ):
        if disable is None:
            disable = progress_disabled()
        self.total_bytes = total_bytes
        self.transferred = 0
        self._lock = Lock()
        self._bar = tqdm(
            total=total_bytes,
            desc=desc,
            unit="B",
            unit_scale=True,
            unit_divisor=1024,
            disable=disable,
            smoothing=0.1,
        )

    def update(self, num_bytes: int) -> None:
        # boto3 invokes the callback from its own transfer threads
        with self._lock:
            self.transferred += num_bytes
            self._bar.update(num_bytes)

    def set_total(self, total_bytes: int) -> None:
        """
        Set the expected size after construction.

        Downloads need the client before they can size the remote path, so the
        bar is created first and told its total once that is known.
        """
        with self._lock:
            self.total_bytes = total_bytes
            self._bar.total = total_bytes
            self._bar.refresh()

    def close(self) -> None:
        self._bar.close()

    def __enter__(self) -> "TransferProgress":
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        self.close()


class ProgressS3Client(S3Client):
    """
    ``S3Client`` that reports every transferred byte to a :class:`TransferProgress`.

    Passing ``progress=None`` gives back plain cloudpathlib behaviour, so this
    class is always safe to use in place of ``S3Client``.
    """

    def __init__(self, *args, progress: Optional[TransferProgress] = None, **kwargs):
        super().__init__(*args, **kwargs)
        self._progress = progress

    def _report(self, num_bytes: int) -> None:
        if self._progress is not None:
            self._progress.update(num_bytes)

    # Mirrors cloudpathlib.s3.S3Client._upload_file, plus Callback.
    def _upload_file(
        self, local_path: Union[str, os.PathLike], cloud_path
    ):  # type: ignore[override]
        obj = self.s3.Object(cloud_path.bucket, cloud_path.key)

        extra_args = self.boto3_ul_extra_args.copy()

        if self.content_type_method is not None:
            content_type, content_encoding = self.content_type_method(str(local_path))
            if content_type is not None:
                extra_args["ContentType"] = content_type
            if content_encoding is not None:
                extra_args["ContentEncoding"] = content_encoding

        obj.upload_file(
            str(local_path),
            Config=self.boto3_transfer_config,
            ExtraArgs=extra_args,
            Callback=self._report,
        )
        return cloud_path

    # Mirrors cloudpathlib.s3.S3Client._download_file, plus Callback.
    def _download_file(
        self, cloud_path, local_path: Union[str, os.PathLike]
    ) -> Path:  # type: ignore[override]
        local_path = Path(local_path)
        obj = self.s3.Object(cloud_path.bucket, cloud_path.key)

        obj.download_file(
            str(local_path),
            Config=self.boto3_transfer_config,
            ExtraArgs=self.boto3_dl_extra_args,
            Callback=self._report,
        )
        return local_path


def build_s3_client(
    credentials: dict,
    extra_args: Optional[dict] = None,
    progress: Optional[TransferProgress] = None,
) -> S3Client:
    """
    Build an S3 client from Polly STS credentials, reporting to ``progress``.

    Falls back to a plain ``S3Client`` if this cloudpathlib release does not
    expose the internals ``ProgressS3Client`` overrides - a missing progress bar
    is preferable to a failed transfer.
    """
    kwargs = dict(
        aws_access_key_id=credentials["AccessKeyId"],
        aws_secret_access_key=credentials["SecretAccessKey"],
        aws_session_token=credentials["SessionToken"],
    )
    if extra_args is not None:
        kwargs["extra_args"] = extra_args

    if progress is None:
        return S3Client(**kwargs)

    client = ProgressS3Client(progress=progress, **kwargs)
    if all(hasattr(client, name) for name in _REQUIRED_CLIENT_ATTRS):
        return client
    # cloudpathlib reworked the internals our overrides rely on
    return S3Client(**kwargs)


def local_total_bytes(local_path: Union[str, os.PathLike]) -> int:
    """Total size of a local file, or of every file beneath a local directory."""
    path = Path(local_path)
    if path.is_file():
        return path.stat().st_size

    total = 0
    for dirpath, _dirnames, filenames in os.walk(path):
        for name in filenames:
            try:
                total += os.path.getsize(os.path.join(dirpath, name))
            except OSError:
                # a file that vanished or is unreadable only affects the bar total
                continue
    return total


def cloud_total_bytes(client: S3Client, cloud_path: str) -> int:
    """
    Total size of an ``s3://`` object, or of every object beneath a prefix.

    A single object is sized with one HEAD. A prefix uses a paginated LIST
    rather than one HEAD per key, so the bar total costs the same for a large
    tree as for a small one.
    """
    path = client.CloudPath(cloud_path)
    bucket, key = path.bucket, path.key
    if not key:
        return 0

    try:
        head = client.client.head_object(Bucket=bucket, Key=key)
        size = int(head.get("ContentLength", 0))
        # an empty key ending in "/" is a directory marker, not a real object,
        # so fall through and sum what is underneath it
        if size or not key.endswith("/"):
            return size
    except Exception:
        # not a single object - treat it as a prefix below
        pass

    # trailing slash so that prefix "data" does not also match "data-archive/"
    prefix = key.rstrip("/") + "/"
    total = 0
    paginator = client.client.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
        for obj in page.get("Contents", []):
            total += obj.get("Size", 0)
    return total


def transfer_progress(
    total_bytes: int, desc: str, disable: Optional[bool] = None
) -> TransferProgress:
    """Convenience constructor used by the workspace transfer helpers."""
    return TransferProgress(total_bytes=total_bytes, desc=desc, disable=disable)


def server_side_progress(desc: str, disable: Optional[bool] = None) -> tqdm:
    """
    An elapsed-time bar for work done entirely on the server.

    Workspace-to-workspace copies never stream bytes through the client, so
    there is no total to count towards - only the fact that we are still
    waiting. Call ``update()`` on each poll to keep it alive.
    """
    if disable is None:
        disable = progress_disabled()
    return tqdm(
        total=None,
        desc=desc,
        disable=disable,
        bar_format="{desc}: {elapsed} elapsed",
    )
