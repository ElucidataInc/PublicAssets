PARAM_EXCEPTION = "parameter passed is either empty or wrong datatype"
PARAM_EXCEPTION_TITLE = "parameter error"

WRONG_PARAMS_EXCEPTION = "Incorrect value of param passed"
WRONG_PARAMS_EXCEPTION_TITLE = "parameter error"

API_ERROR_EXCEPTION_TITLE = "API ERROR"
API_ERROR_EXCEPTION = ""
