from mixpanel import Mixpanel
from polly.constants import MIXPANEL_KEY


class Track:
    """
    This class is used for tracking polly-python services using mixpanel.
    This class will have a unidirectional association relationship with the class which wants to use the tracking service.
    The track function sends the logs to mixpanel.
    For using this feature, make an object in the __init__ function for the class this feature is to be used,
    then use the track function with that object.
    """

    def track_decorator(function):
        def wrapper_function(*args, **kwargs):
            obj = args[0].session
            user_id = obj.user_details.get("user_id")
            function_params = {}
            if len(args) > 1:
                args_list = []
                for index in range(1, len(args)):
                    args_list.append(args[index])
                function_params["arguments"] = args_list
            if kwargs:
                for key, value in kwargs.items():
                    function_params[key] = value
            mp = Mixpanel(MIXPANEL_KEY)
            if function_params:
                mp.track(user_id, function.__name__, function_params)
            else:
                mp.track(user_id, function.__name__)
            return function(*args, **kwargs)

        return wrapper_function
