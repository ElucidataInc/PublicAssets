import copy
import traceback as tb
from datetime import datetime as dt

import rapidfuzz as rf
from pydantic import validator

from polly_validator.settings import FIELD_MAPPING, VALID_NAMES, DATASET_LEVEL_FIELD_SPECIFIC_DEFAULT_VALUES, \
    DATASET_LEVEL_FIELD_SPECIFIC_NOT_ALLOWED_VALUES, DATASET_LEVEL_CONTROLLED_VOCABULARY_ALL_VALUES, DATA_TYPE
from polly_validator.utility.helper import build_validation_schema, list_to_set_in_dict, lower_and_strip, \
    print_exception, split_fields_by_type, split_curated_ontological_fields_by_type, get_controlled_vocab_fields

# Creating valid name but lowered and stripped
VALID_NAMES_LOWERED = copy.deepcopy(VALID_NAMES)
VALID_NAMES_LOWERED = lower_and_strip(VALID_NAMES_LOWERED)

# Convert all lists to set for faster lookups
VALID_NAMES = list_to_set_in_dict(VALID_NAMES)
VALID_NAMES_LOWERED = list_to_set_in_dict(VALID_NAMES_LOWERED)

ontological_fields = ['curated_disease',
                      'curated_tissue',
                      'curated_organism',
                      'curated_cell_line',
                      'curated_cell_type',
                      'curated_drug']


"""Ontology Check Function"""


def check_ontology(field_to_check: str, name: str):
    """
    Checks for ontological values for particular field. Allows field default values.
    Args:
        field_to_check: field being validated
        name: value of field

    Returns:
        Raises value error if name does not match ontology or allowed default values
    """
    if field_to_check == 'curated_cell_line':
        # Specifically for kw_cell_line, valid names are stores separately.
        valid = VALID_NAMES[FIELD_MAPPING[field_to_check]]['valid_cell_line_names']
        valid_lowered_stripped = VALID_NAMES_LOWERED[FIELD_MAPPING[field_to_check]]['valid_cell_line_names']
    elif field_to_check == 'curated_cell_type':
        # Specifically for kw_cell_line, valid names are stores separately.
        valid = VALID_NAMES[FIELD_MAPPING[field_to_check]]['valid_cell_type_names']
        valid_lowered_stripped = VALID_NAMES_LOWERED[FIELD_MAPPING[field_to_check]]['valid_cell_type_names']
    else:
        valid = VALID_NAMES[FIELD_MAPPING[field_to_check]]
        valid_lowered_stripped = VALID_NAMES_LOWERED[FIELD_MAPPING[field_to_check]]

    if name not in valid:
        if name.lower().strip() in valid_lowered_stripped:
            possible_match = rf.process.extract(name, valid, scorer=rf.fuzz.ratio, limit=1)[0][0]
            raise ValueError(f'Ontological Validity Check | Valid Value BUT with case/whitespaces mismatch '
                             f'| Erroneous Value: "{name}" | Possible match: "{possible_match}"')
        else:
            if field_to_check in DATASET_LEVEL_FIELD_SPECIFIC_DEFAULT_VALUES:
                if not check_field_specific_default(field_to_check, name):
                    raise ValueError(f'Ontological Validity Check | Invalid Value | Erroneous Value: "{name}"')

            else:
                raise ValueError(f'Ontological Validity Check | Invalid Value | Erroneous Value: "{name}"')


"""-------Checks for allowed and prohibited default values-------"""


def check_field_specific_default(field_to_check: str, val: str):
    """
    For the given field, if val is one of the allowed values as per the config, returns True
    Args:
        field_to_check: field being validated
        val: value of field

    Returns:
        True if val is one of the allowed values as per the config
    """
    default_value = DATASET_LEVEL_FIELD_SPECIFIC_DEFAULT_VALUES.get(field_to_check, None)
    if default_value and val not in default_value:
        return False

    return True


def check_prohibited_values(cls, val, field):
    """
    For the given field, if val is one of the prohibited values as per the config, raise an error.
    Args:
        field:
        cls: required first parameter for the function to be used as a validator function
        val: value of the field

    Returns:
        val
    """
    field_to_check = field.name
    # field.name sometimes comes with a leading underscore
    field_to_check = field_to_check.strip('_')
    not_allowed_vals = DATASET_LEVEL_FIELD_SPECIFIC_NOT_ALLOWED_VALUES.get(field_to_check, None)
    if not_allowed_vals:
        if val in not_allowed_vals:
            raise ValueError(f'Value Check | Prohibited value for this field | Erroneous Value: "{val}"')
    return val


"""-------Checks for fields with predefined values-------"""


def check_predefined_values(cls, val, field):
    """
    Check the value of fields against predefined values defined in config
    Args:
        cls: required first parameter for the function to be used as a validator function
        val: value of the field
        field: field being validated
    Returns:
        val
    """
    field_to_check = field.name
    # field.name sometimes comes with a leading underscore
    field_to_check = field_to_check.strip('_')

    if val not in DATASET_LEVEL_CONTROLLED_VOCABULARY_ALL_VALUES.get(field_to_check, None):
        raise ValueError(f'Value Check | Invalid value: not one of the predefined values | Erroneous Value: "{val}"')

    return val


"""-------Field Specific Checks [FC]-------"""


def check_lower(cls,val):
    if val.lower() != val and val!='None':
        raise ValueError(f'Value Check | Invalid value: Should be lower case | Erroneous Value: "{val}" ')


def check_abstract(cls, val):
    """
    Check the value of abstract : whether it is a string with a '.' , does not default value for abstract field as per config
    Args:
        cls: required first parameter for the function to be used as a validator function
        val: value of the field

    Returns:
        val
    """
    if 'abstract' in DATASET_LEVEL_FIELD_SPECIFIC_DEFAULT_VALUES:

        if ('.' not in val) and (not check_field_specific_default('abstract', val)):
            raise ValueError(f'Value Check | Invalid value: "." not present | Erroneous Value: "{val}"')

    else:
        if ('.' not in val):
            raise ValueError(f'Value Check | Invalid value: "." not present | Erroneous Value: "{val}"')

    return val



def check_for_nan_strings(cls, val):
    """
    Validator to check for 'nan' or empty strings
    Args:
        cls: required first parameter for the function to be used as a validator function
        val: value of the field

    Returns:
        val
    """
    if isinstance(val, str):
        if (val.strip().lower() == 'nan') | (val.strip().lower() == ''):
            raise ValueError(f'Value Check | Invalid Value: "{val}" ')

    return val


def check_dataset_id(cls, val):
    """
    Check that there should not be any spaces in dateset id value
    Args:
        cls: required first parameter for the function to be used as a validator function
        val: value of the field
    Returns:
        val
    """
    if ' ' in val:
        raise ValueError(f'Value Check | Invalid value: contains one or more spaces. | Erroneous Value: "{val}"')

    return val


def check_valid_data_type(cls, val):
    """
    Check the value of data type against predefined values of data_type in valid_names.json
    Args:
        cls: required first parameter for the function to be used as a validator function
        val: value of the field

    Returns:
        val
    """
    # valid = VALID_NAMES["data_type"]
    if DATA_TYPE == 'bulkseq':
        valid=['Raw Counts Transcriptomics']
    elif DATA_TYPE == 'single_cell':
        valid=['Single cell']
    elif DATA_TYPE == 'microarray':
        valid = ['Microarray']
    else:
        raise ValueError("data_type provided should be one among 'bulkseq','single_cell','microarray'")
    
    if val not in valid:
        raise ValueError(f'Value Check | Invalid value: not one of the predefined values | Erroneous Value: "{val}"')
    return val


def check_year(cls, val):
    """
    Year has to be an integer and not greater than current year
    Args:
        cls: required first parameter for the function to be used as a validator function
        val: value of the field

    Returns:
        val
    """
    is_int = True
    try:
        # converting to integer
        int(val)
    except ValueError:
        is_int = False
    #     if not is_int:
    #         if isinstance(val, str):
    #             if val != 'NA':
    #                 raise ValueError(f'Value Check | Invalid value | Erroneous Value: "{val}"')
    if is_int:
        if int(val) > dt.now().year or int(val) < 1900:
            raise ValueError(
                f'Value Check | Invalid value | Erroneous Value: "{val}"')
    return val


def check_valid_dataset_source(cls, val):
    """
    'dataset_source' can only be one of the predefined values.
    Args:
        cls: required first parameter for the function to be used as a validator function
        val: value of the field

    Returns:
        val
    """
    valid = VALID_NAMES['dataset_source']
    if val not in valid:
        raise ValueError(f'Value Check | Invalid value: not one of the predefined values | Erroneous Value: "{val}"')
    return val


"""-------Ontology Value Checks [OC]-------"""


def check_for_default_values_in_lists(cls, val, field):
    """
    Flags default values (defined in config) in list type fields with length greater than 1
    Args:
        cls: required first parameter for the function to be used as a validator function
        val: value of field
        field: field being validated

    Returns:
        val
    """
    if len(val) < 2:
        return val
    field_to_check = field.name
    # field.name sometimes comes with a leading underscore
    field_to_check = field_to_check.strip('_')
    allowed_default = DATASET_LEVEL_FIELD_SPECIFIC_DEFAULT_VALUES.get(field_to_check, None)
    if allowed_default:
        if any(item in allowed_default for item in val):
            raise ValueError(f'Value Check | A list more than a length of one element '
                             f'contains one or more default values. | Erroneous Value: "{val}"')
    return val


def has_valid_ontology(cls, val, field):
    """
    Check that the values of the above field case-sensitively match the valid values as in the ontology knowledge
    base
    Args:
        cls: required first parameter for the function to be used as a validator function
        val: value of the field
        field: field being validated

    Returns:
        val
    """
    field_to_check = field.name
    # field.name at times comes with a leading underscore
    field_to_check = field_to_check.strip('_')
    if isinstance(val, list):
        for name in val:
            check_ontology(field_to_check, name)
    else:
        check_ontology(field_to_check, val)
    return val


"""-------Logical Checks [LC]--------"""


def check_cell_line_organism_agreement(cls, val, values, field):
    """
    Check that the value of cell line is valid for the particular organism
    Args:
        cls: required first parameter for the function to be used as a validator function
        val: value of the field
        values: dict of values of the model object
        field: field being validated

    Returns:
        val
    """
    field_to_check = field.name
    # field.name at times comes with a leading underscore
    field_to_check = field_to_check.strip('_')
    for value in val:
        if value != 'None' and value != 'none':
            if 'curated_organism' in values:
                organism_list = values.get('curated_organism')
                organisms_to_check_for_cell_line = {org: cell_lines for org, cell_lines in
                                                    VALID_NAMES[FIELD_MAPPING[field_to_check]]['organism'].items()
                                                    if org in organism_list}
                if organisms_to_check_for_cell_line:
                    if not any([True for v in organisms_to_check_for_cell_line.values() if value in v]):
                        raise ValueError(
                            f'Logical Check | Not a valid cell line for '
                            f'organism = {list(organisms_to_check_for_cell_line.keys())} | Erroneous Value: "{value}"')
    return val


def check_cell_line_disease_agreement(cls, val, values, field):
    """
    Check that the value of cell line is valid for the particular disease
    Args:
        val: value of the field
        values: dict of values of the model object
        field: field being validated

    Returns:
        val
    """
    field_to_check = field.name
    # field.name at times comes with a leading underscore
    field_to_check = field_to_check.strip('_')
    for value in val:
        if value != 'None' and value != 'none':
            if 'curated_disease' in values:
                disease_list_from_input = values.get('curated_disease')
                diseases_to_check_for_cell_line = {disease: cell_lines for disease, cell_lines in
                                                   VALID_NAMES[FIELD_MAPPING[field_to_check]]['disease'].items()
                                                   if disease in disease_list_from_input}
                if diseases_to_check_for_cell_line:
                    if not any([True for v in diseases_to_check_for_cell_line.values() if value in v]):
                        raise ValueError(
                            f'Logical Check | Not a valid cell line for '
                            f'disease = {list(diseases_to_check_for_cell_line.keys())} | Erroneous Value: "{value}"')
    return val


"""---Function to dynamically build the validator_class_constructors given a repo---"""


def build_schema_for_repo(schema_dict: dict):
    """
    given a repo, build two pydantic class constructors, one with just the schema, the other with validators as well
    Args:
        schema_dict: schema dictionary

    Returns:
        pydantic classes (schema and schema_with_validator)
    """
    # Build validator_class_constructors
    try:
        schema = build_validation_schema(schema_dict, for_level='dataset')
        all_fields = list(schema_dict.keys())

        ontological_fields_as_str, ontological_fields_as_list = split_curated_ontological_fields_by_type(
            ontological_fields,
            schema_dict)
        str_fields, list_fields = split_fields_by_type(schema_dict)

        controlled_vocab = get_controlled_vocab_fields(DATASET_LEVEL_CONTROLLED_VOCABULARY_ALL_VALUES)
        validators = {

            'check_nan_strings': validator(*all_fields,
                                           allow_reuse=True,
                                           check_fields=False,
                                           each_item=True)(check_for_nan_strings),

            'check_prohibited_values': validator(*all_fields,
                                                 allow_reuse=True,
                                                 check_fields=False,
                                                 each_item=True)(check_prohibited_values),

            'check_dataset_id': validator('dataset_id',
                                          allow_reuse=True,
                                          check_fields=False)(check_dataset_id),
            'check_year': validator('year',
                                    allow_reuse=True,
                                    check_fields=False)(check_year),

            'check_valid_dataset_source': validator('dataset_source',
                                                    allow_reuse=True,
                                                    check_fields=False)(check_valid_dataset_source),
            'check_valid_data_type': validator('data_type',
                                               allow_reuse=True,
                                               check_fields=False)(check_valid_data_type),

            'check_cell_line_organism_agreement': validator('curated_cell_line',
                                                            allow_reuse=True,
                                                            check_fields=False)(check_cell_line_organism_agreement),
            'check_cell_line_disease_agreement': validator('curated_cell_line',
                                                           allow_reuse=True,
                                                           check_fields=False)(check_cell_line_disease_agreement),

            'check_abstract': validator('abstract',
                                        allow_reuse=True,
                                        check_fields=False)(check_abstract),

                                        'check_lower': validator('curated_strain',
                                           allow_reuse=True,
                                           check_fields=False,
                                           each_item=True)(check_lower)  

        }

        # if list_fields:
        #     validators['check_for_default_values_in_lists'] = validator(*list_fields,
        #                                                                 allow_reuse=True,
        #                                                                 check_fields=False)(
        #         check_for_default_values_in_lists)

        if ontological_fields_as_list:
            validators['check_valid_names_in_lists'] = validator(*ontological_fields_as_list,
                                                                 allow_reuse=True,
                                                                 each_item=True,
                                                                 check_fields=False)(has_valid_ontology)
        if ontological_fields_as_str:
            validators['check_valid_names_in_strings'] = validator(*ontological_fields_as_str,
                                                                   allow_reuse=True,
                                                                   check_fields=False)(has_valid_ontology)
        if controlled_vocab:
            validators['check_predefined_values'] = validator(*controlled_vocab,
                                                              allow_reuse=True,
                                                              each_item=True,
                                                              check_fields=False,
                                                              )(check_predefined_values)

        schema_with_validator = build_validation_schema(schema_dict, for_level='dataset', validators=validators)
        return schema, schema_with_validator
    except Exception as exc:
        print(tb.format_exc())
        print_exception()
        return None, None
