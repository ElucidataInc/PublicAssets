import copy
import traceback as tb

import rapidfuzz as rf
from pydantic import validator
import re
from polly_validator.settings import FIELD_MAPPING, VALID_NAMES, SAMPLE_LEVEL_FIELD_SPECIFIC_DEFAULT_VALUES, \
    SAMPLE_LEVEL_FIELD_SPECIFIC_PROHIBITED_VALUES, SAMPLE_LEVEL_CONTROLLED_VOCABULARY_ALL_VALUES
from polly_validator.utility.helper import build_validation_schema, list_to_set_in_dict, lower_and_strip, \
    print_exception, split_curated_ontological_fields_by_type, split_fields_by_type, get_controlled_vocab_fields

# Creating valid name but lowered and stripped
VALID_NAMES_LOWERED = copy.deepcopy(VALID_NAMES)
VALID_NAMES_LOWERED = lower_and_strip(VALID_NAMES_LOWERED)

# Convert all lists to set for faster lookups
VALID_NAMES = list_to_set_in_dict(VALID_NAMES)
VALID_NAMES_LOWERED = list_to_set_in_dict(VALID_NAMES_LOWERED)

ontological_fields = ['curated_disease',
                      'curated_cell_type',
                      'curated_cell_line',
                      'curated_drug',
                      'curated_tissue',
                      'curated_gene',
                      'curated_gene_modified']

fields_to_check_int_in_str = ['clusters']

# fields_to_check_float_in_str = ['gene_counts', 'percent_mito', 'umi_counts']
"""---Utility Functions that use the VALID_NAMES dict---"""


def verify_tissue_value_for_cell_line(tissue_val: str, cell_line_val: str):
    """
    Compile the valid tissue name using the input string and then cross referencing it using BTO value from
    ontologies.
    Args:
        cell_line_val: string value of cell line from the data
        tissue_val: string value of the name of the tissue from the data

    Returns:

    """
    bto_id = VALID_NAMES['tissue']['tissue_id_name_dict'].get(tissue_val)
    cell_line_for_this_bto = VALID_NAMES['cell_line']['cell_line_tissue_dict'].get(bto_id)
    return cell_line_for_this_bto == cell_line_val


def check_field_specific_default(field_to_check: str, val):
    """

    Args:
        field_to_check:
        val:

    Returns:

    """
    default_value = SAMPLE_LEVEL_FIELD_SPECIFIC_DEFAULT_VALUES.get(field_to_check, None)

    if default_value:
        if val not in default_value:
            return False
    return True


"""Ontology Check Function"""


def has_valid_ontology(field_to_check: str, name: str):
    """

    Args:
        field_to_check:
        name:

    Returns:

    """
    if field_to_check == 'curated_cell_line':
        # Specifically for curated_cell_line, valid names are stores separately.
        valid = VALID_NAMES[FIELD_MAPPING[field_to_check]]['valid_cell_line_names']
        valid_lowered_stripped = VALID_NAMES_LOWERED[FIELD_MAPPING[field_to_check]]['valid_cell_line_names']
    elif field_to_check == 'curated_cell_type':
        # Specifically for curated_cell_type, valid names are stored separately.
        valid = VALID_NAMES[FIELD_MAPPING[field_to_check]]['valid_cell_type_names']
        valid_lowered_stripped = VALID_NAMES_LOWERED[FIELD_MAPPING[field_to_check]]['valid_cell_type_names']

    elif field_to_check == 'curated_gene_modified':
        valid = VALID_NAMES[FIELD_MAPPING['curated_gene']]
        valid_lowered_stripped = VALID_NAMES_LOWERED[FIELD_MAPPING['curated_gene']]

    else:
        valid = VALID_NAMES[FIELD_MAPPING[field_to_check]]
        valid_lowered_stripped = VALID_NAMES_LOWERED[FIELD_MAPPING[field_to_check]]

    if name not in valid:
        if not check_field_specific_default(field_to_check, name):
            if name.lower().strip() in valid_lowered_stripped:
                possible_match = rf.process.extract(name, valid, scorer=rf.fuzz.ratio, limit=1)[0][0]
                raise ValueError(f'Ontological Validity Check | Valid Value BUT with case/whitespaces mismatch '
                                 f'| Erroneous Value: "{name}" | Possible match: "{possible_match}"')
            else:
                raise ValueError(f'Ontological Validity Check | Invalid Value | Erroneous Value: "{name}"')


"""---Validator Functions---"""
def check_curated_cancer_tnm_stage(cls,val):

    pattern = r"T\d+\w*N\d+\w*M\d+\w*"
    if not re.fullmatch(pattern, val) and val!='none':
        raise ValueError(f'Value Check | Invalid value: not in proper format: TxNxMx | Erroneous Value: "{val}" ')
    

def check_curated_cancer_stage(cls,val):

    pattern = r"Stage\s\d+"
    if not re.fullmatch(pattern, val) and val!='none':
        raise ValueError(f'Value Check | Invalid value: not in proper format: Stagex | Erroneous Value: "{val}" ')
    

def check_curated_cancer_grade(cls,val):

    pattern = r"Grade\s\d+"
    if not re.fullmatch(pattern, val) and val!='none':
        raise ValueError(f'Value Check | Invalid value: not in proper format: Gradex | Erroneous Value: "{val}" ')

def check_for_nan_strings(cls, val):
    """
    Validator to check for 'nan' strings
    Args:
        cls:
        val:

    Returns:

    """
    if isinstance(val, str):
        if val.strip().lower() == 'nan':
            raise ValueError(f'Value Check | Invalid Value: "{val}" | Correct null value: "none"')
    return val


def check_empty_str(cls, val):
    """

    Args:
        cls:
        val:

    Returns:

    """
    if isinstance(val, str):
        if val == "":
            raise ValueError(f'Value Check | Empty strings are not allowed | Erroneous Value: "{val}"')
    return val


def check_int_value_in_str(cls, val):
    """
    check that the value of the string for a string field is a valid integer value
    Args:
        cls: 
        val: 

    Returns:

    """
    is_int = True
    if isinstance(val, str):
        try:
            # converting to integer
            int(val)
        except ValueError:
            is_int = False
        if not is_int:
            raise ValueError(f'Value Check | Only integer values accepted | Erroneous Value: "{val}"')
    return val


def check_for_default_values_in_lists(cls, val, field):
    """
        Check for a single None value
        Args:
            val:
            field:

        Returns:

        """
    if len(val) < 2:
        return val
    field_to_check = field.name
    # field.name sometimes comes with a leading underscore
    field_to_check = field_to_check.strip('_')
    allowed_default = SAMPLE_LEVEL_FIELD_SPECIFIC_DEFAULT_VALUES.get(field_to_check, None)
    if allowed_default:
        if any(item in allowed_default for item in val):
            raise ValueError(f'Value Check | A list more than a length of one element '
                             f'contains one or more default values. | Erroneous Value: "{val}"')
    return val


def check_prohibited_values(cls, val, field):
    """
    For the given field, if val is one of the prohibited values as per the config, raise an error.
    Args:
        field:
        cls:
        val:

    Returns:

    """
    field_to_check = field.name
    # field.name sometimes comes with a leading underscore
    field_to_check = field_to_check.strip('_')
    not_allowed_vals = SAMPLE_LEVEL_FIELD_SPECIFIC_PROHIBITED_VALUES.get(field_to_check, None)
    if not_allowed_vals:
        if val in not_allowed_vals:
            raise ValueError(f'Value Check | Prohibited value for this field | Erroneous Value: "{val}"')
    return val

def check_predefined_values(cls, val, field):
    """
    Check the value of fields against predefined values defined in config
    Args:
        cls: required first parameter for the function to be used as a validator function
        val: value of the field
        field: field being validated
    Returns:
        val
    """
    field_to_check = field.name
    # field.name sometimes comes with a leading underscore
    field_to_check = field_to_check.strip('_')

    if val not in SAMPLE_LEVEL_CONTROLLED_VOCABULARY_ALL_VALUES.get(field_to_check, None):
        raise ValueError(f'Value Check | Invalid value: not one of the predefined values | Erroneous Value: "{val}"')

    return val

def check_valid_ontology(cls, val, field):
    """
        Check that the values of the above field  match the valid values as in the ontology knowledge
        base
        Args:
            val:
            field:

        Returns:
            val
        """
    field_to_check = field.name
    # field.name at times comes with a leading underscore
    field_to_check = field_to_check.strip('_')
    has_valid_ontology(field_to_check, val)
    return val


# def check_curated_marker_absent(cls, val):
#     """

#     Args:
#         cls:
#         val:

#     Returns:

#     """
#     allowed_values = ['none', 'not_available']
#     if val not in allowed_values:
#         raise ValueError(f'Value Error | Value not allowed. Only allowed values are: {allowed_values} '
#                          f'| Erroneous value: {val}')
#     pass


"""---Concordance Check Validators---"""


def check_cell_ontology_type_agreement(cls, val, values, field):
    """
    Check that the value of cell ontology is valid for the particular cell type(s)
    Args:
        val: value of the field
        values: dict of values of the model object
        field: field being validated

    Returns:

           """
    field_to_check = field.name
    # field.name at times comes with a leading underscore
    field_to_check = field_to_check.strip('_')

    if not check_field_specific_default(field_to_check, val):
        if 'curated_cell_type' in values:
            cell_type_values = values.get('curated_cell_type', None)
            valid_ontological_ids = []
            for cell_type_val in cell_type_values:
                valid = VALID_NAMES[FIELD_MAPPING[field_to_check]]['concordance_id_type_dict'].get(cell_type_val, None)
                if valid:
                    valid_ontological_ids.append(valid)
            if valid_ontological_ids:
                if val not in valid_ontological_ids:
                    raise ValueError(
                        f'Logical Check | Not a valid cell ontology id for any of the '
                        f'cell type values: {cell_type_values} | Erroneous Value: "{val}"')
    return val


# ToDo: Check this
def check_cell_line_disease_agreement(cls, val, values, field):
    """
    Check that the value of cell line is valid for the particular disease
    Args:
        val: value of the field
        values: dict of values of the model object
        field: field being validated

    Returns:

           """
    field_to_check = field.name
    # field.name at times comes with a leading underscore
    field_to_check = field_to_check.strip('_')
    disease_list_from_input = values.get('curated_disease', None)
    if disease_list_from_input:
        if not check_field_specific_default(field_to_check, val):
            diseases_to_check_for_cell_line = {disease: cell_lines for disease, cell_lines in
                                               VALID_NAMES[FIELD_MAPPING[field_to_check]]['disease'].items()
                                               if disease in disease_list_from_input}
            if diseases_to_check_for_cell_line:
                if val not in diseases_to_check_for_cell_line.values():
                    raise ValueError(
                        f'Logical Check | Not a valid cell line for '
                        f'disease = {list(diseases_to_check_for_cell_line.keys())} | '
                        f'Erroneous Value: "{val}"')
    return val


# ToDo: Implement and verify this.
def check_cell_line_organism_agreement(cls, val, values, field, **kwargs):
    """
    check that the value of cell line agrees with the value of the organism (from dataset level)
    Args:
        cls:
        val:
        values:
        field:

    Returns:

    """


"""---Function to dynamically build the validator_class_constructors given a repo---"""


def build_schema_for_repo(schema_dict, dataset_id_organism_dict=None):
    """
    Given a repo, build two pydantic classes, one with just the schema, the other with validators as well
    Args:
        schema_dict:

    Returns:

    """
    try:
        schema = build_validation_schema(schema_dict, for_level='sample')

        # Make groups of fields for common checks:
        all_field_names = list(schema_dict.keys())
        ontological_fields_as_str, ontological_fields_as_list = split_curated_ontological_fields_by_type(
            ontological_fields,
            schema_dict)
        str_fields, list_fields = split_fields_by_type(schema_dict)
        controlled_vocab = get_controlled_vocab_fields(SAMPLE_LEVEL_CONTROLLED_VOCABULARY_ALL_VALUES)
       
        # Assign field specific validators:
        validators = {
            'check_for_nan_strings': validator(*all_field_names,
                                               allow_reuse=True,
                                               check_fields=False,
                                               each_item=True)(check_for_nan_strings),
            'check_empty_str': validator(*all_field_names,
                                         allow_reuse=True,
                                         check_fields=False,
                                         each_item=True)(check_empty_str),
            'check_int_value_in_str': validator(*fields_to_check_int_in_str,
                                                allow_reuse=True,
                                                check_fields=False)(check_int_value_in_str),
            'check_prohibited_values': validator(*all_field_names,
                                                 allow_reuse=True,
                                                 check_fields=False,
                                                 each_item=True)(check_prohibited_values),

            'check_curated_cancer_tnm_stage':validator('curated_cancer_tnm_stage',
                                                 allow_reuse=True,
                                                 check_fields=False,
                                                 each_item=True)(check_curated_cancer_tnm_stage),

            'check_curated_cancer_grade':validator('curated_cancer_grade',
                                                 allow_reuse=True,
                                                 check_fields=False,
                                                 each_item=True)(check_curated_cancer_grade),
            'check_curated_cancer_stage':validator('curated_cancer_stage',
                                                 allow_reuse=True,
                                                 check_fields=False,
                                                 each_item=True)(check_curated_cancer_stage)
                        

            
        }

        if list_fields:
            validators['check_for_default_values_in_list'] = validator(*list_fields,
                                                                       allow_reuse=True,
                                                                       check_fields=False)(
                check_for_default_values_in_lists)
        if ontological_fields_as_list:
            validators['check_valid_names_in_lists'] = validator(*ontological_fields_as_list,
                                                                 allow_reuse=True,
                                                                 each_item=True,
                                                                 check_fields=False)(check_valid_ontology)
        if ontological_fields_as_str:
            validators['check_valid_names_in_strings'] = validator(*ontological_fields_as_str,
                                                                   allow_reuse=True,
                                                                   check_fields=False)(check_valid_ontology)

        if controlled_vocab:
                validators['check_predefined_values'] = validator(*controlled_vocab,
                                                              allow_reuse=True,
                                                              each_item=True,
                                                              check_fields=False,
                                                              )(check_predefined_values)

        # Add validators for agreement checks in the end:
        validators.update(
            {
                # 'check_curated_marker_absent': validator('curated_marker_absent',
                #                                          allow_reuse=True,
                #                                          check_fields=False)(check_curated_marker_absent),
                'check_cell_ontology_type_agreement': validator('curated_cell_ontology_id',
                                                                allow_reuse=True,
                                                                check_fields=False,
                                                                each_item=True)(check_cell_ontology_type_agreement),
                'check_cell_line_disease_agreement': validator('curated_cell_line',
                                                               allow_reuse=True,
                                                               check_fields=True)(check_cell_line_disease_agreement)
                # Todo: To be implemented.
                # ,
                # 'check_cell_line_organism_agreement': validator('curated_cell_line',
                #                                                 allow_reuse=True,
                #                                                 check_fields=False)(
                #     check_cell_line_organism_agreement(dataset_id_organism_dict=dataset_id_organism_dict))
            }
        )
        schema_with_validator = build_validation_schema(schema_dict, for_level='sample', validators=validators)
        return schema, schema_with_validator
    except Exception as exc:
        print(tb.format_exc())
        print_exception()
        return None, None
