import json
import pathlib
import traceback as tb
from appdirs import user_config_dir

from polly_validator.config import CONFIG
from polly_validator.utility.helper import get_data_types_data_sources

ROOT_DIR = pathlib.Path(__file__).parent

SAMPLE_LEVEL_FIELD_SPECIFIC_DEFAULT_VALUES = CONFIG.get('sample_level_field_specific_default_values')
SAMPLE_LEVEL_FIELD_SPECIFIC_PROHIBITED_VALUES = CONFIG.get('sample_level_field_specific_prohibited_values')


REPO_WISE_RUN_CONFIG = CONFIG.get('repo_wise_run_config')

# Repos to carry out validation for
REPOS_FOR_DATASET_LEVEL_VALIDATION = REPO_WISE_RUN_CONFIG.get('repos_for_dataset_level_validation')
REPOS_FOR_SAMPLE_LEVEL_VALIDATION = REPO_WISE_RUN_CONFIG.get('repos_for_sample_level_validation')

# Schema to carry out validation
SCHEMAS_FOR_DATASET_LEVEL_VALIDATION = REPO_WISE_RUN_CONFIG.get('schemas_for_dataset_level_validation')
SCHEMAS_FOR_SAMPLE_LEVEL_VALIDATION = REPO_WISE_RUN_CONFIG.get('schemas_for_sample_level_validation')

# Chunk size config
SAMPLE_METADATA_QUERY_CHUNK_SIZE = REPO_WISE_RUN_CONFIG.get('sample_metadata_query_chunk_size', 50)
DATASET_LEVEL_ERROR_COLLECTION_CHUNK_SIZE = REPO_WISE_RUN_CONFIG.get('dataset_level_error_collection_chunk_size', 10000)
SAMPLE_LEVEL_ERROR_COLLECTION_CHUNK_SIZE = REPO_WISE_RUN_CONFIG.get('sample_level_error_collection_chunk_size', 100000)

# DB Name
DB_NAME = REPO_WISE_RUN_CONFIG.get('job_details').get('env').get('DB_NAME')

# Declare table names
DATASET_ERRORS_TABLE = REPO_WISE_RUN_CONFIG.get('dataset_errors_table_name', 'Dataset_Errors')
SAMPLE_ERRORS_TABLE = REPO_WISE_RUN_CONFIG.get('sample_errors_table_name', 'Sample_Errors')

# Flags for which validation to run
RUN_DATASET_LEVEL_VALIDATIONS = REPO_WISE_RUN_CONFIG.get('run_dataset_level_validations', True)
RUN_SAMPLE_LEVEL_VALIDATIONS = REPO_WISE_RUN_CONFIG.get('run_sample_level_validations', True)

# Dataset IDs to run it for
DATASET_ID_LIST = REPO_WISE_RUN_CONFIG.get('dataset_id_list')

# Field mapping for referring to when using valid_names.json
FIELD_MAPPING = {'tissue': 'tissue',
                 'curated_tissue': 'tissue',
                 'kw_curated_tissue': 'tissue',

                 'kw_cell_type': 'cell_type',
                 'curated_cell_type': 'cell_type',
                 'kw_curated_cell_type': 'cell_type',
                 'curated_cell_ontology_id': 'cell_type',

                 'kw_cell_line': 'cell_line',
                 'curated_cell_line': 'cell_line',
                 'kw_curated_cell_line': 'cell_line',

                 'disease': 'disease',
                 'curated_disease': 'disease',
                 'kw_curated_disease': 'disease',

                 'kw_drug': 'drug',
                 'curated_drug': 'drug',
                 'kw_curated_drug': 'drug',

                 'organism': 'organism',
                 'curated_organism': 'organism',
                 'kw_curated_organism': 'organism',

                 'gene': 'gene',
                 'curated_gene': 'gene',
                 'kw_curated_gene': 'gene',

                 'kw_data_type': 'data_type',
                 'data_type': 'data_type',
                 }

try:
    with open(pathlib.Path(user_config_dir()) / 'polly-validator' / 'valid_names.json', 'r') as fp:
        VALID_NAMES = json.load(fp)
    print('Getting predefined values for Data Type and Data Source...')
    VALID_NAMES['data_type'], VALID_NAMES['dataset_source'] = get_data_types_data_sources()
except Exception as exc:
    print(f'Exception when receiving data types and sources: {exc}')
    print(tb.format_exc())
    exception_type, exception_object, exception_traceback = sys.exc_info()
    filename = exception_traceback.tb_frame.f_code.co_filename
    line_number = exception_traceback.tb_lineno
    print("Exception type: ", exception_type)
    print("File name: ", filename)
    print("Line number: ", line_number)

#Dataset level allowed default values dictionary
DATASET_LEVEL_FIELD_SPECIFIC_DEFAULT_VALUES = CONFIG.get('dataset_level_field_specific_default_values')

#Dataset level dictionary for values that are not allowed
DATASET_LEVEL_FIELD_SPECIFIC_NOT_ALLOWED_VALUES = CONFIG.get('dataset_level_field_specific_not_allowed_values')

#Dataset level dictionary for fields other than ontological fields which have controlled vocabulary
DATASET_LEVEL_CONTROLLED_VOCABULARY_ALL_VALUES = CONFIG.get('dataset_level_controlled_vocabulary_all_values')

#Sample level dictionary for fields other than ontological fields which have controlled vocabulary
SAMPLE_LEVEL_CONTROLLED_VOCABULARY_ALL_VALUES = CONFIG.get('sample_level_controlled_vocabulary_all_values')

#Data type
DATA_TYPE = CONFIG.get('data_type')