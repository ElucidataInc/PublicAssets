"""
Configure the repo-wide run as follows:
"""
import os
import traceback as tb
from pprint import pprint

from polly_validator.utility.helper import print_exception

try:
    environ_dict = dict(os.environ)
    docker_image_tag = environ_dict['docker_image_tag']
    db_file_name = environ_dict['DB_NAME']
    AUTH_KEY = os.environ['AUTH_KEY']
    run_dataset_level_validations = eval(environ_dict['run_dataset_level_validations'])
    run_sample_level_validations = eval(environ_dict['run_sample_level_validations'])
    repos_for_dataset_level_validation = eval(environ_dict['repos_for_dataset_level_validation'])
    repos_for_sample_level_validation = eval(environ_dict['repos_for_sample_level_validation'])
    # schemas_for_dataset_level_validation = eval(environ_dict['schemas_for_dataset_level_validation'])
    # schemas_for_sample_level_validation = eval(environ_dict['schemas_for_sample_level_validation'])
    dataset_id_list = eval(environ_dict['dataset_id_list'])
    data_type=environ_dict['data_type']

except Exception as e:
    print(tb.format_exc())
    print_exception()


"""
Step 4: Provide allowed default values, prohibited values and any other controlled vocabulary
"""
# set allowed default vals dict for fields
dataset_level_field_specific_default_values = {
    'curated_cell_line': ['none'],
    'curated_cell_ontology_id': ['none'],
    'curated_cell_type': ['none'],
    'curated_disease': ['Normal'],
    'curated_drug': ['none'],
    'curated_gene': ['none'],
    'abstract': ['Not available'],
    'curated_tissue': ['none']
}
sample_level_field_specific_default_values = {
    'curated_cell_line': ['none'],
    'curated_cell_ontology_id': ['none'],
    'curated_cell_type': ['none'],
    'curated_disease': ['Normal'],
    'curated_drug': ['none'],
    'curated_gene': ['none'],
    'curated_tissue': ['none']
}

# set default values that are not allowed
dataset_level_field_specific_not_allowed_values = {
    'curated_single_cell_chemistry': ['None', 'Not available', 'not available'],
    'publication': ['Not available', 'not available'],
    'abstract': ['None', 'none'],
    'description': ['None', 'none'],
    'summary': ['None', 'none'],
    'overall_design': ['None', 'none'],
    'dataset_id': ['None', 'none']
}
sample_level_field_specific_prohibited_values = {
    'sample_id': ['none', 'None'],
    'cell_id': ['none', 'None'],
    'curated_marker_present': [ 'None'],
    'curated_disease': ['none', 'None'],
    
}

# set all allowed values for fields with controlled vocabulary, leave empty {} if there are no such fields
dataset_level_controlled_vocabulary_all_values = {
    'raw_counts_available': ['True', 'False'],
    'celltype_annotation_available': ['True', 'False', 'Not Curatable'],
    'curated_dataset_has_donor':['True','False'],
    'ref_gene_annotations':['Ensembl release V107','Ensembl release V90'],
    'reference_genome':['rnor_6.0','GRCm39','GRCh38','GRCm38','GRCh37','mRatBN7.2']


}

sample_level_controlled_vocabulary_all_values ={
    'curated_marker_absent' : ['none','not_available'],
    'curated_is_control':[1,0],
     'curated_genetic_modification_type':['Wildtype','Knockout','Knockin','Knockdown','Mutation','Overexpression',
                                         'Transgenic','none']

    
}
"""
Step 5: Provide the list of dataset IDs you want to run the error 
collection on (can be all dataset IDs in an entire repo, or some selected few)
"""
# dataset_id_list = [
#
# ]

"""Adjustable parameters for chunk sizes:"""
sample_metadata_query_chunk_size = 50
dataset_level_error_collection_chunk_size = 100000
sample_level_error_collection_chunk_size = 100000

CONFIG = {
    "repo_wise_run_config": {
        "run_dataset_level_validations": run_dataset_level_validations,
        "run_sample_level_validations": run_sample_level_validations,
        "sample_metadata_query_chunk_size": sample_metadata_query_chunk_size,
        "dataset_level_error_collection_chunk_size": dataset_level_error_collection_chunk_size,
        "sample_level_error_collection_chunk_size": sample_level_error_collection_chunk_size,

        "repos_for_dataset_level_validation": repos_for_dataset_level_validation,
        # "schemas_for_dataset_level_validation": schemas_for_dataset_level_validation,
        "repos_for_sample_level_validation": repos_for_sample_level_validation,
        # "schemas_for_sample_level_validation": schemas_for_sample_level_validation,
        "dataset_errors_table_name": "DatasetLevelErrors",
        "sample_errors_table_name": "SampleLevelErrors",
        "dataset_id_list": dataset_id_list,
        "job_details": {
            "image": "docker.polly.elucidata.io/elucidatarnd/qa_repo",
            "tag": f"{docker_image_tag}",
            "machineType": "mi5xlarge",
            "timelimit": 100,
            "env": {
                "PROJECT_DIR": "polly_validator",
                "DB_NAME": f"{db_file_name}"
            },
            "name": "QA Validation Error Collection",
            "secret_env": {
                "AUTH_KEY": AUTH_KEY
            }
        }
    },
    "sample_level_controlled_vocabulary_all_values": sample_level_controlled_vocabulary_all_values,
    "sample_level_field_specific_default_values": sample_level_field_specific_default_values,
    "sample_level_field_specific_prohibited_values": sample_level_field_specific_prohibited_values,
    "last_commit_for_obo_ontology_files": "396a727",
    "last_commit_for_compressed_ontology_files": "feff3be",
    "dataset_level_field_specific_default_values": dataset_level_field_specific_default_values,
    "dataset_level_field_specific_not_allowed_values": dataset_level_field_specific_not_allowed_values,
    "dataset_level_controlled_vocabulary_all_values": dataset_level_controlled_vocabulary_all_values,
    "last_commit_for_gene_names_file": "4e15754",
    "last_commit_for_drug_ontology_files": "1cd614f",
    "data_type": data_type
}
