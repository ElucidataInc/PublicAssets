import json
import re
import sys
import traceback as tb
from collections import defaultdict
from pathlib import Path

import pandas as pd
import pronto as pt
from appdirs import user_config_dir
from polly_validator.config import CONFIG

LATEST_COMMIT_FOR_OBO_ONTOLOGY_FILES = CONFIG.get('last_commit_for_obo_ontology_files', 'master')
LATEST_COMMIT_FOR_COMPRESSED_ONTOLOGY_FILES = CONFIG.get('last_commit_for_compressed_ontology_files', 'master')
LATEST_COMMIT_FOR_GENE_NAMES = CONFIG.get('last_commit_for_gene_names_file', 'master')
LATEST_COMMIT_FOR_DRUG_ONTOLOGY = CONFIG.get('last_commit_for_drug_ontology_files', 'master')

folder_path = Path(Path(user_config_dir()) / 'polly-validator')


class SetEncoder(json.JSONEncoder):
    """
    Encoder class to convert set to list when writing to file from a JSON object.
    """

    def default(self, obj):
        if isinstance(obj, set):
            return list(obj)
        return json.JSONEncoder.default(self, obj)


def collect_valid_names():
    """
    Function to gather information from ontological files and save it as a JSON file locally
    Returns:

    """
    try:
        search_for_disease, search_for_organism = 'MESH', 'NCBITaxon'
        print('Retrieving ontological names...')

        tissues = pt.Ontology(f'https://raw.githubusercontent.com/bioinfo-el/ontologies/'
                              f'{LATEST_COMMIT_FOR_OBO_ONTOLOGY_FILES}/obo/tissue.obo')

        cell_types = pt.Ontology(f'https://raw.githubusercontent.com/bioinfo-el/ontologies/'
                                 f'{LATEST_COMMIT_FOR_OBO_ONTOLOGY_FILES}/obo/cell_type.obo')

        cell_line = pt.Ontology(f'https://raw.githubusercontent.com/bioinfo-el/ontologies/'
                                f'{LATEST_COMMIT_FOR_OBO_ONTOLOGY_FILES}/obo/cell_line.obo')

        drug_df = pd.read_json(f'https://media.githubusercontent.com/media/bioinfo-el/ontologies/'
                                f'{LATEST_COMMIT_FOR_DRUG_ONTOLOGY}/json/drug_onto.json')

        diseases = pt.Ontology(f'https://raw.githubusercontent.com/bioinfo-el/ontologies/'
                               f'{LATEST_COMMIT_FOR_OBO_ONTOLOGY_FILES}/obo/disease.obo')

        gene_names_df = pd.read_json(f'https://raw.githubusercontent.com/bioinfo-el/'
                                     f'ontologies/{LATEST_COMMIT_FOR_GENE_NAMES}/json/hgnc-slim.json.gz')

        organism_df = pd.read_csv(f'https://github.com/bioinfo-el/ontologies/blob/'
                                  f'{LATEST_COMMIT_FOR_COMPRESSED_ONTOLOGY_FILES}/compressed/organism.xz?raw=true',
                                  sep='|',
                                  compression='xz')

        all_names = {
            'tissue': set(),
            'cell_type': dict(),
            'cell_line': dict(),
            'disease': set(),
            'drug': set(),
            'organism': set(),
            'gene': set()
        }

        for term in tissues.terms():
            """Specific check for tissue"""
            if 'tissue' in term.subsets:
                all_names['tissue'].add(term.name)

        for term in diseases.terms():
            all_names['disease'].add(term.name)
        
        all_names['drug'] = set(drug_df['name'].to_list())

        all_names['gene'] = set(gene_names_df['name'].to_list())

        all_names['organism'] = set(organism_df['root'])

        """Creating mapping between Cell Lines and Diseases and Cell Lines and Organisms..."""
        cell_line_disease_dict = defaultdict(set)
        cell_line_organism_dict = defaultdict(set)
        valid_cell_line_names = []
        for term in cell_line.terms():
            valid_cell_line_names.append(term.name)
            search_res_disease = [item.description for item in term.xrefs if re.search(search_for_disease, item.id)]
            search_res_organism = [item.description for item in term.xrefs if re.search(search_for_organism, item.id)]
            if search_res_disease:
                cell_line_disease_dict[search_res_disease[0]].add(term.name)
            if search_res_organism:
                cell_line_organism_dict[search_res_organism[0]].add(term.name)

        all_names['cell_line'] = {
            'valid_cell_line_names': valid_cell_line_names,
            'organism': cell_line_organism_dict,
            'disease': cell_line_disease_dict,
        }

        """Creating mapping between Cell ids and Cell Types..."""
        concordance_id_type_dict = {
            term.name: term.id for term in cell_types.terms()
        }

        valid_cell_type_names = []
        valid_cell_ontology_ids = []
        for term in cell_types.terms():
            valid_cell_type_names.append(term.name)
            valid_cell_ontology_ids.append(term.id)
        all_names['cell_type'] = {
            'valid_cell_type_names': valid_cell_type_names,
            'valid_cell_ontology_ids': valid_cell_ontology_ids,
            'concordance_id_type_dict': concordance_id_type_dict
        }

        print(f'Saving a JSON file at:{folder_path}')
        with open(folder_path / 'valid_names.json', 'w+') as openfile:
            json.dump(all_names, openfile, cls=SetEncoder, indent=4)
    except Exception as e:
        print(tb.format_exc())
        exception_type, exception_object, exception_traceback = sys.exc_info()
        filename = exception_traceback.tb_frame.f_code.co_filename
        line_number = exception_traceback.tb_lineno
        print("Exception type: ", exception_type)
        print("File name: ", filename)
        print("Line number: ", line_number)
