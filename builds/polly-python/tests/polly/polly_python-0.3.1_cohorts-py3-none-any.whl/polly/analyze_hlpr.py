from polly.errors import paramException

def check_params_for_cohorts(repo_key, dataset_id):
    """
    Args:
        repo_key(str): repo_name/repo_id of the repository.
        dataset_id(str): dataset_id of the dataset.
    """
    if not (repo_key and (isinstance(repo_key, str) or isinstance(repo_key, int))):
        raise paramException(
            title="Param Error",
            detail="Argument 'repo_key' is either empty or invalid. \
It should either be a string or an integer. Please try again.",
        )
    if not (dataset_id and isinstance(dataset_id, str)):
        raise paramException(
            title="Param Error",
            detail="Argument 'dataset_id' is either empty or invalid. It should be a string. Please try again.",
        )