import json
from collections import namedtuple
from typing import Optional, List
from polly.errors import (
    InvalidSchemaJsonException,
    InvalidSyntaxForRequestException,
    EmptyPayloadException,
    RequestException,
    UnauthorizedException,
    extract_json_api_error,
)
from polly.auth import Polly
from polly import helpers, constants as const, application_error_info as app_err_info
from polly.help import example, doc
import polly.http_response_codes as http_codes
from polly.constants import SUPPORTED_ENTITY_TYPES


class CurationLibrary:
    """
    The CurationLibrary class contains wrapper functions around the models used for
    semantic annotations of string/text

    ``Args:``
        |  ``token (str):`` token copy from polly.

    .. code::


            from polly.curation_library import CurationLibrary
            # To use this class initialize a object like this if you are not authorised on polly
            curationLibObj = CurationLibrary(token)

    If you are authorised then you can initialize object without token to know about :ref:`authentication <auth>`.
    """

    Tag = namedtuple("Tag", ["name", "ontology_id", "entity_type"])
    example = classmethod(example)
    doc = classmethod(doc)

    def __init__(
        self,
        token=None,
        env="",
        default_env="polly",
    ) -> None:
        # check if COMPUTE_ENV_VARIABLE present or not
        # if COMPUTE_ENV_VARIABLE, give priority
        env = helpers.get_platform_value_from_env(
            const.COMPUTE_ENV_VARIABLE, default_env, env
        )
        self.session = Polly.get_session(token, env=env)
        self.base_url = f"https://v2.api.{self.session.env}.elucidata.io"
        self.discover_url = f"https://api.discover.{self.session.env}.elucidata.io"
        self.elastic_url = (
            f"https://api.datalake.discover.{self.session.env}.elucidata.io/elastic/v2"
        )
        self.inference_url = f"https://api.discover.{self.session.env}.elucidata.io/curations/inferences/"

    def _handle_errors(self, response):
        detail = response.get("errors")[0].get("detail", [])
        title = response.get("errors")[0].get("title", [])
        return title, detail

    def _perform_inference(
        self,
        model_name: str,
        input_data: dict,
    ) -> dict:
        """
        This is a wrapper around model inference APIs
        It serializes input_data, calls the API for the given model_name and returns deserialized output

        Args:
            model_name (str): one of 'normalizer', 'biobert' and 'control-perturbation'
            input_data (dict): model input

        Returns:
            dict
        """
        url = self.inference_url + model_name

        payload = {}
        payload = json.dumps({"data": {"attributes": input_data, "type": "curation"}})
        response = self.session.post(url, data=payload)
        if response.status_code != 201:
            if response.status_code == http_codes.UNAUTHORIZED:
                raise UnauthorizedException("User is unauthorized to access this")
            elif response.status_code == http_codes.BAD_REQUEST:
                title, details = extract_json_api_error(response)
                if title == app_err_info.EMPTY_PAYLOAD_CODE:
                    raise EmptyPayloadException()
                elif app_err_info.INVALID_MODEL_NAME_TITLE in title:
                    raise InvalidSyntaxForRequestException()
            elif response.status_code == http_codes.INTERNAL_SERVER_ERROR:
                raise InvalidSchemaJsonException()
            else:
                title, details = extract_json_api_error(response)
                raise Exception("Exception Occurred :" + str(details))
        try:
            response = response.json()
        except json.JSONDecodeError as e:
            raise e
        if "data" in response:
            return response.get("data")
        return response

    def harmonize(
        self,
        mention: str,
        entity_type: str,
        context: Optional[str] = None,
        threshold: Optional[float] = None,
    ) -> dict:
        """Map a given mention (keyword) to an ontology term.

        Args:
            mention (str): mention of an entity e.g. "Cadiac arrythmia"
            entity_type (str): Should be one of ['disease', 'drug', 'tissue', 'cell_type', 'cell_line', 'species', 'gene']

        Kwargs:
            context (Optional[str]): The text where the mention occurs. This is used to resolve abbreviations

        Returns:
            dict

        """
        data = {
            "mention": {
                "keyword": mention,
                "entity_type": entity_type,
                "threshold": threshold,
            }
        }

        if context:
            data["context"] = context
        output = self._perform_inference("normalizer", data)
        if output.get("errors", []):
            title, detail = self._handle_errors(output)
            raise RequestException(title, detail)

        if "term" not in output:
            return {
                "ontology": "CUI-less",
                "ontology_id": None,
                "name": None,
                "entity_type": entity_type,
            }

        return output.get("term", [])

    def run_ner(
        self,
        text: str,
        threshold: Optional[float] = None,
        normalize_output: bool = False,
    ):
        """Run an NER model on the given text. The returned value is a list of entities along with span info.

        Args:
            text (str): input text

        Kwargs:
            normalize_output (bool): whether to normalize the keywords

        Returns:
            entities (List[dict]): returns a list of spans,
            each span contains the keyword, start and end index of the keyword and the entity type
        """
        # TODO: If text is too long, break it up into chunks small enough for biobert

        payload = {"text": text}
        if threshold:
            payload["threshold"] = threshold
        response = self._perform_inference("biobert", payload)

        if "errors" in response:
            title, detail = self._handle_errors(response)
            raise RequestException(title, detail)
        try:
            entities = response.get("entities", [])
        except KeyError as e:
            raise e

        # TODO: fetch this list from the server maybe?

        if normalize_output:
            for entity in entities:

                # don't call `normalize` for unsupported entity types
                if entity.get("entity_type") not in SUPPORTED_ENTITY_TYPES:
                    entity["name"] = None
                    continue
                norm = self.harmonize(entity["keyword"], entity["entity_type"], text)
                if norm.get("ontology", []) == "CUI-less":
                    entity["name"] = None
                else:
                    entity["ontology_id"] = norm["ontology"] + ":" + norm["ontology_id"]
                    entity["name"] = norm["name"]
        return entities

    def semantic_annotation(
        self,
        text: str,
    ) -> List[Tag]:

        """
        Tag a given piece of text. A "tag" is just an ontology term.

        This function calls `run_ner` followed by `normalize`

        Args:
            text (str): Input text

        Returns:
            tags (set of tuples): set of unique tags
        """

        entities = self.run_ner(text, normalize_output=True)
        res = {
            self.Tag(
                e.get("name", []), e.get("ontology_id", []), e.get("entity_type", [])
            )
            for e in entities
            if e.get("name")
        }
        return list(res)
