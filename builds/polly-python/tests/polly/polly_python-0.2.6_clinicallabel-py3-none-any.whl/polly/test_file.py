#!/usr/bin/env python3

def inner_function(a:str):
    try:
        x = 1/0
    except Exception as err:
        print("EEEEEEE")
        raise err
        #return err

def main():
    try:
        for i in range(1,10,1):
            inner_function("abc")
    except Exception as err:
        print ("ac,hfbkvyuafv")
        #print(err)
        #raise err

    #inner_function("abc")
if __name__ == "__main__":
    main()


from io import StringIO 
import sys
import inspect

class Capturing(list):
    def __enter__(self):
        self._stdout = sys.stdout
        sys.stdout = self._stringio = StringIO()
        return self
    def __exit__(self, *args):
        self.extend(self._stringio.getvalue().splitlines())
        del self._stringio    # free up some memory
        sys.stdout = self._stdout

def test():
    valid_function =[]
    help_present_hai = []
    help_not_present = []
    for i in inspect.getmembers(omixatlas, predicate=inspect.ismethod):   # this is my condition list
        if not i[0].startswith("_"):# this is the mechanism to choose the right function
            #valid_function.append(i[0])
            result = help(i[1]);
        
docs_present_omixatlas = []
with Capturing() as output:
    test()
#print('output:', output)
for i in output: 
    if "Help on method" in i: 
        method = i.replace("Help on method","").split("in module")[0].strip()
        docs_present_omixatlas.append(method)
docs_present_omixatlas
#print(len(docs_present_omixatlas))

omixatlas_memebers = []
for i in inspect.getmembers(omixatlas, predicate=inspect.ismethod): 
    if not i[0].startswith("_"):
        omixatlas_memebers.append(i[0])
        print(i[0])
print(len(omixatlas_memebers))

______________

def test(class_name):
    '''
    fucntion which will call the help on the members of the class
    '''
    valid_function =[]
    help_present_hai = []
    help_not_present = []
    for i in inspect.getmembers(class_name, predicate=inspect.ismethod):   # this is my condition list
        if not i[0].startswith("_"):# this is the mechanism to choose the right function
            #valid_function.append(i[0])
            result = help(i[1])

for class_name in ["Polly","omixatlas","workspaces","cohort","curation","session"]: 
    print ("checking for class: " + class_name)
    class_members = []
    for i in inspect.getmembers(class_name, predicate=inspect.ismethod): 
        if not i[0].startswith("_"):
            class_members.append(i[0])

    docs_present_omixatlas = []
    with Capturing() as output:
        test(class_name=class_name)
    #print('output:', output)
        for i in output: 
            if "Help on method" in i: 
                method = i.replace("Help on method","").split("in module")[0].strip()
                docs_present_omixatlas.append(method)
    if len(docs_present_omixatlas) != len(class_members):
        print(f"ERROR FOR :{class_name}")
    
    










