from polly.auth import Polly
from polly.errors import (
    ResourceNotFoundError,
    BadRequestError,
    UnauthorizedException,
    InvalidParameterException,
    QueryFailedException,
)
from polly import helpers
from polly import constants as const
from polly.tracking import Track

import requests
import json
import os
import sys
from requests import Response
import time


def _is_timeout_error(e: Exception) -> bool:
    s = str(e).lower()
    return any(
        k in s
        for k in (
            "endpoint request timed out",
            "timed out",
            "timeout",
            "504",
            "gateway",
        )
    )


def _is_neo4j_transaction_timeout(e: Exception) -> bool:
    s = str(e).lower()
    return (
        "transactiontimedoutclientconfiguration" in s
        or "transaction has been terminated" in s
    )


def _fmt_elapsed(seconds: int) -> str:
    if seconds < 60:
        return f"{seconds}s"
    return f"{seconds // 60}m {seconds % 60}s"


def _print_progress(msg: str, newline: bool = False) -> None:
    """Print a progress message, overwriting the current line in a TTY."""
    if sys.stdout.isatty():
        end = "\n" if newline else ""
        print(f"\r{msg}".ljust(60), end=end, flush=True)
    else:
        print(msg, flush=True)


def get_error_message(response: Response):
    """Helper function to extract error message from response"""
    if "errors" in response.json():
        errors = response.json()["errors"]
        if isinstance(errors, list) and errors:
            return errors[0].get("detail", "Unknown error")
        return errors or "Unknown error"
    return "Unknown error"


def handle_success_and_error_response(response: Response):
    error_message = "Unknown error"

    if response.status_code in [200, 201]:
        return response.json()

    if response.status_code == 204:
        return None

    if response.status_code == 401:
        raise UnauthorizedException()

    error_message = get_error_message(response)

    if response.status_code == 400:
        raise BadRequestError(detail=error_message)
    elif response.status_code == 404:
        raise ResourceNotFoundError(detail=error_message)
    elif response.status_code == 409:
        raise Exception(f"Conflict: {error_message}")

    if int(response.status_code) >= 500:
        raise Exception(f"Server error: {error_message}")

    response.raise_for_status()


def _get_latest_version_kg(session, polly_kg_neo4j_endpoint, kg_id):
    """Get the latest version of the knowledge graph with the specified kg_id.

    Args:
        session: The authenticated session to make requests.
        polly_kg_neo4j_endpoint: The endpoint for the Polly Knowledge Graph API.
        kg_id (str): The ID of the knowledge graph.

    Returns:
        tuple: A tuple containing the kg_id and version_id of the latest version.

    Raises:
        ResourceNotFoundError: If no knowledge graph with the specified kg_id is found.
    """
    response = session.get(f"{polly_kg_neo4j_endpoint}/kg/{kg_id}")
    handle_success_and_error_response(response)
    data = response.json().get("data", {})
    if not data:
        raise ResourceNotFoundError(
            detail=f"No knowledge graph with ID '{kg_id}' found."
        )
    latest_version = data.get("attributes", {})
    version_id = latest_version.get("version_id")
    if version_id is None:
        raise InvalidParameterException(
            f"Knowledge graph with ID '{kg_id}' is missing version_id in the API response."
        )
    return kg_id, version_id


def _get_default_kg(session, polly_kg_neo4j_endpoint):
    kg_url = f"{polly_kg_neo4j_endpoint}/kg"
    response = session.get(kg_url)
    handle_success_and_error_response(response)
    data = response.json().get("data", [])
    if not data:
        raise ResourceNotFoundError(detail="No knowledge graphs found.")
    if len(data) > 1:
        kg_ids = {kg.get("kg_id") for kg in data}
        if len(kg_ids) == 1:
            return _get_latest_version_kg(
                session, polly_kg_neo4j_endpoint, kg_ids.pop()
            )
        else:
            raise BadRequestError(
                detail="Multiple knowledge graphs found for the given org. Please specify a kg_id and version_id."
            )
    default_kg = data[0]
    latest_kg_response = session.get(
        f"{polly_kg_neo4j_endpoint}/kg/{default_kg.get('kg_id')}"
    )
    handle_success_and_error_response(latest_kg_response)
    latest_kg = latest_kg_response.json().get("data", {}).get("attributes", {})

    return (
        latest_kg.get("kg_id"),
        latest_kg.get("version_id"),
    )


def _print_kg_disambiguation_table(kg_name, matches):
    """Print a table of KGs to help the user disambiguate."""
    print(
        f"\nMultiple KGs found with name '{kg_name}'. "
        "Please re-initialize with kg_id and version_id:\n"
    )
    print(f"  {'kg_id':<45} {'version_id':<12} description")
    print(f"  {'-'*45} {'-'*12} {'-'*30}")
    for kg in matches:
        desc = (kg.get("kg_description") or "")[:30]
        print(f"  {kg.get('kg_id', ''):<45} {str(kg.get('version_id', '')):<12} {desc}")


def _resolve_kg_by_name(session, polly_kg_neo4j_endpoint, kg_name, data_version=None):
    """Resolve kg_id and version_id from a human-readable kg_name and optional data_version.

    Args:
        session: The authenticated session to make requests.
        polly_kg_neo4j_endpoint: The endpoint for the Polly Knowledge Graph API.
        kg_name (str): The name of the knowledge graph (case-insensitive).
        data_version (str, optional): Data version string (e.g. "2.6") matched against
            the start of each KG's description field using startswith. If None, the latest
            version is used.

    Returns:
        tuple: (kg_id, version_id)

    Raises:
        ResourceNotFoundError: If no KG with the given name (and data_version) is found,
            or if the API returns no data at all.
        BadRequestError: If multiple distinct KGs cannot be narrowed to a single result.
        InvalidParameterException: If resolved kg_id or version_id is missing from the
            API response.
    """
    response = session.get(f"{polly_kg_neo4j_endpoint}/kg")
    handle_success_and_error_response(response)
    all_kgs = response.json().get("data", [])

    if not all_kgs:
        raise ResourceNotFoundError(
            detail="No knowledge graphs found in your organisation."
        )

    name_matches = [
        kg for kg in all_kgs if kg.get("kg_name", "").lower() == kg_name.lower()
    ]

    if not name_matches:
        raise ResourceNotFoundError(
            detail=f"No knowledge graph named '{kg_name}' found."
        )

    if data_version is not None:
        normalized = data_version.strip().lstrip("vV").lower()
        version_matches = [
            kg
            for kg in name_matches
            if (kg.get("kg_description") or "")
            .strip()
            .lstrip("vV")
            .lower()
            .startswith(normalized)
        ]
        if not version_matches:
            raise ResourceNotFoundError(
                detail=(
                    f"No knowledge graph named '{kg_name}' with data version "
                    f"'{data_version}' found."
                )
            )
        if len(version_matches) > 1:
            _print_kg_disambiguation_table(kg_name, version_matches)
            raise BadRequestError(
                detail=(
                    f"Multiple KGs match name '{kg_name}' and data version "
                    f"'{data_version}'. Please specify kg_id and version_id explicitly."
                )
            )
        kg = version_matches[0]
        resolved_kg_id = kg.get("kg_id")
        resolved_version_id = kg.get("version_id")
        if not resolved_kg_id or resolved_version_id is None:
            raise InvalidParameterException(
                f"KG named '{kg_name}' with data version '{data_version}' is missing "
                "required fields (kg_id or version_id) in the API response."
            )
        return resolved_kg_id, resolved_version_id

    unique_kg_ids = {kg.get("kg_id") for kg in name_matches}
    if len(unique_kg_ids) > 1:
        _print_kg_disambiguation_table(kg_name, name_matches)
        raise BadRequestError(
            detail=(
                f"Multiple knowledge graphs found with name '{kg_name}'. "
                "Please specify kg_id and version_id explicitly."
            )
        )

    # Single unique kg_id — warn if multiple versions exist, then pick latest
    if len(name_matches) > 1:
        print(
            f"\nMultiple versions found for KG '{kg_name}'. "
            "Selecting the latest version automatically. "
            "Use data_version to pin a specific version.\n"
        )

    resolved_kg_id, resolved_version_id = _get_latest_version_kg(
        session, polly_kg_neo4j_endpoint, unique_kg_ids.pop()
    )
    if not resolved_kg_id or resolved_version_id is None:
        raise InvalidParameterException(
            f"KG named '{kg_name}' is missing required fields (kg_id or version_id) "
            "in the API response."
        )
    return resolved_kg_id, resolved_version_id


def _validate_kg_init_params(kg_name, kg_id, version_id, data_version):
    """Validate the parameter combinations passed to PollyKG.__init__."""
    if kg_name is not None and (not isinstance(kg_name, str) or not kg_name.strip()):
        raise InvalidParameterException("kg_name must be a non-empty string.")

    if data_version is not None and (
        not isinstance(data_version, str) or not data_version.strip()
    ):
        raise InvalidParameterException(
            "data_version must be a non-empty string (e.g. '2.6')."
        )

    if data_version is not None and kg_name is None:
        raise InvalidParameterException(
            "data_version requires kg_name to be specified."
        )

    if kg_name is not None and kg_id is not None:
        raise InvalidParameterException(
            "kg_name and kg_id cannot both be specified. Use one or the other."
        )

    if kg_name is not None and version_id is not None:
        raise InvalidParameterException(
            "version_id cannot be used with kg_name. Use data_version instead."
        )

    if kg_id is None and version_id is not None:
        raise InvalidParameterException("kg_id")


def _resolve_kg_init(session, polly_kg_neo4j_endpoint, kg_id, version_id, kg_name, data_version):
    """Resolve (kg_id, version_id) from whichever init parameters were provided."""
    if kg_name is not None:
        resolved_kg_id, resolved_version_id = _resolve_kg_by_name(
            session, polly_kg_neo4j_endpoint, kg_name.strip(), data_version
        )
        return _validate_kg_version_exists(
            session, polly_kg_neo4j_endpoint, resolved_kg_id, resolved_version_id
        )

    if kg_id is None and version_id is None:
        return _get_default_kg(session, polly_kg_neo4j_endpoint)

    if kg_id is not None and version_id is not None:
        return _validate_kg_version_exists(
            session, polly_kg_neo4j_endpoint, kg_id, version_id
        )

    # kg_id provided, version_id not — fetch latest then validate
    resolved_kg_id, resolved_version_id = _get_latest_version_kg(
        session, polly_kg_neo4j_endpoint, kg_id
    )
    return _validate_kg_version_exists(
        session, polly_kg_neo4j_endpoint, resolved_kg_id, resolved_version_id
    )


def _validate_kg_version_exists(session, polly_kg_neo4j_endpoint, kg_id, version_id):
    """Validate if the specified kg_id and version_id exist in the Polly Knowledge Graph.

    Args:
        session: The authenticated session to make requests.
        polly_kg_neo4j_endpoint: The endpoint for the Polly Knowledge Graph API.
        kg_id (str): The ID of the knowledge graph.
        version_id (str): The version ID of the knowledge graph.

    Returns:
        tuple: A tuple containing the kg_id and version_id if they exist.

    Raises:
        ResourceNotFoundError: If the specified kg_id or version_id does not exist.
    """
    response = session.get(
        f"{polly_kg_neo4j_endpoint}/kg/{kg_id}/versions/{version_id}"
    )
    handle_success_and_error_response(response)
    data = response.json().get("data", [])
    if not data:
        raise ResourceNotFoundError(
            detail=f"No knowledge graphs with ID '{kg_id}' and version '{version_id}' found."
        )
    return kg_id, version_id


class PollyKG:
    """The PollyKG class provides an interface to interact with the Polly Knowledge Graph (KG) API.\
     It enables users to execute and manage Cypher queries, retrieve node and relationship data,\
     and analyze graph structures efficiently. This class simplifies access to the KG engine, allowing seamless\
     querying and data exploration. It is designed for users who need to extract insights from complex graph-based datasets.

    Args:
        token (str): Authentication token from polly

    Usage:
        from polly.polly_kg import PollyKG

        kg = PollyKG(token)
    """

    def __init__(
        self,
        token=None,
        env="",
        default_env="polly",
        kg_id=None,
        version_id=None,
        kg_name=None,
        data_version=None,
    ) -> None:
        # Initialize a PollyKG instance.

        # Args:
        #     token (str, optional): Authentication token. Defaults to None.
        #     env (str, optional): Environment override. Defaults to "".
        #     default_env (str, optional): Default environment if not specified. Defaults to "polly".
        #     kg_id (str, optional): Knowledge graph ID. Defaults to None.
        #     version_id (str, optional): Internal version ID. Defaults to None.
        #     kg_name (str, optional): Human-readable KG name. Resolved to kg_id automatically.
        #     data_version (str, optional): Data version string (e.g. "2.6"), matched against
        #         the description field. Only valid with kg_name.

        env = helpers.get_platform_value_from_env(
            const.COMPUTE_ENV_VARIABLE, default_env, env
        )
        self.session = Polly.get_session(token, env=env)
        self.polly_kg_endpoint = (
            f"https://sarovar.{self.session.env}.elucidata.io/polly_kg"
        )
        self.polly_kg_neo4j_endpoint = (
            f"https://apis.{self.session.env}.elucidata.io/polly-kg"
        )

        _validate_kg_init_params(kg_name, kg_id, version_id, data_version)
        self.kg_id, self.version_id = _resolve_kg_init(
            self.session, self.polly_kg_neo4j_endpoint,
            kg_id, version_id, kg_name, data_version,
        )

    def __repr__(self):
        kg_id = getattr(self, "kg_id", None)
        version_id = getattr(self, "version_id", None)
        return f"PollyKG(kg_id={kg_id}, version_id={version_id})"

    def _extract_data(self, response_json: dict, error_msg: str) -> dict:
        """Extract and validate the data field from an API response."""
        data = response_json.get("data")
        if isinstance(data, list):
            data = data[0] if data else {}
        if not isinstance(data, dict):
            raise QueryFailedException(error_msg)
        return data

    def _check_poll_errors(self, response_json: dict) -> None:
        """Raise QueryFailedException if the poll response contains errors."""
        if "errors" not in response_json:
            return
        error = response_json["errors"][0]
        error_code = error.get("code")
        error_detail = error.get("detail", "Unknown error")
        if error_code == "resource_not_found":
            raise QueryFailedException(f"Query not found: {error_detail}")
        raise QueryFailedException(f"API Error [{error_code}]: {error_detail}")

    def _handle_failed_status(self, query_id: str, status_data: dict) -> None:
        """Extract error info from a FAILED status and raise QueryFailedException."""
        metadata = status_data.get("attributes", {}).get("metadata", {})
        results = metadata.get("results", {})
        if results and ("error" in results or "details" in results):
            error_type = results.get("error", "Unknown error")
            error_details = results.get("details", "")
            error_message = (
                f"{error_type}: {error_details}" if error_details else error_type
            )
        else:
            error_message = metadata.get(
                "error", "Query failed without a specific error message."
            )
        _print_progress(f"Query {query_id} failed: {error_message}", newline=True)
        raise QueryFailedException(error_message)

    def _poll_for_result(self, query_url: str, query_id: str) -> dict:
        """Poll the async query endpoint until COMPLETED or FAILED."""
        download_url = f"{query_url}{query_id}/results?download=true"
        start_time = time.time()

        while True:
            status_response = self.session.get(download_url)
            status_response_json = status_response.json()
            self._check_poll_errors(status_response_json)

            status_data = self._extract_data(
                status_response_json, "Unexpected status response format"
            )
            status = status_data.get("attributes", {}).get("status")

            if status == "COMPLETED":
                elapsed = int(time.time() - start_time)
                _print_progress(
                    f"Query {query_id} completed in {_fmt_elapsed(elapsed)}.",
                    newline=True,
                )
                result_s3_signed_url = (
                    status_data.get("attributes", {})
                    .get("metadata", {})
                    .get("results", {})
                    .get("url")
                )
                if not result_s3_signed_url:
                    raise QueryFailedException(
                        f"Query {query_id} completed but no result URL was returned."
                    )
                return requests.get(result_s3_signed_url).json()
            elif status == "FAILED":
                self._handle_failed_status(query_id, status_data)
            elif status in ("IN_PROGRESS", "QUEUED"):
                elapsed = int(time.time() - start_time)
                _print_progress(f"Query in progress... {_fmt_elapsed(elapsed)} elapsed")
                time.sleep(5)
            else:
                raise QueryFailedException(f"Unexpected query status: {status}")

    def _run_query_async(self, query_url: str, payload: dict) -> dict:
        """Handle asynchronous query execution with status polling."""
        query_response = self.session.post(query_url, data=json.dumps(payload))
        handle_success_and_error_response(query_response)

        data = self._extract_data(
            query_response.json(), "Unexpected query submission response format"
        )
        query_id = data.get("attributes", {}).get("query_id")
        if not query_id:
            raise QueryFailedException("Query submission did not return query_id")

        print(f"Query submitted. Query ID: {query_id}")
        return self._poll_for_result(query_url, query_id)

    def _run_query_sync(self, query_url: str, payload: dict) -> dict:
        """Handle synchronous query execution."""
        query_response = self.session.post(query_url, data=json.dumps(payload))
        if query_response.status_code == 413:
            raise QueryFailedException(
                "Query result is too large (exceeds 6MB limit). "
                "Try one of the following:\n"
                "  1. Limit your query results (e.g. add LIMIT 100 to your Cypher query).\n"
                "  2. Use run_query(query, async_query=True) to retrieve large results asynchronously.\n"
                "  3. For very large results, use submit_query(query, long_running=True) to submit the query "
                "and retrieve results later with get_query_results(query_id)."
            )
        handle_success_and_error_response(query_response)

        query_json = query_response.json()
        if "data" in query_json:
            return query_json["data"]
        elif "errors" in query_json:
            error_message = get_error_message(query_response)
            raise QueryFailedException(error_message)
        return query_json

    @Track.track_decorator
    def run_query(self, query: str, async_query: bool = False) -> dict:
        """
        Execute a graph query on the specified KG version.

        This function submits the query to Polly KG. For both sync and async modes,
        it waits until the query completes and returns the result.

        Args:
            query (str): The query string to be executed.
            async_query (bool): If True, uses async endpoint (long-running queries).
                               If False, uses sync endpoint (short queries).
        Returns:
            dict: Query result in parsed JSON format.

        Raises:
            InvalidParameterException: If query is empty.
            QueryFailedException: If query execution fails.
        """
        if not query or query == "":
            raise InvalidParameterException("query")

        # Try synchronous query first (if async_query is False)
        if not async_query:
            try:
                query_url = f"{self.polly_kg_neo4j_endpoint}/kg/{self.kg_id}/versions/{self.version_id}/synchronous-queries/"
                payload = {
                    "data": {
                        "type": "kg_query",
                        "attributes": {"query_string": query, "query_type": "CYPHER"},
                    }
                }
                return self._run_query_sync(query_url, payload)
            except Exception as e:
                if not _is_timeout_error(e):
                    raise
                print("Sync query timed out. Retrying as an async query...")

        # Fall back to async query; polls until COMPLETED or FAILED
        query_url = f"{self.polly_kg_neo4j_endpoint}/kg/{self.kg_id}/versions/{self.version_id}/queries/"
        payload = {
            "data": {
                "type": "kg_query",
                "attributes": {
                    "query_string": query,
                    "query_type": "CYPHER",
                    "long_running": False,
                },
            }
        }
        try:
            return self._run_query_async(query_url, payload)
        except QueryFailedException as e:
            if _is_neo4j_transaction_timeout(e):
                raise QueryFailedException(
                    "Query timed out. For long-running queries, use submit_query(query, long_running=True) "
                    "and retrieve results later with get_query_results(query_id)."
                ) from e
            raise

    @Track.track_decorator
    def submit_query(self, query: str, long_running: bool = False) -> dict:
        """
        Submit a graph query on the specified KG version.

        This function submits the query to Polly KG and returns the Query ID.

        Args:
            query (str): The query string to be executed.
            long_running (bool): If True, the query will be treated as long-running and can run for up to 48 hours.
                If False, the query is expected to complete within 10 minutes.

        Returns:
            query_id (str): Unique Identifier for the query submitted.

        Raises:
            InvalidParameterException: If query is empty.
            QueryFailedException: If query execution fails.
        """
        if not query or query == "":
            raise InvalidParameterException("query")
        query_url = f"{self.polly_kg_neo4j_endpoint}/kg/{self.kg_id}/versions/{self.version_id}/queries/"
        payload = {
            "data": {
                "type": "kg_query",
                "attributes": {
                    "query_string": query,
                    "query_type": "CYPHER",
                    "long_running": long_running,
                },
            }
        }
        try:
            query_response = self.session.post(query_url, data=json.dumps(payload))

            handle_success_and_error_response(query_response)

            data = query_response.json().get("data")
            return data.get("attributes", {}).get("query_id")
        except Exception as e:
            print(e)
            raise e

    @Track.track_decorator
    def get_query_status(self, query_id: str) -> dict:
        """
        Fetch the status of a  submitted query.

        Args:
            query_id (str): Unique ID of the submitted query.

        Returns:
            dict: A dictionary containing current status of the query (e.g., "IN_PROGRESS", "COMPLETED").

        Raises:
            InvalidParameterException: If query_id is not provided.
        """
        if not query_id or query_id == "":
            raise InvalidParameterException("query_id")
        query_url = f"{self.polly_kg_neo4j_endpoint}/kg/{self.kg_id}/versions/{self.version_id}/queries/{query_id}"
        try:
            response = self.session.get(query_url)
            handle_success_and_error_response(response)
            data = response.json().get("data", {})
            return {"status": data.get("attributes", {}).get("status")}
        except Exception as e:
            print(e)
            raise e

    @Track.track_decorator
    def get_query_results(self, query_id: str) -> None:
        """Get the results of a query by its ID.

        Args:
            query_id (str): The ID of the query whose results you want to get.

        Returns:
            dict: Query result in parsed JSON format.

        Raises:
            InvalidParameterException: If the query_id is empty or None.
            QueryFailedException: If query execution failed.
            RequestFailureException: If the request fails due to an unexpected error.

        """
        if not query_id or query_id == "":
            raise InvalidParameterException("query_id")
        base_url = f"{self.polly_kg_neo4j_endpoint}/kg/{self.kg_id}/versions/{self.version_id}/queries"
        query_url = f"{base_url}/{query_id}/results?download=true"
        try:
            response = self.session.get(query_url)
            handle_success_and_error_response(response)
            data = response.json().get("data", {})

            status = data.get("attributes", {}).get("status")
            if status == "FAILED":
                metadata = data.get("attributes", {}).get("metadata", {})
                # Try new format first: metadata.results.error and metadata.results.details
                results = metadata.get("results", {})
                if results and ("error" in results or "details" in results):
                    error_type = results.get("error", "Unknown error")
                    error_details = results.get("details", "")
                    error_message = (
                        f"{error_type}: {error_details}"
                        if error_details
                        else error_type
                    )
                else:
                    # Fallback to old format: metadata.error
                    error_message = metadata.get(
                        "error", "Query failed without a specific error message."
                    )

                print(f"Query failed. Query ID: {query_id}. Error: {error_message}")
                raise QueryFailedException(error_message)
            result_s3_signed_url = (
                data.get("attributes", {})
                .get("metadata", {})
                .get("results", {})
                .get("url")
            )
            if not result_s3_signed_url:
                raise ResourceNotFoundError("Query results not found.")

            result_json = requests.get(result_s3_signed_url)
            return result_json.json()
        except Exception as e:
            print(e)
            raise e

    @Track.track_decorator
    def download_query_results(self, query_id: str, folder: str = "./results") -> None:
        """Download the results of a query by its ID.
            If the download directory does not exist, it will be created.
            The results will be saved in a ./results directory/query_id.json with the filename as query_id.json.

        Args:
            query_id (str): The ID of the query whose results you want to download.
            folder (str): The directory where the results should be saved.

        Returns:
            str: Path to the downloaded results.

        Raises:
            InvalidParameterException: If the query_id is empty or None.
            QueryFailedException: If query execution failed.
            RequestFailureException: If the request fails due to an unexpected error.

        """
        if not query_id or query_id == "":
            raise InvalidParameterException("query_id")
        base_url = f"{self.polly_kg_neo4j_endpoint}/kg/{self.kg_id}/versions/{self.version_id}/queries"
        query_url = f"{base_url}/{query_id}/results?download=true"
        try:
            response = self.session.get(query_url)
            handle_success_and_error_response(response)
            data = response.json().get("data", {})

            status = data.get("attributes", {}).get("status")
            if status == "FAILED":
                metadata = data.get("attributes", {}).get("metadata", {})
                # Try new format first: metadata.results.error and metadata.results.details
                results = metadata.get("results", {})
                if results and ("error" in results or "details" in results):
                    error_type = results.get("error", "Unknown error")
                    error_details = results.get("details", "")
                    error_message = (
                        f"{error_type}: {error_details}"
                        if error_details
                        else error_type
                    )
                else:
                    # Fallback to old format: metadata.error
                    error_message = metadata.get(
                        "error", "Query failed without a specific error message."
                    )

                print(f"Query failed. Query ID: {query_id}. Error: {error_message}")
                raise QueryFailedException(error_message)
            result_s3_signed_url = (
                data.get("attributes", {})
                .get("metadata", {})
                .get("results", {})
                .get("url")
            )
            if not result_s3_signed_url:
                raise ResourceNotFoundError("Query results not found.")

            with requests.get(result_s3_signed_url, stream=True) as r:
                r.raise_for_status()
                os.makedirs(folder, exist_ok=True)
                file_path = os.path.join(folder, f"{query_id}.json")
                with open(file_path, "wb") as f:
                    for chunk in r.iter_content(chunk_size=1048576):
                        if chunk:
                            f.write(chunk)
            print(f"Results downloaded successfully to {file_path}")
            return file_path
        except Exception as e:
            print(e)
            raise

    def get_summary(self, stats: bool = False) -> dict:
        """Retrieve a summary of the Polly Knowledge Graph.
        Params:
            stats: A boolean flag to retrieve the detailed counts edges.
        Returns:
            dict: A dictionary containing summary information about the graph,
                 such as node counts, edge counts, and other metadata.

        Raises:
            ResourceNotFoundError: Raised when the specified graph summary does not exist.
            AccessDeniedError: Raised when the user does not have permission to access the graph summary.
            RequestFailureException: Raised when the request fails due to an unexpected error.
        """
        try:
            if stats:
                response = self.session.get(
                    f"{self.polly_kg_neo4j_endpoint}/kg/{self.kg_id}/versions/{self.version_id}/summary?stats=true"
                )
            else:
                response = self.session.get(
                    f"{self.polly_kg_neo4j_endpoint}/kg/{self.kg_id}/versions/{self.version_id}/summary"
                )
            return handle_success_and_error_response(response)
        except Exception as e:
            print(e)
            raise

    def get_schema(self) -> dict:
        """Retrieve the schema of the Polly Knowledge Graph.

        Returns:
            dict: A dictionary containing schema information about the graph,
                 such as node types, relationship types, and other metadata with descriptions.

        Raises:
            ResourceNotFoundError: Raised when the specified graph schema does not exist.
            AccessDeniedError: Raised when the user does not have permission to access the graph schema.
            RequestFailureException: Raised when the request fails due to an unexpected error.
        """
        try:

            # Always include description parameter
            params = {"description": "true", "custom_attribute": "true"}

            response = self.session.get(
                f"{self.polly_kg_neo4j_endpoint}/kg/{self.kg_id}/versions/{self.version_id}/schema",
                params=params,
            )
            schema_response = handle_success_and_error_response(response)

            # Transform new format to old format
            if schema_response and "data" in schema_response:
                transformed = self._transform_schema_to_legacy_format(
                    schema_response, self.kg_id, self.version_id
                )
                return transformed

            return schema_response
        except Exception as e:
            print(e)
            raise

    @Track.track_decorator
    def get_all_queries(
        self,
        status: str = "IN_PROGRESS",
        page_size: int = 100,
        next_token: str = None,
        instance_id: str = None,
    ) -> dict:
        """Retrieve a list of queries for the specified KG version.

        This function fetches queries based on their status, allowing you to filter
        and paginate through query results. It supports filtering by status and
        optionally by instance_id.

        Args:
            status (str, optional): Filter queries by status. Accepts "IN_PROGRESS",
                "COMPLETED", "FAILED", "QUEUED", or "CANCELLED". Defaults to "IN_PROGRESS".
            page_size (int, optional): Number of queries to return per page.
                Maximum 100. Defaults to 100.
            next_token (str, optional): Pagination token for retrieving the next page
                of results. Obtained from the 'meta' section of the previous response.
                Defaults to None.
            instance_id (str, optional): Filter queries by specific instance ID.
                Defaults to None.

        Returns:
            dict: A dictionary containing query data and pagination metadata:
                - data (list): List of query objects with attributes including query_id,
                  query_string, status, created_at, and metadata.
                - meta (dict): Pagination metadata including next_token if more results exist.
                If no queries are found, returns a message string.

        Raises:
            BadRequestError: If invalid parameters are provided.
            UnauthorizedException: If authentication fails.
            RequestFailureException: If the request fails due to an unexpected error.
        """
        queries_url = f"{self.polly_kg_neo4j_endpoint}/kg/{self.kg_id}/versions/{self.version_id}/queries/"
        params = {"status": status, "page_size": page_size}

        if next_token:
            params["next_token"] = next_token
        if instance_id:
            params["instance_id"] = instance_id

        response = self.session.get(queries_url, params=params)
        handle_success_and_error_response(response)
        response_json = response.json()
        meta = response_json.get("meta", {})

        if "data" in response_json:
            count = len(response_json["data"])
            if count == 0:
                return f"No {status} queries found"
            return {"data": response_json["data"], "meta": meta}
        return {
            "message": response_json.get("message", "No information available"),
            "meta": meta,
        }

    @Track.track_decorator
    def cancel_query(self, query_id: str) -> dict:
        """Cancel a running or queued query.

        This function attempts to cancel a query that is currently in "IN_PROGRESS"
        or "QUEUED" status. Once cancelled, the query status will be updated to
        "CANCELLED" and it will stop execution.

        Args:
            query_id (str): The unique ID of the query to cancel. Must be a non-empty string.

        Returns:
            dict: A dictionary containing the cancellation response with updated query status.

        Raises:
            InvalidParameterException: If query_id is None, empty, or not a valid string.
            ResourceNotFoundError: If the specified query_id does not exist.
            BadRequestError: If the query cannot be cancelled (e.g., already completed or failed).
            UnauthorizedException: If authentication fails.
            RequestFailureException: If the request fails due to an unexpected error.
        """
        if not query_id or not isinstance(query_id, str) or query_id.strip() == "":
            raise InvalidParameterException("query_id")

        queries_url = f"{self.polly_kg_neo4j_endpoint}/kg/{self.kg_id}/versions/{self.version_id}/queries/{query_id}/status"
        payload = {"data": {"type": "kg_query", "attributes": {"status": "CANCELLED"}}}

        try:
            response = self.session.patch(queries_url, data=json.dumps(payload))
            handle_success_and_error_response(response)
            return response.json()
        except Exception as e:
            print(e)
            raise e

    def _transform_schema_to_legacy_format(
        self, new_schema: dict, kg_id: str, version_id: str
    ) -> dict:
        """Transform new schema format to legacy format for backward compatibility.

        Args:
            new_schema (dict): The new schema format from the API
            kg_id (str): The knowledge graph ID
            version_id (str): The version ID

        Returns:
            dict: Schema in legacy format
        """
        data = new_schema.get("data", {})
        attributes = data.get("attributes", {})
        schema = attributes.get("schema", {})
        custom_attributes = attributes.get("custom_attributes", {})

        # Extract basic information
        node_types = schema.get("node_types", [])
        edge_types = schema.get("edge_types", [])
        nodes = schema.get("nodes", {})
        edges = schema.get("edges", {})

        # Transform nodes to legacy format
        transformed_nodes = {}
        for node_name, node_data in nodes.items():
            properties_dict = node_data.get("properties", {})
            node_description = node_data.get("description", "")

            # Convert properties from dict to array format
            properties_array = []

            for prop_name, prop_details in properties_dict.items():
                prop_type = prop_details.get("type", "String")
                prop_description = prop_details.get("description", "")

                # Build property object with name, type, and description
                prop_obj = {
                    "name": prop_name,
                    "type": prop_type,
                    "description": prop_description,
                }
                properties_array.append(prop_obj)

            transformed_nodes[node_name] = {
                "properties": properties_array,
            }

            # Add description if available
            if node_description:
                transformed_nodes[node_name]["description"] = node_description

        # Transform edges to legacy format
        transformed_edges = {}
        for edge_name, edge_data in edges.items():
            properties_dict = edge_data.get("properties", {})
            edge_description = edge_data.get("description", "")
            connections = edge_data.get("connections", [])

            # Convert properties from dict to array format
            properties_array = []
            for prop_name, prop_details in properties_dict.items():
                prop_type = prop_details.get("type", "String")
                prop_description = prop_details.get("description", "")

                # Build property object with name, type, and description
                prop_obj = {
                    "name": prop_name,
                    "type": prop_type,
                    "description": prop_description,
                }
                properties_array.append(prop_obj)

            # Transform connections from new format (in/out) to old format (from/to)
            # In new format: "out" is the target node, "in" is the source node
            # In old format: "from" is the source node (in), "to" is the target node (out)
            connections_array = []
            for conn in connections:
                connections_array.append(
                    {"from": conn.get("in"), "to": conn.get("out")}
                )

            transformed_edges[edge_name] = {
                "properties": properties_array,
                "connections": connections_array,
            }

            # Add description if available
            if edge_description:
                transformed_edges[edge_name]["description"] = edge_description

        # Build legacy format response
        from datetime import datetime

        # Build metadata with standard fields
        metadata = {
            "name": "schema",
            "kg_id": str(kg_id),
            "kg_version": str(version_id),
            "last_updated": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
            "computed_at": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        }

        data_source = custom_attributes.get("data_source")
        if data_source is not None:
            metadata["data_source"] = data_source

        legacy_format = {
            "data": {
                "type": "kg_schema",
                "attributes": {
                    "metadata": metadata,
                    "node_types": node_types,
                    "edge_types": edge_types,
                    "nodes": transformed_nodes,
                    "edges": transformed_edges,
                },
            }
        }

        return legacy_format

    @Track.track_decorator
    def get_all_kgs(
        self,
        include_unpublished: bool = False,
        include_instances: bool = False,
        include_terminated: bool = False,
    ) -> list:
        """Retrieve all available Knowledge Graphs.

        This function fetches a list of all available Knowledge Graphs (KGs)
        that the user has access to, including their metadata such as kg_id,
        kg_name, kg_description, version_id, created_at timestamp, and
        published status.

        Args:
            include_unpublished (bool, optional): Include unpublished knowledge graphs.
                Defaults to False.
            include_instances (bool, optional): Include instance information for each KG.
                When True, each KG will include an 'instances' array with details about
                available instances (instance_id, instance_type, CPU/RAM, etc.).
                Defaults to False.
            include_terminated (bool, optional): Include terminated instances in the response.
                Only applies when include_instances is True. Defaults to False.

        Returns:
            list: A list of dictionaries, where each dictionary contains:
                - kg_id (str): Unique identifier for the knowledge graph
                - kg_name (str): Name of the knowledge graph
                - kg_description (str): Description of the knowledge graph
                - version_id (int): Current version ID
                - created_at (int): Creation timestamp (Unix epoch in milliseconds)
                - published (bool): Whether the KG is published
                - instances (list, optional): Available when include_instances=True.
                  Each instance contains:
                    - instance_id (str): Unique identifier for the instance
                    - instance_type (str): Type/size of instance (e.g., "t3.medium")
                    - is_terminated (bool): Whether the instance is terminated
                    - default_instance (bool): Whether this is the default instance
                    - org_id (int): Organization ID
                    - created_at (int): Instance creation timestamp

        Raises:
            ResourceNotFoundError: Raised when no knowledge graphs are found.
            AccessDeniedError: Raised when the user does not have permission to access the KGs.
            RequestFailureException: Raised when the request fails due to an unexpected error.
        """
        try:
            kg_url = f"{self.polly_kg_neo4j_endpoint}/kg"

            # Build query parameters
            params = {}
            if include_unpublished:
                params["include_unpublished"] = "true"
            if include_instances:
                params["include_instances"] = "true"
            if include_terminated:
                params["include_terminated"] = "true"

            response = self.session.get(kg_url, params=params)
            handle_success_and_error_response(response)

            data = response.json().get("data", [])

            if not data:
                raise ResourceNotFoundError(detail="No knowledge graphs found.")

            return data

        except Exception as e:
            print(e)
            raise
