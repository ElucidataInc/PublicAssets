from polly.auth import Polly
from polly.errors import (
    InvalidParameterException,
    AccessDeniedError,
    RequestFailureException,
    QueryFailedException,
    ResourceNotFoundError,
)
from polly import helpers
from polly import constants as const
from polly.tracking import Track

import requests
import json
import logging


class PollyKG:
    """A class to interact with the Polly Knowledge Graph (KG) API.

    This class provides methods to execute and manage Gremlin queries against the Polly KG endpoint.

    Attributes:
        session: The Polly session object for authentication
        polly_kg_endpoint: The base URL for the Polly KG API
        env_string: The environment string (prod, test, or devenv)
    """

    def __init__(self, token=None, env="", default_env="polly") -> None:
        """Initialize a PollyKG instance.

        Args:
            token (str, optional): Authentication token. Defaults to None.
            env (str, optional): Environment override. Defaults to "".
            default_env (str, optional): Default environment if not specified. Defaults to "polly".
        """
        env = helpers.get_platform_value_from_env(
            const.COMPUTE_ENV_VARIABLE, default_env, env
        )
        self.session = Polly.get_session(token, env=env)
        self.polly_kg_endpoint = (
            f"https://apis.{self.session.env}.elucidata.io/polly-kg"
        )
        if self.session.env == "polly":
            self.env_string = "prod"
        elif self.session.env == "testpolly":
            self.env_string = "test"
        else:
            self.env_string = "devenv"

    @Track.track_decorator
    def get_engine_status(self) -> dict:
        """Retrieve a status of the Polly Knowledge Graph.

        Returns:
            dict: A dictionary containing status information about the engine,
                 such as gremlin, opencypher.

        Raises:
            ResourceNotFoundError: If the graph summary is not found.
            AccessDeniedError: If access to the graph summary is denied.
            RequestFailureException: If the request fails for any other reason.

        Examples:
            >>> kg = PollyKG()
            >>> summary = kg.get_graph_summary()
        """
        try:
            response = self.session.get(f"{self.polly_kg_endpoint}/status")
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as http_err:
            if http_err.response.status_code == 404:
                raise ResourceNotFoundError("Graph summary not found.")
            elif http_err.response.status_code == 403:
                raise AccessDeniedError("Access denied to graph summary.")
            logging.error(f"HTTP error occurred: {http_err}")
            raise RequestFailureException()
        except requests.exceptions.RequestException as e:
            logging.error(f"Error retrieving graph summary: {e}")
            raise RequestFailureException()

    @Track.track_decorator
    def get_graph_summary(self) -> dict:
        """Retrieve a summary of the Polly Knowledge Graph.

        Returns:
            dict: A dictionary containing summary information about the graph,
                 such as node counts, edge counts, and other metadata.

        Raises:
            ResourceNotFoundError: If the graph summary is not found.
            AccessDeniedError: If access to the graph summary is denied.
            RequestFailureException: If the request fails for any other reason.

        Examples:
            >>> kg = PollyKG()
            >>> summary = kg.get_graph_summary()
        """
        try:
            response = self.session.get(f"{self.polly_kg_endpoint}/summary")
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as http_err:
            if http_err.response.status_code == 404:
                raise ResourceNotFoundError("Graph summary not found.")
            elif http_err.response.status_code == 403:
                raise AccessDeniedError("Access denied to graph summary.")
            logging.error(f"HTTP error occurred: {http_err}")
            raise RequestFailureException()
        except requests.exceptions.RequestException as e:
            logging.error(f"Error retrieving graph summary: {e}")
            raise RequestFailureException()

    @Track.track_decorator
    def run_opencypher_query(self, query: str) -> dict:
        """Execute a opencypher query against the Polly KG endpoint.

        Args:
            query (str): The opencypher query to execute.

        Returns:
            dict: The query execution results.

        Raises:
            InvalidParameterException: If query is empty or None.
            RequestFailureException: If the request fails.
            QueryFailedException: If the query execution fails due to timeout.
        """
        if not query or query == "":
            raise InvalidParameterException("query")

        payload = {"query_content": query}

        try:
            response = self.session.post(
                f"{self.polly_kg_endpoint}/opencypher/query", data=json.dumps(payload)
            )
            print(response.json())
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as http_err:
            if (
                http_err.response.status_code == 408
                or "timeout" in str(http_err).lower()
            ):
                logging.error("Query execution timed out")
                raise QueryFailedException(
                    "Time limit exceeded, please optimize the query or contact polly.support@elucidata.io"
                )
            logging.error(f"HTTP error occurred: {http_err}")
            raise RequestFailureException()
        except requests.exceptions.RequestException as e:
            logging.error(f"Error executing query: {e}")
            raise RequestFailureException()

    @Track.track_decorator
    def run_gremlin_query(self, query: str) -> dict:
        """Execute a Gremlin query against the Polly KG endpoint.

        Args:
            query (str): The Gremlin query to execute.

        Returns:
            dict: The query execution results.

        Raises:
            InvalidParameterException: If query is empty or None.
            RequestFailureException: If the request fails.
            QueryFailedException: If the query execution fails due to timeout.
        """
        if not query or query == "":
            raise InvalidParameterException("query")

        payload = {"query_content": query}

        try:
            response = self.session.post(
                f"{self.polly_kg_endpoint}/gremlin/query", data=json.dumps(payload)
            )
            response.raise_for_status()
            if not response.json().get("success", True):
                raise ValueError(f"Gremlin query failed: {response.json().get('message', 'Unknown error')}")
            return response.json()["result"]
        except requests.exceptions.HTTPError as http_err:
            if (
                http_err.response.status_code == 408
                or "timeout" in str(http_err).lower()
            ):
                logging.error("Query execution timed out")
                raise QueryFailedException(
                    "Time limit exceeded, please optimize the query or contact polly.support@elucidata.io"
                )
            logging.error(f"HTTP error occurred: {http_err}")
            raise RequestFailureException()
        except requests.exceptions.RequestException as e:
            logging.error(f"Error executing query: {e}")
            raise RequestFailureException()
