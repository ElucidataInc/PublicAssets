V2_API_ENDPOINT = 'https://v2.api.devpolly.elucidata.io'
