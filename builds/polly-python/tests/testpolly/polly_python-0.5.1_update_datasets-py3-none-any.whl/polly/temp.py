{
    "data": [
        {
            "id": "transcriptomics_110/ACBC_MSKCC_2015_Copy_Number_AdCC10T_copy",
            "type": "files",
            "attributes": {
                "size": 4,
                "author": "yogesh.lakhotia@elucidata.io",
                "version": "KGpwVMg0foKeQlT71yNEpKOhZ4ESSplC",
            },
        },
        {
            "id": "transcriptomics_111/ACBC_MSKCC_2015_Copy_Number_AdCC10T_copy",
            "type": "files",
            "attributes": {
                "size": 4,
                "author": "yogesh.lakhotia@elucidata.io",
                "version": "z7g7r_ANWhqOcvnnsj0iG_PN6Yn5Gvab",
            },
        },
        {
            "id": "transcriptomics_110/ACBC_MSKCC_2015_Copy_Number_AdCC12T.gct",
            "type": "files",
            "attributes": {
                "size": 34030,
                "author": "mayank.saurabh@elucidata.io",
                "version": "M.1RVBs9nWEWxXCZ4nv_jUCfWrY3em_V",
            },
        },
        {
            "id": "transcriptomics_110/ACBC_MSKCC_2015_Copy_Number_AdCC11T.gct",
            "type": "files",
            "attributes": {
                "size": 34027,
                "author": "mayank.saurabh@elucidata.io",
                "version": "rc1b2cH8DjEBeUmvSnpsocP132gdbcdo",
            },
        },
        {
            "id": "transcriptomics_200/ACBC_MSKCC_2015_Copy_Number_AdCC12T.gct",
            "type": "files",
            "attributes": {
                "size": 34030,
                "author": "mayank.saurabh@elucidata.io",
                "version": "YlyRFhJ2yye1vDvKWY6Tsg6Qi6ExuJsK",
            },
        },
        {
            "id": "transcriptomics_200/ACBC_MSKCC_2015_Copy_Number_AdCC11T.gct",
            "type": "files",
            "attributes": {
                "size": 34027,
                "author": "mayank.saurabh@elucidata.io",
                "version": "FPJdAXJiWwforYDoZpMg5Zj2PEfNNrxg",
            },
        },
        {
            "id": "transcriptomics_201/ACBC_MSKCC_2015_Copy_Number_AdCC12T.gct",
            "type": "files",
            "attributes": {
                "size": 34030,
                "author": "mayank.saurabh@elucidata.io",
                "version": "suvzHmhoJ1ARZqZ_KxUTFJoZWt3_Ah34",
            },
        },
        {
            "id": "transcriptomics_201/ACBC_MSKCC_2015_Copy_Number_AdCC11T.gct",
            "type": "files",
            "attributes": {
                "size": 34027,
                "author": "mayank.saurabh@elucidata.io",
                "version": "RExN4ZNNkf3ltOhjjcjDp4xZ8s1Tn9cS",
            },
        },
        {
            "id": "transcriptomics_306/GSE76311_GPL17586.gct",
            "type": "files",
            "attributes": {
                "size": 47939744,
                "author": "mayank.saurabh@elucidata.io",
                "version": "dhUHivGvzpInyECvXaENSSdZpH4xAzeC",
            },
        },
        {
            "id": "transcriptomics_307/GSE101503_GPL16791.gct",
            "type": "files",
            "attributes": {
                "size": 3092866,
                "author": "mayank.saurabh@elucidata.io",
                "version": "FstJGXavjxsDVy0xcb7Fco2V_TXhuZd5",
            },
        },
        {
            "id": "transcriptomics_110/ACBC_MSKCC_2015_Copy_Number_AdCC10T.gct",
            "type": "files",
            "attributes": {
                "size": 34381,
                "author": "mayank.saurabh@elucidata.io",
                "version": "h5OMzZTDizu5zgKQD.aGuOlKO8yjfK7r",
            },
        },
        {
            "id": "transcriptomics_110/ACBC_MSKCC_2015_Copy_Number_AdCC1T.gct",
            "type": "files",
            "attributes": {
                "size": 34359,
                "author": "mayank.saurabh@elucidata.io",
                "version": "70.2noDSL5ZYqZBrP4QopULICA93BCJp",
            },
        },
        {
            "id": "transcriptomics_610/GSE76311_GPL17586.gct",
            "type": "files",
            "attributes": {
                "size": 34324480,
                "author": "mayank.saurabh@elucidata.io",
                "version": "OcGP4i2u9qjDhq6xpWkBMD7zQONNX3F1",
            },
        },
        {
            "id": "transcriptomics_610/GSE95640_GPL11154.gct",
            "type": "files",
            "attributes": {
                "size": 91960610,
                "author": "mayank.saurabh@elucidata.io",
                "version": "Ssy7hZLQQpcKFtG_IqJHmCFl2BjvI.9Z",
            },
        },
        {
            "id": "ACBC_MSKCC_2015_Copy_Number_AdCC10T.gct",
            "type": "files",
            "attributes": {
                "size": 34381,
                "author": "mayank.saurabh@elucidata.io",
                "version": "k6m8bFMcl09OVyS7j.wu0IW81m9FJ2j6",
            },
        },
        {
            "id": "ACBC_MSKCC_2015_Copy_Number_AdCC11T.gct",
            "type": "files",
            "attributes": {
                "size": 34027,
                "author": "mayank.saurabh@elucidata.io",
                "version": "aEhjFcbLD9GF7rnatALBRV3afBKhmSOs",
            },
        },
        {
            "id": "ACBC_MSKCC_2015_Copy_Number_AdCC12T.gct",
            "type": "files",
            "attributes": {
                "size": 34030,
                "author": "mayank.saurabh@elucidata.io",
                "version": "s0wwzbfmfYkR11BX285EAdRZu.kac5_n",
            },
        },
        {
            "id": "transcriptomics_301/GSE54747_GPL6244.gct",
            "type": "files",
            "attributes": {
                "size": 2127910,
                "author": "mayank.saurabh@elucidata.io",
                "version": "7cwerqHPWJwl__6pinGd420L6wC16oIB",
            },
        },
    ],
    "links": {
        "self": "/repositories/1673847977346/files?page[size]=1000&version=latest",
        "next": None,
    },
}
