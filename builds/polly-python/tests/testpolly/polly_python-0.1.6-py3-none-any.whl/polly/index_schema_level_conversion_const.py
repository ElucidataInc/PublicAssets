# index and level name
indexes_schema_level_map = {
    "files": "dataset",
    "gct_metadata": "sample",
    "h5ad_metadata": "sample",
}
