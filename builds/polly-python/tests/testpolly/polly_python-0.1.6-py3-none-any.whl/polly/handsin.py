#!/usr/bin/env python

from polly.auth import Polly
from polly.omixatlas import OmixAtlas

AUTH_TOKEN = "NW02dWZ2Zm5wZzo6RTAzWjNEQ3l5TDZsck9JbGl3bE1hNEtVS3BJbnF1UEsxYVF5TFBRZw=="
Polly.auth(AUTH_TOKEN)

repo_id = "1643359804137"
query = f"SELECT * FROM {repo_id}.datasets LIMIT 10"
omix_obj_test = OmixAtlas(AUTH_TOKEN, env="devpolly")
res_df = omix_obj_test.query_metadata(query)
print(res_df)
