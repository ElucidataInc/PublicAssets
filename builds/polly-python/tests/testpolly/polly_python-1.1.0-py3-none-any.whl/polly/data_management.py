import os
import re
from os import PathLike
from os.path import join as join_paths
from typing import Tuple, Optional, Union, List, TYPE_CHECKING, Any
from datetime import datetime
import logging
import json
import gzip
import urllib
import tempfile

import boto3
from botocore.client import BaseClient
from botocore.credentials import RefreshableCredentials
from botocore.session import get_session

from polly.auth import Polly, UnauthorizedException
from polly.session import PollySession
from polly.s3_utils import copy_file, read_bytes
from polly.errors import error_handler
from polly.threading_utils import for_each_threaded

if TYPE_CHECKING:
    from cmapPy.pandasGEXpress.GCToo import GCToo
    from anndata import AnnData


class UnsupportedFormat(ValueError):
    pass


def humanize_unix_timestamp(unix_timestamp_ms):
    """
    Converts a Unix timestamp in milliseconds to a human-readable date and time string.

    Args:
        unix_timestamp_ms (int): The Unix timestamp in milliseconds.

    Returns:
        str: A string representing the date and time in the format "YYYY-MM-DD HH:MM:SS"
    """
    unix_timestamp = unix_timestamp_ms / 1000.0
    dt = datetime.fromtimestamp(unix_timestamp)
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def sanitize_user_defined_id(string, prepend="", check_startswith_digit=False):
    if len(str(string)) == 0:
        raise ValueError("Empty string cannot be sanitized")

    string = f"{prepend}{string}"
    string = re.sub("[^0-9a-zA-Z_]", "_", string)
    if check_startswith_digit:
        string = f"_{string}" if string[0].isdigit() else string
    return string


def _validate_user_defined_id(identifier: str, name_for_id: str):
    if identifier == "":
        raise ValueError(f"Empty string cannot be used as {name_for_id}")
    sanitized_id = sanitize_user_defined_id(identifier)
    if identifier != sanitized_id:
        raise ValueError(
            f"Cannot use '{identifier}' as {name_for_id},"
            f" consider using '{sanitized_id}'",
        )


class _S3ClientManager:
    """
    Used for retrieving the right S3 client for the omixatlas
    S3 bucket

    The client returned by `get_client` is configured with temporary
    tokens for the omixatlas bucket, and auto-refreshes when they
    expire

    Clients are cached, and as per AWS docs they are thread safe
    """

    _cache = {}

    def __init__(self, omixatlas_id: str, copy_dest_omixatlas_id: Optional[str] = None):
        self.omixatlas_id = omixatlas_id
        self.copy_dest_omixatlas_id = copy_dest_omixatlas_id
        if Polly.default_session is None:
            raise UnauthorizedException()
        self.polly_session = Polly.default_session

    def _init_client(self) -> Tuple[boto3.Session, BaseClient, str, str]:
        if (self.omixatlas_id, self.copy_dest_omixatlas_id) not in self._cache:
            session, bucket, folder = self._get_autorefresh_session()
            client = session.client("s3")
            self._cache[(self.omixatlas_id, self.copy_dest_omixatlas_id)] = (
                session,
                client,
                bucket,
                folder,
            )

        return self._cache[(self.omixatlas_id, self.copy_dest_omixatlas_id)]

    def get_client(self) -> BaseClient:
        """
        Returns the boto3 client to be used for making S3 requests
        """
        _, client, _, _ = self._init_client()
        return client

    def get_upload_path(self) -> Tuple[str, str]:
        """
        Returns the bucket and prefix where the data
        needs to be uploaded
        """
        _, _, bucket, prefix = self._init_client()
        return bucket, prefix

    def _generate_temp_s3_tokens(self):
        logging.debug(
            f"Generating temporary S3 tokens for omixatlas_id='{self.omixatlas_id}'"
        )

        # post request for upload urls
        payload = {
            "data": {
                "type": "session-tokens",
                "attributes": {
                    "omixatlas_id": self.omixatlas_id,
                    "copy_dest_omixatlas_id": self.copy_dest_omixatlas_id,
                },
            }
        }

        # post request
        url = f"{self.polly_session.discover_url}/session-tokens"

        resp = self.polly_session.post(url, json=payload)
        error_handler(resp)
        resp.raise_for_status()

        response_data = resp.json()
        attrs = response_data["data"]["attributes"]

        credentials = {}
        if self.copy_dest_omixatlas_id is None:
            bucket_name = attrs.get("bucket_name")
            prefix = attrs.get("prefix")
        else:
            bucket_name = attrs["copy_dest_details"]["bucket_name"]
            prefix = attrs["copy_dest_details"]["prefix"]

        tokens = attrs["tokens"]
        credentials["access_key"] = tokens["AccessKeyId"]
        credentials["secret_key"] = tokens["SecretAccessKey"]
        credentials["token"] = tokens["SessionToken"]
        credentials["expiry_time"] = tokens["Expiration"]

        return credentials, bucket_name, prefix

    def _get_autorefresh_session(self):
        """
        Returns
        - boto3 session configured with refreshable credentials
        - bucket name for the given omixatlas
        - folder within the bucket
        """
        # Here we're assuming that bucket and folder
        # won't change after token refresh
        creds, bucket, folder = self._generate_temp_s3_tokens()

        def refresh_using():
            creds, _, _ = self._generate_temp_s3_tokens()
            return creds

        session_credentials = RefreshableCredentials.create_from_metadata(
            metadata=creds,
            refresh_using=refresh_using,
            method="files-endpoint",
        )

        session = get_session()
        session._credentials = session_credentials
        autorefresh_session = boto3.Session(botocore_session=session)

        return autorefresh_session, bucket, folder


def _is_supported_format(path: str) -> bool:
    try:
        _infer_file_type(path)
    except UnsupportedFormat:
        return False

    return True


def _infer_file_type(path: str) -> Tuple[str, str]:
    """
    Args:
        path (str): The file path for which to infer the file type.

    Returns:
        Tuple[str, str]: A tuple containing the inferred file type and file extension.

    Raises:
        UnsupportedFormat: If the file extension is not recognized as a supported format
    """
    # TODO: a way to upload any unsupported file type
    extension = _extract_file_extension(path)
    if extension == ".gct":
        return "gct", ".gct"
    if extension == ".gct":
        return "csv", ".csv"
    raise UnsupportedFormat(f"Couldn't infer file type {path}")


def _extract_extension_from_s3_uri(uri: str) -> str:
    """
    Args:
        uri (str): S3 URI (e.g. s3://mybucket/file.txt)

    Returns:
        str: The file extension, including the leading period (e.g., '.txt'),
             or an empty string if no extension is found.
    """
    uri_without_version = uri.split("?")[0]

    s3_key = uri_without_version.rstrip("/").split("/")[-1]

    if s3_key.startswith("."):
        return "" if s3_key.count(".") == 1 else ".".join(s3_key.split(".")[1:])
    parts = s3_key.split(".")
    if len(parts) > 1:
        extension = "." + ".".join(parts[1:])  # Join all parts except the file name
    else:
        extension = ""  # No extension present
    return extension


class _Version:
    dataset_id: str
    omixatlas_id: str
    data_type: str
    version_id: str
    study_id: str
    metadata_location: str
    data_location: str
    data_format: str
    created_at: int

    attributes: dict
    _s3_client_manager: _S3ClientManager

    def __init__(self, **kwargs):
        self.omixatlas_id: str = kwargs.get("omixatlas_id")
        self.dataset_id: str = kwargs.get("dataset_id")
        self.version_id: str = kwargs.get("version_id")
        self.data_type: str = kwargs.get("data_type")
        self.metadata_location: str = kwargs.get("metadata_location")
        self.data_location: str = kwargs.get("data_location")
        self.data_format: str = kwargs.get("data_format")
        self.created_at: int = kwargs.get("created_at")

        self.attributes = kwargs

    def metadata(self) -> dict:
        """
        Retrieves the metadata for the dataset version.

        Returns:
            dict: The metadata of the dataset version as a dictionary.

        Example:
            >>> metadata = dataset.metadata()
            >>> print(metadata)  # Example output: {'description': '...'}
        """
        if not hasattr(self, "_metadata"):
            raw_data = read_bytes(
                self._s3_client_manager.get_client(), self.metadata_location
            )
            self._metadata = json.loads(gzip.decompress(raw_data).decode("utf-8"))

        return self._metadata

    def load(self) -> Union["GCToo", "AnnData"]:
        """
        Loads the underlying data into memory, as a GCToo or AnnData object

        The function determines the appropriate loader based on the data format.

        Returns:
            Union["GCToo", "AnnData"]: The loaded data object

        Raises:
            ValueError: If the data format is not supported or cannot be determined.

        Example:
            >>> adata = dataset.load()
        """
        format = self.attributes.get("data_format")

        if not format:
            raise ValueError(
                "Unable to determine file format. Use `dataset.download(...)` instead"
            )

        if format == "gct":
            from cmapPy.pandasGEXpress.parse import parse

            with tempfile.NamedTemporaryFile("w", suffix=".gct", delete=True) as f:
                # Using a context manager to handle the temporary file
                tmp_file_path = f.name
                copy_file(
                    self.data_location,
                    tmp_file_path,
                    s3_client=self._s3_client_manager.get_client(),
                )
                return parse(tmp_file_path)

        if format == "h5ad":
            import anndata

            with tempfile.NamedTemporaryFile("w", suffix=".h5ad", delete=True) as f:
                # Using a context manager to handle the temporary file
                tmp_file_path = f.name
                copy_file(
                    self.data_location,
                    tmp_file_path,
                    s3_client=self._s3_client_manager.get_client(),
                )
                return anndata.read_h5ad(tmp_file_path)

        raise ValueError(f"Unsupported format: {format}")

    def download(self, path: Union[str, PathLike]):
        """
        Downloads the dataset version's data to a local file path.

        Args:
            path (Union[str, PathLike]): Can be a directory or a file path.

        Returns:
            str: The file path where the data was downloaded.

        Example:
            >>> dataset.download('./mydataset.h5ad')
        """
        format = self.attributes.get("data_format")

        if os.path.isdir(path):
            format_to_extension = {
                "csv": ".csv",
                "json+gzip": ".json.gz",
                "gct": ".gct",
                "h5ad": ".h5ad",
            }

            if format in format_to_extension:
                extension = format_to_extension[format]
            else:
                extension = _extract_extension_from_s3_uri(self.data_location)

            path = join_paths(path, f"{self.dataset_id}{extension}")

        copy_file(
            self.data_location, path, s3_client=self._s3_client_manager.get_client()
        )
        return path


class Dataset(_Version):
    def __init__(
        self,
        **kwargs,
    ):
        super().__init__(**kwargs)

        self.study_id: str = kwargs.get("study_id")
        self.last_modified_at: int = kwargs.get("last_modified_at")

        self._s3_client_manager = _S3ClientManager(self.omixatlas_id)

    def __repr__(self) -> str:
        modified_at = humanize_unix_timestamp(self.last_modified_at)
        if self.study_id is None:
            return (
                f"Dataset(dataset_id='{self.dataset_id}', data_type='{self.data_type}',"
                f" last_modified_at='{modified_at}', data_format='{self.data_format}')"
            )
        return (
            f"Dataset(dataset_id='{self.dataset_id}', data_type='{self.data_type}',"
            f" last_modified_at='{modified_at}', data_format={self.data_format},"
            f" study_id='{self.study_id}'"
        )


# TODO: Check for anndata > 0.8.0

# TODO: Make sure authorization-related error messages are clear

# TODO: Params for validation?


class DatasetVersion(_Version):
    def __init__(
        self,
        **kwargs,
    ):
        super().__init__(**kwargs)

        self._s3_client_manager = _S3ClientManager(self.omixatlas_id)

    def __repr__(self) -> str:
        return (
            f"DatasetVersion(version_id='{self.version_id}',"
            f" created_at='{humanize_unix_timestamp(self.created_at)}')"
        )


def _is_gctoo(obj: Any) -> bool:
    """
    Checks if obj is an instance of GCToo without
    requiring cmapPy to be present as a dependency
    """
    try:
        from cmapPy.pandasGEXpress.GCToo import GCToo

        return isinstance(obj, GCToo)
    except ImportError:
        return False


def _is_anndata(obj: Any) -> bool:
    try:
        from anndata import AnnData

        return isinstance(obj, AnnData)
    except ImportError:
        return False


def _extract_file_extension(path: str):
    """
    Extracts the file extension from the given file path.

    Args:
        path (str): The file path from which to extract the file extension.

    Returns:
        str: The file extension including the leading period (e.g. '.txt').

    Raises:
        ValueError: If the file path is either an empty string, a directory path,
         or does not contain a file extension.
    """
    if not path or path.endswith("/") or path.endswith("\\"):
        raise ValueError("The file path is either an empty string or a directory path.")

    base_name = os.path.basename(path)
    if "." not in base_name or base_name.startswith("."):
        raise ValueError("The file path does not contain a file extension.")

    return os.path.splitext(base_name)[1]


class Catalog:
    def __init__(self, omixatlas_id: str) -> None:
        """
        Initializes the internal data Catalog for a given OmixAtlas

        Args:
            omixatlas_id (str): The identifier for the OmixAtlas

        Example:
            >>> geo_catalog = Catalog(omixatlas_id='9')
        """
        # what's the difference between env and default_env?
        # why does Polly.get_session make a request?

        if Polly.default_session is None:
            raise UnauthorizedException()

        self._session: PollySession = Polly.default_session
        self.omixatlas_id = omixatlas_id
        self._s3_client_manager = _S3ClientManager(self.omixatlas_id)

    def _upload_data(
        self,
        dataset_id: str,
        data: Union[str, "GCToo", "AnnData"],
        data_format: Optional[str] = None,
    ) -> Tuple[str, str]:
        client = self._s3_client_manager.get_client()
        bucket, prefix = self._s3_client_manager.get_upload_path()

        dest_path_without_extension = "s3://" + join_paths(
            bucket, prefix, f"v2/{dataset_id}/{dataset_id}"
        )

        if isinstance(data, str) and data.startswith("s3://"):
            # user is passing s3 uri directly
            if data_format is None:
                raise ValueError(
                    "'data_format' is a required field when passing S3 uri directly"
                )
            return data, data_format

        if isinstance(data, str) and not _is_supported_format(data):
            # couldn't infer format
            if data_format is None:
                raise ValueError(
                    "Couldn't infer 'data_format', please pass it directly"
                )
            s3_uri = dest_path_without_extension + _extract_file_extension(data)
            s3_uri_with_version = copy_file(data, s3_uri, s3_client=client)
            return s3_uri_with_version, data_format

        if isinstance(data, str):
            # try to infer file format
            file_type, extension = _infer_file_type(data)
            s3_uri = dest_path_without_extension + extension
            s3_uri_with_version = copy_file(data, s3_uri, s3_client=client)
            return s3_uri_with_version, file_type

        if _is_gctoo(data):
            extension = ".gct"
            import cmapPy.pandasGEXpress.write_gct as wg

            with tempfile.NamedTemporaryFile("w", suffix=extension, delete=True) as f:
                # Using a context manager to handle the temporary file
                tmp_file_path = f.name
                wg.write(data, tmp_file_path)
                s3_uri_with_version = copy_file(
                    tmp_file_path,
                    dest_path_without_extension + extension,
                    s3_client=client,
                )
                return s3_uri_with_version, "gct"

        if _is_anndata(data):
            extension = ".h5ad"
            with tempfile.NamedTemporaryFile("w", suffix=extension, delete=True) as f:
                # Using a context manager to handle the temporary file
                tmp_file_path = f.name
                data.write(tmp_file_path)
                s3_uri_with_version = copy_file(
                    tmp_file_path,
                    dest_path_without_extension + extension,
                    s3_client=client,
                )
                return s3_uri_with_version, "h5ad"

        raise ValueError(f"Unsupported type ({type(data)}) for parameter 'data'")

    def create_dataset(
        self,
        dataset_id: str,
        data_type: str,
        data: Union[str, "GCToo", "AnnData"],
        metadata: dict,
        *,
        ingestion_params: Optional[dict] = None,
        **kwargs,
    ) -> Dataset:
        """
        Creates a new dataset in the catalog.

        Raises an error if a dataset with the same ID already exists

        Args:
            dataset_id (str): The unique identifier for the dataset.
            data_type (str): The type of data being uploaded.
            data (Union[str, 'GCToo', 'AnnData']): The data to upload,
                 which can be a file path or an object.
            metadata (dict): The metadata dictionary

        Returns:
            Dataset: An instance representing the newly created dataset.

        Example:
            >>> catalog = Catalog(omixatlas_id='9')
            >>> new_dataset = catalog.create_dataset(
                    dataset_id='GSE123',
                    data_type='Bulk RNAseq',
                    data='/path/to/data/file.gct',
                    metadata={'description': 'New dataset description'}
                )
        """

        _validate_user_defined_id(dataset_id, "dataset_id")

        s3_uri_with_version, file_type = self._upload_data(
            dataset_id, data, data_format=kwargs.pop("data_format", None)
        )

        payload = {
            "data": {
                "type": "datasets",
                "id": dataset_id,
                "attributes": {
                    "data_type": data_type,
                    "metadata": metadata,
                    "data_s3_uri": s3_uri_with_version,
                    "data_format": file_type,
                    **kwargs,
                },
            },
            "meta": {"ingestion_params": ingestion_params},
        }
        resp = self._session.post(
            f"{self._session.discover_url}/repositories/{self.omixatlas_id}/datasets",
            json=payload,
        )
        error_handler(resp)
        return Dataset(**resp.json()["data"]["attributes"])

    def get_dataset(self, dataset_id: str) -> Dataset:
        """
        Retrieves the dataset with the given dataset_id if it exists

        Note that this function doesn't download the underlying data, it only
        returns a reference to it

        Args:
            dataset_id (str): The unique identifier for the dataset to retrieve.

        Returns:
            Dataset: An object representing the retrieved dataset.

        Example:
            >>> catalog = Catalog(omixatlas_id='9')
            >>> dataset = catalog.get_dataset(dataset_id='GSE123')
        """
        resp = self._session.get(
            f"{self._session.discover_url}/repositories/{self.omixatlas_id}/datasets/{dataset_id}",
        )
        error_handler(resp)
        data = resp.json()["data"]
        dataset_id = data["id"]
        data["attributes"].pop("dataset_id", None)
        return Dataset(dataset_id=dataset_id, **data["attributes"])

    def list_versions(
        self, dataset_id: str, *, include_deleted: bool = False
    ) -> List[DatasetVersion]:
        """
        Lists dataset versions, optionally including deleted ones.

        Args:
            dataset_id (str): Identifier for the dataset.
            include_deleted (bool): If set to True, includes previously deleted versions

        Returns:
            List[DatasetVersion]: List of dataset versions.
        """
        resp = self._session.get(
            f"{self._session.discover_url}/repositories/{self.omixatlas_id}/"
            f"datasets/{dataset_id}/versions?include_deleted={include_deleted}"
        )
        error_handler(resp)
        data = resp.json()["data"]
        versions = []
        for version_dict in data:
            version_id = version_dict["id"]
            version_dict["attributes"].pop("version_id", None)
            versions.append(
                DatasetVersion(version_id=version_id, **version_dict["attributes"])
            )
        return versions

    def list_datasets(self, *, prefetch_metadata: bool = False) -> List[Dataset]:
        """
        Retrieves the complete list of datasets in the catalog.

        By default, the metadata is lazily downloaded when you call `dataset.metadata()`
        If prefetch_metadata is set to True, this is fetched in advance for all datasets
        using multiple threads.

        Args:
            prefetch_metadata (bool, optional): Prefetches metadata for each dataset

        Returns:
            List[Dataset]: A list of Dataset instances.

        Example:
            >>> catalog = Catalog(omixatlas_id='9')
            >>> datasets = catalog.list_datasets()
            >>> for dataset in datasets:
            ...     print(dataset.dataset_id, dataset.data_type)
        """
        datasets = []
        next_link = f"/repositories/{self.omixatlas_id}/datasets"
        while True:
            resp = self._session.get(f"{self._session.discover_url}{next_link}")
            error_handler(resp)
            resp_dict = resp.json()
            datasets.extend(resp.json()["data"])
            if "links" not in resp_dict or "next" not in resp_dict["links"]:
                break
            if resp_dict["links"]["next"] is None:
                break
            next_link = resp_dict["links"]["next"]

        datasets = [Dataset(**item["attributes"]) for item in datasets]

        if prefetch_metadata:
            for_each_threaded(
                datasets, lambda d: d.metadata(), max_workers=20, verbose=True
            )

        return datasets

    def update_dataset(
        self,
        dataset_id: str,
        data_type: Optional[str] = None,
        metadata: Optional[dict] = None,
        data: Union[str, "GCToo", None] = None,
        *,
        ingestion_params: Optional[dict] = None,
        **kwargs,
    ) -> Dataset:
        """
        Updates one or more attributes of a dataset.

        Every update creates a new version of the dataset.

        Args:
            dataset_id (str): Identifier for the dataset.
            data_type (str, optional): New data type.
            metadata (dict, optional): New metadata.
            data (str, optional): New data path or object.

        Returns:
            Dataset: Updated dataset instance.

        Example:
            >>> catalog = Catalog(omixatlas_id='9')
            >>> updated_dataset = catalog.update_dataset(
                    dataset_id='GSE123',
                    metadata={'new': 'metadata'}
                )
        """
        attrs = {**kwargs}

        if data is not None:
            s3_uri_with_version, file_type = self._upload_data(
                dataset_id, data, data_format=kwargs.pop("data_format", None)
            )
            attrs["data_s3_uri"] = s3_uri_with_version
            attrs["data_format"] = file_type

        if data_type is not None:
            attrs["data_type"] = data_type

        if metadata is not None:
            attrs["metadata"] = metadata

        payload = {
            "data": {
                "type": "datasets",
                "id": dataset_id,
                "attributes": attrs,
            },
            "meta": {"ingestion_params": ingestion_params},
        }

        if not attrs:
            raise ValueError("Nothing to update")

        resp = self._session.patch(
            f"{self._session.discover_url}/repositories/{self.omixatlas_id}/datasets/{dataset_id}",
            json=payload,
        )

        error_handler(resp)
        data = resp.json()["data"]
        dataset_id = data["id"]
        data["attributes"].pop("dataset_id", None)
        return Dataset(dataset_id=dataset_id, **data["attributes"])

    def delete_dataset(self, dataset_id: str, **kwargs) -> None:
        """
        Performs a soft deletion of the dataset

        Args:
            dataset_id (str): Identifier for the dataset to be deleted.

        Example:
            >>> catalog.delete_dataset(dataset_id='GSE123')
        """
        params = urllib.parse.quote(json.dumps(kwargs))
        resp = self._session.delete(
            f"{self._session.discover_url}/repositories/{self.omixatlas_id}/datasets/{dataset_id}?params={params}",
        )
        error_handler(resp)

    def set_parent_study(self, dataset_id: str, study_id: Optional[str]) -> None:
        """
        Adds a dataset to a study. The study_id can be any arbitrary string.

        To remove the dataset from the study, set the study_id to None.

        Args:
            dataset_id (str): Identifier for the dataset
            study_id (str, optional): User defined ID for the parent study

        Example:
            >>> catalog.set_parent_study(dataset_id='GSE123', study_id='PMID123')
            >>> catalog.set_parent_study(dataset_id='GSE123', study_id=None)
        """
        if study_id is not None:
            _validate_user_defined_id(study_id, "study_id")

        payload = {
            "data": {
                "type": "datasets",
                "id": dataset_id,
                "attributes": {"study_id": study_id},
            }
        }

        resp = self._session.patch(
            f"{self._session.discover_url}/repositories/{self.omixatlas_id}/datasets/{dataset_id}",
            json=payload,
        )

        error_handler(resp)

    def list_datasets_in_study(self, study_id: str) -> List[str]:
        """
        Retrieves a list of datasets associated with a specific study.

        Args:
            study_id (str): Identifier for the study.

        Returns:
            List[str]: A list of dataset IDs that are part of the study.

        Example:
            >>> catalog = Catalog(omixatlas_id='9')
            >>> dataset_ids = catalog.list_datasets_in_study(study_id='PMID123')
            >>> print(dataset_ids)  # ['GSE123', 'GSE123_raw']
        """
        resp = self._session.get(
            f"{self._session.discover_url}/repositories/{self.omixatlas_id}/studies/{study_id}",
        )

        error_handler(resp)
        items = resp.json()["relationships"]["datasets"]["data"]
        return [item["id"] for item in items]

    def list_studies(self) -> List[str]:
        """
        Retrieves a list of all studies in the catalog.

        Returns:
            List[str]: A list of study IDs.

        Example:
            >>> catalog = Catalog(omixatlas_id='9')
            >>> studies = catalog.list_studies()
            >>> for study_id in studies:
            ...     print(study_id)
        """
        resp = self._session.get(
            f"{self._session.discover_url}/repositories/{self.omixatlas_id}/studies"
        )
        error_handler(resp)
        studies = resp.json()["data"]
        return [study["id"] for study in studies]

    def get_version(self, dataset_id: str, version_id: str) -> DatasetVersion:
        """
        Retrieves a specific version of a dataset.

        You can also use this to retrieve a version that may have been deleted.

        Args:
            dataset_id (str): Identifier for the dataset.
            version_id (str): Identifier for the dataset version.

        Returns:
            DatasetVersion: An object representing the dataset version.

        Example:
            >>> catalog = Catalog(omixatlas_id='9')
            >>> version = catalog.get_version(dataset_id='GSE123', version_id='<uuid>')
            >>> print(version.metadata())  # {'description': '...'}
        """
        resp = self._session.get(
            f"{self._session.discover_url}/repositories/{self.omixatlas_id}/datasets/{dataset_id}/versions/{version_id}",
        )
        error_handler(resp)
        data = resp.json()["data"]
        version_id = data["id"]
        data["attributes"].pop("version_id", None)
        return DatasetVersion(version_id=version_id, **data["attributes"])

    def rollback(self, dataset_id: str, version_id: str) -> Dataset:
        """
        Reverts a dataset to a specified older version.

        This function updates the dataset's `data` and `metadata` to match the specified
        version. The version ID itself is not restored.

        Args:
            dataset_id (str): Identifier for the dataset.
            version_id (str): Identifier for the version to roll back to.

        Returns:
            Dataset: The dataset instance with the rolled back data and metadata.

        Example:
            >>> catalog = Catalog(omixatlas_id='9')
            >>> new_dataset = catalog.rollback(dataset_id='GSE123', version_id='<uuid>')
        """
        version = self.get_version(dataset_id, version_id)

        if dataset_id in self:
            return self.update_dataset(
                dataset_id,
                data_type=version.data_type,
                metadata=version.metadata(),
                data=version.data_location,
                data_format=version.data_format,  # important: don't try to infer format
            )
        else:
            return self.create_dataset(
                dataset_id,
                data_type=version.data_type,
                data=version.data_location,
                metadata=version.metadata(),
                data_format=version.data_format,  # important: don't try to infer format
            )

    def __contains__(self, dataset_id: str):
        """
        Check if a dataset with the given dataset_id exists in the catalog.

        Args:
            dataset_id (str): Identifier for the dataset.

        Returns:
            bool: True if the dataset exists, False otherwise.
        """
        resp = self._session.get(
            f"{self._session.discover_url}/repositories/{self.omixatlas_id}/datasets/{dataset_id}"
        )
        if resp.status_code == 404:
            return False
        error_handler(resp)
        return True

    def __repr__(self):
        return f"Catalog(omixatlas_id='{self.omixatlas_id}')"


def copy_dataset(
    src_omixatlas_id: str,
    src_dataset_id: str,
    dest_omixatlas_id: str,
    dest_dataset_id: str,
    *,
    ingestion_params: Optional[dict] = None,
    **kwargs,
) -> Dataset:
    """
    Copies a dataset from one omixatlas catalog to another.

    The transfer happens remotely, the data is not downloaded locally.

    Args:
        src_omixatlas_id (str): The source omixatlas_id
        src_dataset_id (str): The source dataset_id
        dest_omixatlas_id (str): The destination omixatlas_id
        dest_dataset_id (str): The destination dataset_id

    Returns:
        Dataset: The newly created dataset in the destination catalog.
    """
    client_manager = _S3ClientManager(src_omixatlas_id, dest_omixatlas_id)
    bucket, prefix = client_manager.get_upload_path()

    src_catalog = Catalog(src_omixatlas_id)
    src_dataset = src_catalog.get_dataset(src_dataset_id)

    dest_path_without_extension = "s3://" + join_paths(
        bucket, prefix, f"v2/{dest_dataset_id}/{dest_dataset_id}"
    )
    extension = _extract_extension_from_s3_uri(src_dataset.data_location)

    s3_uri_with_version = copy_file(
        src_dataset.data_location,
        dest_path_without_extension + extension,
        s3_client=client_manager.get_client(),
    )
    dest_catalog = Catalog(dest_omixatlas_id)
    return dest_catalog.create_dataset(
        dest_dataset_id,
        src_dataset.data_type,
        data=s3_uri_with_version,
        metadata=src_dataset.metadata(),
        data_format=src_dataset.data_format,
        study_id=src_dataset.study_id,
        ingestion_params=ingestion_params,
        **kwargs,
    )
