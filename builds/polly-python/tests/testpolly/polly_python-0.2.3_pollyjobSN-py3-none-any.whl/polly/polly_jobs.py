from collections import UserString
from polly import helpers
from polly.auth import Polly
from polly import helpers, constants as const
from polly.errors import (
    InvalidParameterException,
    InvalidPathException
)
from polly.helpers import(
    get_user_details,
)
import pandas as pd
import os 
import json
class polly_jobs:
    """
    The polly_jobs class contains functions which can be used to create, cancel and monitor polly jobs, 

    ``Args:``
        |  ``token (str):`` token copy from polly.

    .. code::


            from polly.polly_jobs import polly_jobs
            # To use this class initialize a object like this if you are not authorised on polly
            jobs = polly_jobs(token)

    If you are authorised then you can initialize object without token to know about :ref:`authentication <auth>`.
    """

    def __init__(
        self,
        token=None,
        env="",
        default_env="polly",
    ) -> None:
        # check if COMPUTE_ENV_VARIABLE present or not
        # if COMPUTE_ENV_VARIABLE, give priority
        env = helpers.get_platform_value_from_env(
            const.COMPUTE_ENV_VARIABLE, default_env, env
        )
        self.session = Polly.get_session(token, env=env)
        self.base_url = f"https://v2.api.{self.session.env}.elucidata.io"
        self.discover_url = f"https://api.discover.{self.session.env}.elucidata.io"
    
    #project_id -> workspace_id
    #job_file -> json file 
    def submit_job(self, project_id : str ,job_file: str) -> pd.DataFrame: 
        if not (project_id and job_file): 
            raise InvalidParameterException("project_id")
        if not os.path.exists(job_file):
            raise InvalidPathException(job_file)
        try:
            with open (job_file, "r") as jobfile:
                jobData = json.load(jobfile)
        except Exception as err:
            raise err

        # TODO: add file validation for json 
        dict_secret_env_variables = self._get_secret_env_variables()
        if "secret_env" not in jobData:
            jobData['secret_env'] = {};
        jobData['secret_env']['POLLY_REFRESH_TOKEN'] = dict_secret_env_variables.get("refreshToken");
        jobData['secret_env']['POLLY_ID_TOKEN'] = dict_secret_env_variables.get("idToken");
        jobData['secret_env']['POLLY_WORKSPACE_ID'] = project_id;
        jobData['secret_env']['POLLY_USER'] = dict_secret_env_variables.get("email");
        #try without these. 
        jobData['secret_env']['POLLY_SUB'] = dict_secret_env_variables.get("sub");
        jobData['secret_env']['POLLY_EXP'] = dict_secret_env_variables.get("exp");
        jobData['secret_env']['POLLY_AUD'] = dict_secret_env_variables.get("aud");

        print("** added secret env variables *** Job data looks like this: ")
        print(jobData)

        job_post_data = self._submit_job_to_polly(project_id, jobData)
        submittedProject = job_post_data['data']
        print (submittedProject)
        # workspace_id = submittedProject['data']['project_id']
        # job_id = ['data']['job_id']
        # job_details = {"job_id": job_id, "job_details" : job_details}
        # return job_details
        # let tableData = [['Workspace ID', 'Job ID']]
        # tableData.push([submittedProject.data.project_id, submittedProject.data.job_id]);
        # pollymsg.pollySuccess("Submitted the job to run!");
        # pollymsg.pollyTable(tableData);

    def cancel_job(self, project_id : str ,job_file: str):
        return
        #TODO: figure this out. 
        #await axios.delete(jobUrl, await pollyHeaders.getV2Headers())


    def _submit_job_to_polly(self,project_id, job_data):
        print("***in _submit_job_to_polly ***")
        submitBody = { "data": {"type": "jobs","attributes": job_data}}

        self.base_url = f"https://v2.api.{self.session.env}.elucidata.io"
        self.jobUrl = f"{self.base_url}/projects/{project_id}/jobs"

        try:
            print("first try without any soecific headers.. ")
            resp1 = self.session.post(self.jobUrl, data=json.dumps(submitBody))
            print(resp1)
        except Exception as err:
            print ("Not able to submit job")
            raise err
        self._get_headers_for_job(job_data)
        #response = self.session.post(jobUrl, data=payload)
        try:
            print("*** sending  2nd API post request....") 
            print("*** url: " + self.jobUrl )
            print("*** data: " + submitBody)
            print("*** headers: " + self.session.headers)
            postData = self.session.post(self.jobUrl, data=json.dumps(submitBody))
            print(postData)
            #postData = await axios.post(jobUrl, submitBody, await pollyHeaders.getV2Headers());
        except Exception as err:
            print ("Not able to submit job")
            raise err
        return postData
    
    def _get_headers_for_job(self,job_data):
        print("**** in get headers for job.. adding cookie for job..")
        self.session.headers["Cookie"] = helpers.makeRequestCookieForPollyJob(job_data)
        #TODO: why are we doing this? 
        # if (pollyEnv.environment == 'local'):
        #     headers = { 
        #         headers : {
        #             'Content-Type': 'application/vnd.api+json'
        #         }
        #     }
        print(self.session.headers)

    def _get_secret_env_variables(self) -> dict:
        print("*** in get secret env variables.. ***")
        session = self.session
        dict_secret_env_variables={}
        user_details = get_user_details(self)
        # '''
        # {'license_info': {'license_accepted': True, 'accepted_at': 1663670665852}, 'active': True, 'user_id': 1663209871, 'created_at': 1663209871000, 'last_name': 'Nair', 'default_organization': None, 'first_name': 'Shilpa', 'search_key': 'shilpa nair::shilpa.nair@elucidata.io', 'email': 'shilpa.nair@elucidata.io', 'organizations': [{'org_id': 1, 'roles': [3]}], 'organization': 1}
        # '''
        dict_secret_env_variables["id"] = user_details.get("id")
        dict_secret_env_variables["type"] = user_details.get("type")
        dict_secret_env_variables["user_id"] = user_details.get("user_id")
        dict_secret_env_variables["email"] = user_details.get("email")
        dict_secret_env_variables["first_name"] = user_details.get("first_name")
        dict_secret_env_variables["last_name"] = user_details.get("last_name")
        dict_secret_env_variables["active"] = user_details.get("last_name")
        dict_secret_env_variables["created_at"] = user_details.get("created_at")
        dict_secret_env_variables["organizations"] = user_details.get("organizations")
        dict_secret_env_variables["polly_sub"] = os.getenv("POLLY_SUB")
        dict_secret_env_variables["polly_exp"] = os.getenv("POLLY_EXP")
        dict_secret_env_variables["refreshToken"] = os.getenv("POLLY_REFRESH_TOKEN")
        dict_secret_env_variables["idToken"] = os.getenv("POLLY_ID_TOKEN")
        dict_secret_env_variables["attributes"] = user_details
        dict_secret_env_variables["aud"] = os.getenv("POLLY_AUD")

        print("***returning dict_secret_env_variables: ")
        print(dict_secret_env_variables)
        print("****")

        return dict_secret_env_variables
    

    #     # need to create a dict of 
    #     # email
    #     # refresh_token 
    #     # pollyidToken
    #     # pollyExp
    #     # pollySub
    #     # pollyAud
        
        
        

