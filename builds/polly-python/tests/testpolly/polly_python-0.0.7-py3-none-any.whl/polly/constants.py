DATA_FORMATS = "https://elucidatainc.github.io/PublicAssets/internal_constants/data_formats.txt"
