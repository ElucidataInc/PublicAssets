from polly.auth import Polly
from polly.atlas import Atlas, Column, Table
import pandas as pd
from enum import Enum
from typing import Optional, List
import random
import time
import os
import random
import string
import json

DEV_POLLY_TOKEN = (
    "Z2ZxMjhzbmdtZDo6OUlSaUU1dlNkSDdoVHMyNUJpSDY3dU54cUc4azc3ZHFvUDdZUDRlMA=="
)
DEV_ENV = "devpolly"

TEST_POLLY_TOKEN = (
    "NDViZTBhZTQxYzo6YjI4ZWYwYWI4YmUwNWYwMDY1NDg1MDNjYzljOTRkNTRlNmI3NThjMQ=="
)
TEST_ENV = "testpolly"

Polly.auth(
    TEST_POLLY_TOKEN,
    env=TEST_ENV,
)
print("Authenticated")

##Instantiating new atlas
# atlas = Atlas(atlas_id="test_atlas")

# create_atlas(atlas_id="test_polly_atlas", atlas_name="test atlas")

atlas = Atlas(atlas_id="test_polly_atlas")

# sample_file_path = os.path.join(os.path.dirname(__file__), "sample_data.csv")
# atlas.delete_table("june_23")
# df = pd.read_csv(sample_file_path)
# df.set_index("gene", inplace=True)
# atlas.create_table_from_df(table_name="june_23", df=df)
# atlas.delete_table("nfwnfkw")
# sample_file_path = os.path.join(os.path.dirname(__file__), "customers-1000.csv")
# df = pd.read_csv(sample_file_path)
# df.set_index("index", inplace=True)
# # new_df = df[["gene", "dataset_id", "data_type", "negative_log10_padj"]]
# # new_df.set_index("gene", inplace=True)
# atlas.create_table_from_df("customer", df)

# table = atlas.get_table("customer")

# print(atlas.query("SELECT COUNT(*) FROM customer;", format="json"))

# print(atlas.query("SELECT * FROM june_23 LIMIT 10;", format="json"))
# print(atlas)
# print(atlas.get_name())
# print(atlas.list_tables())
# print(atlas.get_table("patient").list_columns())
# atlas.query("SELECT * FROM patient LIMIT 10;", format="json")
# patient = atlas.create_table(
#     table_name="new_table",
#     columns=[Column(name="patient_id", col_type="string", constraint="PRIMARY KEY")],
# )
# table = atlas.get_table("newtable")
# print(table.columns)
# table.add_column(Column(name="patient_name", col_type="string"))
# table.add_column(Column(name="patient_age", col_type="integer"))
# table.add_column(Column(name="patient_bmi", col_type="float"))
# print(table.columns)
# print(table.delete_column("patient_bmi"))
# print(table.columns)

# Get atlas info
# name = atlas.get_name()
# print(name)

# # List all tables in atlas
# tables = atlas.list_tables()
# print(tables)

# Load a particular table
# pythontable = atlas.get_table(table_name="pythontable")
# print(pythontable)

# Add a new table to atlas
# columns = [
#     Column(name="curated_patient_id", col_type="string", constraint="PRIMARY KEY"),
#     Column(name="alcohol_history", col_type="boolean"),
#     Column(name="alcohol_intensity", col_type="string"),
#     Column(name="tobacco_smoking", col_type="integer"),
# ]
# new_table = atlas.create_table(table_name="patient", columns=columns)
# print(new_table)
# all_tables = atlas.list_tables()
# print(all_tables)

# Delete a table
# atlas.delete_table(table_name="patient")
# all_tables = atlas.list_tables()
# print(all_tables)

# Instantiate a new table
# patient = Table(atlas_id="test_atlas", name="patient")
# print(patient)

# List columns of table
# columns = patient.list_columns()
# print(columns)

# Add a new column
# new_column = patient.add_column(Column(name="bmis", col_type="integer"))
# print(new_column)
# columns = patient.list_columns()  # To verify if columns were added
# print(columns)

# Delete a column
# patient.delete_column("bmis")
# print(patient.list_columns())

# Add data to table
# dummy_patients = [generate_dummy_patient() for _ in range(100000)]
# patient.add_rows(dummy_patients)


# Traversing through the table
# for page in patient.iter_rows():
#     print(page)


# Adding table from a dataframe
# data = {
#     "patient_id": [f"P{str(i).zfill(4)}" for i in range(1, 4500)],
#     "patient_name": [f"Patient_{i}" for i in range(1, 4500)],
#     "patient_age": [i for i in range(1, 4500)],
# }
# Creating the DataFrame
# df = pd.DataFrame(data)
# df.set_index("patient_id", inplace=True)
# atlas.create_table_from_df(table_name="very_big_table", df=df)

# print(atlas.list_tables())
# new_table = atlas.get_table(table_name="new_table")
# print(new_table)

# Query Atlas
# response = atlas.query("SELECT * FROM exposure LIMIT 1;", format="json")
# print(response)


# print(exposure.head())

# df = exposure.to_df()
# print(df)

# for page in new_table.iter_rows():
#     for record in page:
#         print(record)
#         if record["patient_id"] == "P0035":
#             break

# table = atlas.get_table(table_name="big_table")
# # print(table.to_df())
# script_dir = os.path.dirname(os.path.abspath(__file__))
# csv_file_path = os.path.join(script_dir, "sample_data.csv")
# df = pd.read_csv(csv_file_path)
# df.set_index("gene", inplace=True)
# atlas.create_table_from_df("logfile", df=df)


# def generate_dataframe(rows=10):
#     # Helper function to generate random strings
#     def random_string(length=8):
#         letters = string.ascii_lowercase
#         return "".join(random.choice(letters) for _ in range(length))

#     # Generate data for each column
#     data = {
#         "unique_id": list(range(1, rows + 1)),  # Unique integer column
#         "integers": [random.randint(1, 100) for _ in range(rows)],  # Integer column
#         "floats": [random.uniform(0, 100) for _ in range(rows)],  # Float column
#         "booleans": [
#             random.choice([True, False]) for _ in range(rows)
#         ],  # Boolean column
#         "strings": [random_string() for _ in range(rows)],  # String column
#     }

#     # Create DataFrame
#     df = pd.DataFrame(data)

#     return df


# df = generate_dataframe(4000)
# df.set_index("unique_id", inplace=True)
# atlas.create_table_from_df(table_name="stree_test", df=df)

# print(atlas.list_tables())
# table = atlas.get_table(table_name="very_big_table")
# # print(table)
# print(table.columns)
# print("       ")
# table.add_column(Column(name="snfjsnf", col_type="integer"))
# print(table.columns)
# print("       ")
# table.delete_column(column_name="snfjsnf")
# print(table.columns)
# print("       ")
# print(table.list_columns())

# test_table = atlas.get_table(table_name="patient")
# print(test_table.head())

# for rows in test_table.iter_rows():
#     print(rows)
#     break

# print(atlas.get_table("patient"))
# print(atlas.list_tables())
# df = atlas.query("SELECT * FROM patient LIMIT 10;")
# print(df.set_index("curated_patient_id", inplace=True))
# print(df)
# print(atlas.list_tables())
# table = atlas.get_table(table_name="stree_test")
# print(table.head())

# atlas.delete_table("june_23_06")
# sample_file_path = os.path.join(os.path.dirname(__file__), "sample_data.csv")
# df = pd.read_csv(sample_file_path)
# df.set_index("gene", inplace=True)
# atlas.create_table_from_df(table_name="june_23_06", df=df)
# records = df.to_json(orient="records")
# print(records)
# print(json.loads(records))

# atlas.create_table(
#     table_name="june_23_06",
#     columns=[Column(name="gene", col_type="string", constraint="PRIMARY KEY")],
# )
# atlas.delete_table("june_23_06")

# print(atlas.query("SELECT COUNT(*) FROM customer;", format="json"))
# for page in atlas.get_table("customer").iter_rows():
#     print(page)


# Atlas.create_atlas(atlas_id="test_polly_atlas_1", atlas_name="test atlas")

# print(atlas.get_table("customer").to_df())
# for page in atlas.get_table("customer").iter_rows():
#     print(page)


# script_dir = os.path.dirname(os.path.abspath(__file__))
# print(script_dir)
# csv_file_path = os.path.join(script_dir, "people-1000.csv")
# df = pd.read_csv(csv_file_path)
# df.set_index("pkey", inplace=True)
# atlas.create_table_from_df("peoples", df=df)

# # print(atlas.list_tables())
# # print(atlas.get_table("organization").to_df())
# # print(atlas.get_table("customer").head())


# table = atlas.get_table("people")
# table.update_rows(rows=[{"index": 5, "last_name": "Hauler"}])


atlases = Atlas.list_atlas()
print(atlases)


atlase = Atlas.create_atlas(atlas_id="nfnsffs", atlas_name="sjnfjsnf")
print(atlase)
