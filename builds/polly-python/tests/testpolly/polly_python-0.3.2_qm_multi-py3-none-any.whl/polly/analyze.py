from polly.auth import Polly
from polly import helpers
from polly import constants as const
from polly.omixatlas import OmixAtlas
from polly.errors import paramException
from polly.tracking import Track
from polly import omixatlas_hlpr
from polly.constants import COHORT_SUPPORTED_DATATYPES, COHORT_SUPPORTED_DATASOURCES

import pandas as pd
import plotly.express as px


class Analyze:
    """
    The Analyze class contains functions which can be used to identify cohorts in datasets, \
    perform differential expression and pathway analysis, and execute meta-analysis workflows.\
    Args:
        token (str): Authentication token from polly
    Usage:
        from polly.analyze import Analyze

        analysis = Analyze(token)
    """

    def __init__(self, token=None, env="", default_env="polly") -> None:
        # check if COMPUTE_ENV_VARIABLE present or not
        # if COMPUTE_ENV_VARIABLE, give priority
        env = helpers.get_platform_value_from_env(
            const.COMPUTE_ENV_VARIABLE, default_env, env
        )
        self.session = Polly.get_session(token, env=env)
        self.omixatlas_obj = OmixAtlas()
        self.elastic_url = (
            f"https://api.datalake.discover.{self.session.env}.elucidata.io/elastic/v2"
        )

    @Track.track_decorator
    def identify_cohorts(self, repo_key: str, dataset_id: str) -> pd.DataFrame:
        """
        This function is used to get the cohorts that can be created from samples in a GEO dataset.
        Please note: Currently only Bulk RNASeq datasets from GEO source are supported.
        If results are generated for other datatypes or datasource, they may be inaccurate.
        If you want to use this functionality for any other data type and source,
        please reach out to polly.support@elucidata.io
        Args:
            repo_key (int/str): repo_id or repo_name in str or int format
            dataset_id (str): dataset_id of the GEO dataset. eg. "GSE132270_GPL11154_raw"
        Returns:
            Dataframe showing values of samples across factors/cohorts.

        """
        # param checks
        omixatlas_hlpr.parameter_check_for_dataset_id(dataset_id)
        omixatlas_hlpr.parameter_check_for_repo_id(repo_key)
        repo_key = omixatlas_hlpr.make_repo_id_string(repo_key)

        # Get dataset level metadata and check if datatype is supported
        response_omixatlas = self.omixatlas_obj.omixatlas_summary(repo_key)
        data = response_omixatlas.get("data", "")
        index_name = data.get("indexes", {}).get("files", "")
        if index_name is None:
            raise paramException(
                title="Param Error", detail="Repo entered is not an omixatlas."
            )
        elastic_url = f"{self.elastic_url}/{index_name}/_search"
        query = helpers.elastic_query(index_name, dataset_id)
        metadata = helpers.get_metadata(self, elastic_url, query)
        source_info = metadata.get("_source", "")
        if (source_info["data_type"] not in COHORT_SUPPORTED_DATATYPES) or (
            source_info["dataset_source"] not in COHORT_SUPPORTED_DATASOURCES
        ):
            raise paramException(
                title="Param Error",
                detail="Only Bulk RNA Seq datasets that are from GEO are supported",
            )

        # Get sample level metadata
        col_metadata = self.omixatlas_obj.get_metadata(repo_key, dataset_id, "samples")
        # Index should be sample IDs which are available in geo_accession
        col_metadata = col_metadata.set_index("geo_accession")

        # Remove curated columns
        col_metadata = col_metadata.loc[
            :, ~col_metadata.columns.str.contains("curated", case=False)
        ]
        # Remove column with cohorts information if it exists
        col_metadata = col_metadata.drop(
            ["sample_characteristics"], axis=1, errors="ignore"
        )
        # Keeps only columns with more than 1 unique value
        col_metadata = col_metadata.loc[:, col_metadata.nunique() > 1]
        # Remove columns like sample id etc that has all unique values
        col_metadata = col_metadata.loc[:, col_metadata.nunique() != len(col_metadata)]
        # Fix for 'None entries cannot have not-None children' error in sunburst
        col_metadata = col_metadata.fillna("notgiven")

        # Get list of columns to plot in sunburst, in ascending order of nunique() values
        df = col_metadata
        df = pd.DataFrame(df.nunique()).reset_index()
        df = df.sort_values(by=[0])
        lst = df["index"].to_list()
        print("Factors based on which cohorts can be created for this dataset:", lst)

        # Plot sunburst
        fig = px.sunburst(col_metadata, path=lst)
        fig.show()
        return col_metadata[lst]
