import base64
from collections import namedtuple
from typing import Optional
from typing_extensions import Self
from polly.auth import Polly
from polly.errors import (
    InvalidParameterException,
    error_handler,
    InvalidPathException,
    AccessDeniedError,
)
from polly import helpers, session
from polly import constants as const
import logging
import pandas as pd
import json
import os
from polly.help import example, doc
from typing import Dict, List, Optional, Set
from requests import Session

class IPC:
    Tag = namedtuple("Tag", ["name", "ontology_id", "entity_type"])
    example = classmethod(example)
    doc = classmethod(doc)

    def __init__(self, token=None, env="", default_env="polly") -> None:
        # check if COMPUTE_ENV_VARIABLE present or not
        # if COMPUTE_ENV_VARIABLE, give priority
        env = helpers.get_platform_value_from_env(
            const.COMPUTE_ENV_VARIABLE, default_env, env
        )
        self.session = Polly.get_session(token, env=env)
        self.base_url = f"https://v2.api.{self.session.env}.elucidata.io"
        self.discover_url = f"https://api.discover.{self.session.env}.elucidata.io"
        self.elastic_url = (
            f"https://api.datalake.discover.{self.session.env}.elucidata.io/elastic/v2"
        )
        self.resource_url = f"{self.base_url}/v1/omixatlases"
        self.inference_url = f"https://api.discover.{self.session.env}.elucidata.io/curations/inferences/"
        print("INITALISED")
 
    def get_base_url_link(self):
        # dummy = {}
        # dummy["K"] = "V"
        return self.base_url

    def perform_inference(self, model_name: str, input_data: dict) -> dict:
        """
        This is a wrapper around model inference APIs
        It serializes input_data, calls the API for the given model_name and returns deserialized output

        Args:
            model_name (str): one of 'normalizer', 'biobert' and 'control-perturbation'
            input_data (dict): model input

        Returns:
            dict
        """
        #client = _get_client()
        print(self.inference_url)
        url = self.inference_url+ model_name
        print(url)
        #print(self.session.params)
        

        print("type of input_data in inference: " + str(type(input_data)))
        print(input_data)
        payload = {}
        payload = json.dumps({"data": {"attributes": input_data, "type": "curation"}})

        print(payload)
        # self.session.headers  = {
        #     'Content-Type': 'application/vnd.api+json',
        #     'Cookie': 'CognitoIdentityServiceProvider.3gphrakcgldiq04651jd6k773b.63daced0-256d-4f80-b1e2-c35fd4d2a985.accessToken=eyJraWQiOiJ3MkVVUHNuSXA0b1NBdDdGczR1VWg5NkM1UnArbjM2TzAxVytWdTF5cUpjPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI2M2RhY2VkMC0yNTZkLTRmODAtYjFlMi1jMzVmZDRkMmE5ODUiLCJldmVudF9pZCI6IjFmMDY1NWU5LWQ5NzctNDQzOS05ODU3LTEwMDY2OGRhYzc3MSIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiYXdzLmNvZ25pdG8uc2lnbmluLnVzZXIuYWRtaW4iLCJhdXRoX3RpbWUiOjE2NjE0Mjk2OTcsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC51cy13ZXN0LTIuYW1hem9uYXdzLmNvbVwvdXMtd2VzdC0yX2ZEV2QwVkNDZiIsImV4cCI6MTY2MjAzMjMyOCwiaWF0IjoxNjYyMDI4NzI4LCJqdGkiOiIxODkxYzk0OS1hZDE1LTRlYTAtYTc4OC1iMDAzNjUzYmYxM2YiLCJjbGllbnRfaWQiOiIzZ3BocmFrY2dsZGlxMDQ2NTFqZDZrNzczYiIsInVzZXJuYW1lIjoiNjNkYWNlZDAtMjU2ZC00ZjgwLWIxZTItYzM1ZmQ0ZDJhOTg1In0.bLueBmZ4Rk1G1pNhACLUyVCjVbsvOT7ed0f5AvzobHPsxKmPnpBDfgIW3uzaP5Ia4kk0TvZe2lpGBxPRrPDnE88oWEcU72-FW103qsR7ZchBSTm6eEaqsIuihcjc63_T_ES_ri6ubDOIK4vKd6OT_PHZF6VnLjKgP5YIFhvrg6xSMqm9QGhUVKzZGcQCWa2UeqnEFA3KNQEmIjIy9b_NiFGhoY1-y3fDNxzvBDXEMQ9XinyamUykVCnTTCCcuDxyZobI7XLwIIgetemHlLWbMwoYHERm9Q-vjPgawKYXDaZrPuCmKhg5pQrsW-hNOBRT_RlpMmjOehIA1bh18Z_8zg; CognitoIdentityServiceProvider.3gphrakcgldiq04651jd6k773b.63daced0-256d-4f80-b1e2-c35fd4d2a985.clockDrift=-2; CognitoIdentityServiceProvider.3gphrakcgldiq04651jd6k773b.63daced0-256d-4f80-b1e2-c35fd4d2a985.refreshToken=eyJjdHkiOiJKV1QiLCJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiUlNBLU9BRVAifQ.VvyeSkM9yvhRvgf35GPmh92ITwmKR-HKUln9xWRp8_DrwE7xHknUUWlmCS448VNNmdP5YIb1LrBbscb7zznXgqcgp6iCrAGsUFTIMvvBq4zxrVXITYm6GAK1PmiFxeOvohD6WLTkiGL6XmpB80I8LBzUlmBFkdz1QJnNM6mO9fnc70Gn8Aleb_VmvVMRrgfKWKyzQl7TC0A6QHMWbYnyz4Jm2VC1vgD_qEj6e4Havo-kamQKgZFef_0PCMNzcanOWV1Kgy_2G0NbcqquBDzFspB6pKXgV-soTFB44Fx_oMXI6EdESGUdWhwiKrsBdlUZFZKlWy_tDbTxbT5C6j9aGA.jhFIUpce2TZqB53l.VvvT82oYhFxfNVp4X8lYBGdeGKGpdVDTjZYOz74nfv5fojpTnuIAIUuGwK6sFguigkEBP584-tTXqttLT9OKgUYTgZyJkW2Z5vA7EITt8AlER3mByJfoFvtTpuJiwRfFUSk9FJ7WhK2h08VkC-T7-WdX0caQnvcrW-tPagbsPSW_67JQtGdmygr14Zc0MMmEaNRShmc0wPZrNCTC8Hxx2-4IxlRGscC2i1HubiY6YiDdNt7Hdw61-KMJLTuDjBFcjnTYpAjhJFWuIMdOs6y5e3zAE7frg-WCPzvFD09ILeJU2oH4j4LqyJ8SRDAvHLRIf_k6_L-8b-46xLVSEsossufbQdJ8PfF7VpvNlKgYpDQj0wLc-ZGVrXLW-U2LKrDh0bBoh311UjoJozNPmeezGmjBjJolIq0fuZUEB7z80Cwnq4ZG97o6AnfFKiYjztd_UUV3nYyEgs4YQJAvNurSx0hP1h-mMY60dTvjkVV3DDRexARIuY4MKU8S-RcmsmAQGVMTOAGMQKZJeeBZJMYCFmsoN4k2J1bmPKa1ARkoaQa1ETjKjbO0GYJ5NUSTQ4EfG0WO9OPXxI3-Fyq69yCKB3BezuAO3bSA36nPJldSS8XtXsUhLNTZDcR5RCXjrcFUCy5-XJ1yR01kX7hpg5dCkrzaJwlQcrPGeyaT1DcPY0omeEs0EUnYQg2eMxQrM1jb5LS8HqEZ9DZIfhwJ31_5m-HLpFYPAuJpsLh-HMIr-hob5LALo0M3b8v49eOoGK91plUN1DUa4oS4beZnxvuhb6wN-7XQeyrEfbeq_J6edql2Jv884cNX2nDgBksjiAtezYqb4W6MUJ1Dia-Ga5eqyytOvcHva-WzA6_NA1R8aEW__vpvzLqYn4_VIa5IIyNu-AHtDI83iNXt9nYWNsh8SWtbbcZcJuUW9bcWmia0ZuRqIrVsk0C6g2n7XZH0C_W5FJSTuIDnFhvVDrbJSKvMuMwlI7lCQyDHmlb0Dz5VKocmhwqT4O0dFcJsGQtcTuP58rIBAEexB0ysRTWmYSd6HCp-b1wEYkNKYukWEKim42IbBlaRveCkSHsnb8xpXjq5ZxrAlN5dF1jrn1Flg88At5QHvCwA5s0a4m4hnt8DR1xRNgvaQSqqi8lis_k3TdNEMOYKPBPI9VdBRefgPamNsdDtxDFyeqz9HZPjcCfCGeWLwGd_kIFYp4CRr4tr5DCWrtsvgn13JBWIWV-WsPhu2m4GCMnkQtEN2RF09Y9QETXb5SmN3RiVNrYsckrljJ27akxNE3b-M_RksoUAT_wNKFb3oHWDf5DSlcWHCnnJ0W1eM84n-POpysQHaUQ.IkH9dsQFimue4E4ZWpU8cg; CognitoIdentityServiceProvider.3gphrakcgldiq04651jd6k773b.LastAuthUser=63daced0-256d-4f80-b1e2-c35fd4d2a985'
        #     }
        # self.session.headers = {
        # 'Content-Type': 'application/vnd.api+json',
        # 'Cookie': 'refreshToken=eyJjdHkiOiJKV1QiLCJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiUlNBLU9BRVAifQ.VvyeSkM9yvhRvgf35GPmh92ITwmKR-HKUln9xWRp8_DrwE7xHknUUWlmCS448VNNmdP5YIb1LrBbscb7zznXgqcgp6iCrAGsUFTIMvvBq4zxrVXITYm6GAK1PmiFxeOvohD6WLTkiGL6XmpB80I8LBzUlmBFkdz1QJnNM6mO9fnc70Gn8Aleb_VmvVMRrgfKWKyzQl7TC0A6QHMWbYnyz4Jm2VC1vgD_qEj6e4Havo-kamQKgZFef_0PCMNzcanOWV1Kgy_2G0NbcqquBDzFspB6pKXgV-soTFB44Fx_oMXI6EdESGUdWhwiKrsBdlUZFZKlWy_tDbTxbT5C6j9aGA.jhFIUpce2TZqB53l.VvvT82oYhFxfNVp4X8lYBGdeGKGpdVDTjZYOz74nfv5fojpTnuIAIUuGwK6sFguigkEBP584-tTXqttLT9OKgUYTgZyJkW2Z5vA7EITt8AlER3mByJfoFvtTpuJiwRfFUSk9FJ7WhK2h08VkC-T7-WdX0caQnvcrW-tPagbsPSW_67JQtGdmygr14Zc0MMmEaNRShmc0wPZrNCTC8Hxx2-4IxlRGscC2i1HubiY6YiDdNt7Hdw61-KMJLTuDjBFcjnTYpAjhJFWuIMdOs6y5e3zAE7frg-WCPzvFD09ILeJU2oH4j4LqyJ8SRDAvHLRIf_k6_L-8b-46xLVSEsossufbQdJ8PfF7VpvNlKgYpDQj0wLc-ZGVrXLW-U2LKrDh0bBoh311UjoJozNPmeezGmjBjJolIq0fuZUEB7z80Cwnq4ZG97o6AnfFKiYjztd_UUV3nYyEgs4YQJAvNurSx0hP1h-mMY60dTvjkVV3DDRexARIuY4MKU8S-RcmsmAQGVMTOAGMQKZJeeBZJMYCFmsoN4k2J1bmPKa1ARkoaQa1ETjKjbO0GYJ5NUSTQ4EfG0WO9OPXxI3-Fyq69yCKB3BezuAO3bSA36nPJldSS8XtXsUhLNTZDcR5RCXjrcFUCy5-XJ1yR01kX7hpg5dCkrzaJwlQcrPGeyaT1DcPY0omeEs0EUnYQg2eMxQrM1jb5LS8HqEZ9DZIfhwJ31_5m-HLpFYPAuJpsLh-HMIr-hob5LALo0M3b8v49eOoGK91plUN1DUa4oS4beZnxvuhb6wN-7XQeyrEfbeq_J6edql2Jv884cNX2nDgBksjiAtezYqb4W6MUJ1Dia-Ga5eqyytOvcHva-WzA6_NA1R8aEW__vpvzLqYn4_VIa5IIyNu-AHtDI83iNXt9nYWNsh8SWtbbcZcJuUW9bcWmia0ZuRqIrVsk0C6g2n7XZH0C_W5FJSTuIDnFhvVDrbJSKvMuMwlI7lCQyDHmlb0Dz5VKocmhwqT4O0dFcJsGQtcTuP58rIBAEexB0ysRTWmYSd6HCp-b1wEYkNKYukWEKim42IbBlaRveCkSHsnb8xpXjq5ZxrAlN5dF1jrn1Flg88At5QHvCwA5s0a4m4hnt8DR1xRNgvaQSqqi8lis_k3TdNEMOYKPBPI9VdBRefgPamNsdDtxDFyeqz9HZPjcCfCGeWLwGd_kIFYp4CRr4tr5DCWrtsvgn13JBWIWV-WsPhu2m4GCMnkQtEN2RF09Y9QETXb5SmN3RiVNrYsckrljJ27akxNE3b-M_RksoUAT_wNKFb3oHWDf5DSlcWHCnnJ0W1eM84n-POpysQHaUQ.IkH9dsQFimue4E4ZWpU8cg'
        # }
        print(self.session.headers)
        
        response = self.session.post(url, data=payload)
        print(response.cookies)
        print(response.headers)
        print(response.status_code)

        if response.status_code != 201:
            print("Response: ", response.text)
            raise Exception(f"Server responded with {response.status_code}")

        try:
            print("status code from response is: " + str(response.status_code))
            response = response.json()
        except json.JSONDecodeError as e:
            print("response: ", response.text)
            raise e

        print("RETURNING RESPONSE : ")
        print(response)

        if "data" in response:
            return response["data"]

        return response


    def normalize(
        self,
        mention: str,
        entity_type: str,
        context: Optional[str] = None,
        threshold: Optional[float] = None,
    ) -> dict:
        """Map a given mention (keyword) to an ontology term.

        Args:
            mention (str): mention of an entity e.g. "Cadiac arrythmia"
            entity_type (str): Should be one of ['disease', 'drug', 'tissue', 'cell_type', 'cell_line', 'species', 'gene']

        Kwargs:
            context (Optional[str]): The text where the mention occurs. This is used to resolve abbreviations

        Returns:
            dict

        """
        # TODO: Composite mentions?
        data = {
            "mention": {
                "keyword": mention,
                "entity_type": entity_type,
                "threshold": threshold,
            }
        }

        if context:
            data["context"] = context
        output = self.perform_inference("normalizer", data)

        if "term" not in output:
            return {
                "ontology": "CUI-less",
                "ontology_id": None,
                "name": None,
                "entity_type": entity_type,
            }

        return output["term"]

    def run_ner( self,
    text: str, threshold: Optional[float] = None, normalize_output: bool = False
):
        """Run an NER model on the given text. The returned value is a list of entities along with span info.

        Args:
            text (str): input text

        Kwargs:
            normalize_output (bool): whether to normalize the keywords

        Returns:
            entities (List[dict]): returns a list of spans, each span contains the keyword, start and end index of the keyword and the entity type
        """
        # TODO: If text is too long, break it up into chunks small enough for biobert

        payload = {"text": text}
        if threshold:
            payload["threshold"] = threshold
        response = self.perform_inference("biobert", payload)
        try:
            entities = response["entities"]
        except KeyError as e:
            print(response)
            raise e

        # TODO: fetch this list from the server maybe?
        supported_types = [
            "disease",
            "drug",
            "species",
            "tissue",
            "cell_type",
            "cell_line",
            "gene",
        ]

        if normalize_output:
            for entity in entities:

                # don't call `normalize` for unsupported entity types
                if entity["entity_type"] not in supported_types:
                    entity["name"] = None
                    continue
                norm = self.normalize(entity["keyword"], entity["entity_type"], text)
                if norm["ontology"] == "CUI-less":
                    entity["name"] = None
                else:
                    entity["ontology_id"] = norm["ontology"] + ":" + norm["ontology_id"]
                    entity["name"] = norm["name"]
        return entities

    
    def tag(self, text: str) -> List[Tag]:
        
        """
        Tag a given piece of text. A "tag" is just an ontology term.

        This function calls `run_ner` followed by `normalize`

        Args:
            text (str): Input text

        Returns:
            tags (set of tuples): set of unique tags
        """
        # TODO: remove non specific

        entities = self.run_ner(text, normalize_output=True)
        res = {
            self.Tag(e["name"], e["ontology_id"], e["entity_type"])
            for e in entities
            if e["name"]
        }
        print("list(res) in tag function")
        print(list(res))
        return list(res)
