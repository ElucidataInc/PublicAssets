# coding: utf-8
import os
import sys
import random
import string
import urllib
import subprocess
import pytest
from polly.data_management import copy_dataset, Catalog
from polly.auth import Polly
from polly.errors import RequestException

ENV = os.getenv("ENV")
POLLY_TOKEN = os.getenv("POLLY_TOKEN")

if not ENV or not POLLY_TOKEN:
    raise ValueError("Both ENV and POLLY_TOKEN environment variables must be set.")

if ENV not in ["devpolly", "testpolly"]:
    raise ValueError(f"env needs to be one of 'testpolly' and 'devpolly', not {ENV}")


def print_colored(message, color_code):
    """
    Prints a message in the terminal with the specified ANSI color code.
    """
    print(f"\033[{color_code}m{message}\033[0m")


# ANSI color codes
GREEN = "32"
RED = "31"
DARK_GREY = "85"


@pytest.fixture(scope="session")
def _polly():
    Polly.auth(token=POLLY_TOKEN, env=ENV)


@pytest.fixture(scope="session")
def catalog(_polly):
    if ENV == "devpolly":
        catalog = Catalog("1697567891577")
    elif ENV == "testpolly":
        catalog = Catalog("1649664527538")  # type_cell_viability_assay (3760 datasets)
    else:
        raise ValueError()
    return catalog


@pytest.fixture(scope="session")
def another_catalog(_polly):
    if ENV == "devpolly":
        another_catalog = Catalog("1645074792149")
    elif ENV == "testpolly":
        another_catalog = Catalog("1673411159486")  # bulk_rnaseq_atlas
    else:
        raise ValueError()
    return another_catalog


@pytest.fixture(scope="session")
def anndata():
    subprocess.check_call([sys.executable, "-m", "pip", "install", "anndata"])
    import anndata

    yield anndata
    subprocess.check_call([sys.executable, "-m", "pip", "uninstall", "-y", "anndata"])


sample_h5ad_url = (
    "https://raw.githubusercontent.com/ElucidataInc/PublicAssets"
    "/master/internal-user/add_dataset_test_file/sample_dataset.h5ad"
)
sample_gct_url = (
    "https://raw.githubusercontent.com/ElucidataInc/PublicAssets"
    "/master/internal-user/add_dataset_test_file/GSE15553_GPL570.gct"
)

file_extensions = [".h5seurat", ".maf", ".vcf", ".bam", ".csv", ".rds"]


def _insert_random_data(path):
    # Generate random binary data
    data = os.urandom(1024 * 1024)

    # Write the random data to the file
    with open(path, "wb") as f:
        f.write(data)

    return path


@pytest.fixture(scope="function", params=file_extensions)
def random_data_file(request, tmp_path):
    file_extension = request.param
    file_path = tmp_path / f"random_data{file_extension}"

    _insert_random_data(file_path)

    # Return the path to the file
    return str(file_path)


def generate_random_study_id():
    """
    Generates a random study ID with a 5-letter word prefixed by 'study_'.
    """
    letters = string.ascii_lowercase
    random_word = "".join(random.choice(letters) for i in range(5))
    return f"test_study_{random_word}"


def generate_random_dataset_id():
    """
    Generates a random dataset ID with a 5-letter word prefixed by 'dataset_'.
    """
    letters = string.ascii_lowercase
    random_word = "".join(random.choice(letters) for i in range(5))
    return f"test_dataset_{random_word}"


def test_list_datasets(catalog):
    datasets = catalog.list_datasets()
    for dataset in datasets[:5]:
        print_colored(dataset, DARK_GREY)


def test_list_datasets_with_limit(catalog):
    datasets = catalog.list_datasets(limit=13)
    assert len(datasets) == 13


def test_list_datasets_prefetch_metadata(catalog):
    datasets = catalog.list_datasets(prefetch_metadata=True)
    for dataset in datasets[:5]:
        print_colored(dataset.metadata(), DARK_GREY)


@pytest.fixture(
    scope="session", params=[(sample_gct_url, ".gct"), (sample_h5ad_url, ".h5ad")]
)
def sample_file(request, tmp_path_factory):
    file_url, file_ext = request.param
    # Create a temporary directory that will be used for the session
    temp_dir = tmp_path_factory.mktemp("data")
    file_path = temp_dir / ("sample_file" + file_ext)

    # Download the sample .gct file to the temporary file
    urllib.request.urlretrieve(file_url, file_path)

    # TODO: remove the `str` after posixpath for `data` parameter of `catalog.create_dataset`
    return str(file_path)


@pytest.fixture(scope="session")
def sample_gct_file(tmp_path_factory):
    """
    Pytest fixture to download the sample GCT file and make it available to tests.
    """
    # Create a temporary directory that will be used for the session
    temp_dir = tmp_path_factory.mktemp("data")
    gct_file = temp_dir / "sample_dataset.gct"

    # Download the sample .gct file to the temporary file
    urllib.request.urlretrieve(sample_gct_url, gct_file)

    return gct_file


@pytest.fixture(scope="session")
def sample_h5ad_file(tmp_path_factory):
    """
    Pytest fixture to download the sample H5AD file and make it available to tests.
    """
    # Create a temporary directory that will be used for the session
    temp_dir = tmp_path_factory.mktemp("data")
    h5ad_file = temp_dir / "sample_dataset.h5ad"

    urllib.request.urlretrieve(sample_h5ad_url, h5ad_file)

    return h5ad_file


@pytest.fixture(params=[("PMID123", ["GSE_YOYO.rds"]), (None, [])])
def dataset(request, catalog, sample_gct_file, tmp_path):
    """
    Pytest fixture to create a dummy dataset using the sample GCT file.
    """
    study_id, sup_file_names = request.param
    test_dataset_id = generate_random_dataset_id()

    # Create a test dataset
    dataset = catalog.create_dataset(
        dataset_id=test_dataset_id,
        data_type="Test Data",
        data=str(sample_gct_file),
        metadata={"description": "some description"},
        study_id=study_id,
    )
    for name in sup_file_names:
        file_path = tmp_path / name
        _insert_random_data(file_path)
        catalog.attach_file(test_dataset_id, path=str(file_path))

    print_colored(dataset, DARK_GREY)

    yield dataset

    # Cleanup after the test session is done
    catalog.delete_dataset(dataset_id=test_dataset_id)


@pytest.fixture()
def persistent_dataset(catalog, sample_gct_file):
    """
    This fixture does not perform any cleanup after the test session.
    """
    test_dataset_id = generate_random_dataset_id()
    dataset = catalog.create_dataset(
        dataset_id=test_dataset_id,
        data_type="Test Data",
        data=str(sample_gct_file),
        metadata={"description": "that ultimate dataset", "hello": 123},
    )
    print_colored(dataset, DARK_GREY)

    yield dataset
    # No cleanup code here, so the dataset will persist after the test session ends


def test_rollback(catalog, dataset):
    """
    Tests the rollback functionality of the Catalog class to ensure that a dataset
    can be successfully reverted to a previous version.
    """
    dataset_id = dataset.dataset_id

    # Update the dataset to create a new version
    catalog.update_dataset(
        dataset_id=dataset_id,
        metadata={"description": "Updated dataset description"},
    )

    # Rollback to the original version
    _ = catalog.rollback(
        dataset_id=dataset_id,
        version_id=dataset.version_id,
    )
    rollback_dataset = catalog.get_dataset(dataset_id)
    print_colored(rollback_dataset, DARK_GREY)

    # Assert that the rollback was successful
    assert rollback_dataset.metadata() == dataset.metadata()
    assert rollback_dataset.data_location == dataset.data_location


def test_delete_dataset_and_list_deleted_versions(catalog, persistent_dataset):
    """
    Tests the delete_dataset method followed by list_deleted_versions to ensure that
    a dataset can be successfully deleted and then listed among deleted versions.
    """
    test_dataset_id = persistent_dataset.dataset_id

    # Delete the created dataset
    catalog.delete_dataset(dataset_id=test_dataset_id)

    # List deleted versions of the dataset
    deleted_versions = catalog.list_versions(test_dataset_id, include_deleted=True)

    # Assert that the deleted version is present in the list
    assert any(
        version.version_id == persistent_dataset.version_id
        for version in deleted_versions
    )


def test_creation_from_adata(catalog, anndata, sample_h5ad_file):
    adata = anndata.read_h5ad(sample_h5ad_file)

    test_dataset_id = generate_random_dataset_id()
    metadata = {"description": "Test dataset for load function"}

    # Create a test dataset from adata object
    dataset = catalog.create_dataset(
        dataset_id=test_dataset_id,
        data_type="Test Data",
        data=adata,
        metadata=metadata,
    )
    _ = dataset.load()

    # cleanup
    catalog.delete_dataset(test_dataset_id)


def test_dataset_download(catalog, sample_file, anndata):
    """
    Tests the {Dataset,DatasetVersion}.{load,download}
    functions to ensure that data can be downloaded correctly.
    """
    test_dataset_id = generate_random_dataset_id()
    metadata = {"description": "Test dataset for load function"}

    # Create a test dataset
    _ = catalog.create_dataset(
        dataset_id=test_dataset_id,
        data_type="Test Data",
        data=sample_file,
        metadata=metadata,
    )

    # Load the dataset
    test_dataset = catalog.get_dataset(test_dataset_id)
    _ = test_dataset.load()

    path = test_dataset.download("./")
    print_colored(f"File downloaded at: {path}", DARK_GREY)
    assert os.path.exists(path)
    if os.path.exists(path):
        os.remove(path)

    assert test_dataset.metadata() == metadata

    # Load the version
    version = catalog.get_version(
        dataset_id=test_dataset_id, version_id=test_dataset.version_id
    )
    _ = version.load()

    path = version.download("./")
    print_colored(f"File downloaded at: {path}", DARK_GREY)
    assert os.path.exists(path)
    if os.path.exists(path):
        os.remove(path)

    assert version.metadata() == metadata

    # Clean up test data
    catalog.delete_dataset(dataset_id=test_dataset_id)


def test_copy_dataset(catalog, another_catalog, dataset):
    """
    Tests the copy_dataset function to ensure a dataset
    can be copied from one catalog to another.
    """
    dest_dataset_id = generate_random_dataset_id()

    # Copy the dataset to the destination catalog
    dest_dataset = copy_dataset(
        src_omixatlas_id=catalog.omixatlas_id,
        src_dataset_id=dataset.dataset_id,
        dest_omixatlas_id=another_catalog.omixatlas_id,
        dest_dataset_id=dest_dataset_id,
    )

    assert dest_dataset_id in another_catalog
    assert dataset.data_type == dest_dataset.data_type
    assert dataset.metadata() == dest_dataset.metadata()
    assert dataset.study_id == dest_dataset.study_id

    # Clean up test data from other catalog
    another_catalog.delete_dataset(dataset_id=dest_dataset_id)


def test_copy_dataset_within_same_catalog(catalog, dataset):
    """
    Tests the copy_dataset function to ensure a dataset
    can be copied within the same catalog.
    """
    dest_dataset_id = generate_random_dataset_id()

    # Copy the dataset within the same catalog
    dest_dataset = copy_dataset(
        src_omixatlas_id=catalog.omixatlas_id,
        src_dataset_id=dataset.dataset_id,
        dest_omixatlas_id=catalog.omixatlas_id,
        dest_dataset_id=dest_dataset_id,
    )

    assert dest_dataset_id in catalog
    assert dataset.data_type == dest_dataset.data_type
    assert dataset.metadata() == dest_dataset.metadata()
    assert dataset.study_id == dest_dataset.study_id
    # copying within the same catalog doesn't make a physical copy of file
    assert dataset.data_location == dest_dataset.data_location

    # Clean up destination data from the catalog
    catalog.delete_dataset(dataset_id=dest_dataset_id)


def test_set_parent_study_list_studies_and_datasets_in_study(catalog, dataset):
    """
    Tests the set_parent_study, list_studies, and list_datasets_in_study functions
    to ensure a dataset can be assigned to a study and the study and datasets can
    be listed correctly.
    """
    test_dataset_id = dataset.dataset_id
    test_study_id = generate_random_study_id()

    # Set the parent study
    catalog.set_parent_study(dataset_id=test_dataset_id, study_id=test_study_id)

    assert catalog.get_dataset(test_dataset_id).study_id == test_study_id

    # Verify that the study is listed in the catalog
    studies = catalog.list_studies()
    assert test_study_id in studies

    # Verify that the dataset is listed under the study
    datasets_in_study = catalog.list_datasets_in_study(study_id=test_study_id)
    assert test_dataset_id in datasets_in_study


def test_attach_supplementary_file(catalog, dataset, random_data_file, tmp_path):
    dataset_id = dataset.dataset_id
    file_path = random_data_file
    actual_file_name = os.path.basename(file_path)
    actual_format = actual_file_name.split(".")[1]
    if actual_file_name.endswith("gz"):
        actual_format = actual_format + "+gzip"

    # Attach the file to the dataset
    f = catalog.attach_file(dataset_id, file_path)
    # Overwriting file shouldn't throw an error
    # Also, path should accept s3 location
    catalog.attach_file(
        dataset_id,
        path=f.file_location,
        tag="MAJOR LAZER",
        file_name=f.file_name,
        file_format=f.file_format,
    )

    # Retrieve the list of supplementary files to verify attachment
    supplementary_files = catalog.list_files(dataset_id=dataset_id)

    # Assert that the file is in the list of supplementary files
    assert any(file.file_name == actual_file_name for file in supplementary_files)

    # Retrieve the list of supplementary files to verify attachment
    file = catalog.get_file(dataset_id, actual_file_name)

    assert file.dataset_id == dataset.dataset_id
    assert file.derived_from is None
    assert file.file_format == actual_format
    assert file.tag == "MAJOR LAZER"
    assert file.omixatlas_id == catalog.omixatlas_id
    file.download(str(tmp_path / "here"))

    catalog.delete_file(dataset_id, actual_file_name)


def test_attach_supplementary_file_to_version(
    catalog, dataset, sample_gct_file, sample_h5ad_file
):
    file_name = "brrrrr_file"
    sup_file = catalog.attach_file(
        dataset.dataset_id,
        str(sample_gct_file),
        source_version_id=dataset.version_id,
        file_name=file_name,
    )

    catalog.get_file(dataset.dataset_id, file_name)

    assert sup_file.derived_from == dataset.data_location
    assert sup_file.file_format == "gct"

    catalog.update_dataset(dataset.dataset_id, data=str(sample_h5ad_file))

    with pytest.raises(RequestException):
        catalog.get_file(dataset.dataset_id, file_name)
