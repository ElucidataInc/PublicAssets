from polly_interfaces.IFiles import IFiles
from polly import helpers
from polly_services.files import files_hlpr
import pandas as pd
from polly import constants as const
import time


class Files(IFiles):
    def __init__(self):
        pass

    def add_datasets(
        self,
        polly_session,
        repo_id: int,
        source_folder_path: dict,
        priority="low",
        validation=False,
    ):
        """Function to ingest the dataset and metadata in omixatlas

        Args:
            polly_session (_type_): _description_
            repo_id (int): _description_
            source_folder_path (dict): _description_
            priority (str, optional): _description_. Defaults to "low".
            validation (bool, optional): _description_. Defaults to False.

        Returns:
            _type_: _description_
        """

        files_hlpr.parameter_check_for_add_dataset(
            repo_id, source_folder_path, priority
        )

        data_file_list, metadata_file_list = files_hlpr.create_file_list(
            source_folder_path
        )

        # data metadata file mapping
        # initial data metadata mapping dict containing all the files
        data_metadata_mapping = files_hlpr.map_data_metadata_files(
            data_file_list, metadata_file_list, source_folder_path
        )

        validation_dataset_lvl = {}
        if validation:
            validation_dataset_lvl = files_hlpr.check_status_file(source_folder_path)
            (
                data_file_list,
                metadata_file_list,
            ) = files_hlpr.filter_files_after_dataset_lvl_validation(
                data_file_list,
                metadata_file_list,
                validation_dataset_lvl,
                source_folder_path,
                data_metadata_mapping,
            )
            # create data_metadata_mapping again with filtered files after validation
            data_metadata_mapping = files_hlpr.map_data_metadata_files_after_validation(
                data_file_list, metadata_file_list
            )

        # sai has confirmed -> every file will have same tokens
        # does not depend on the destination folder -> so empty destination
        # folder also ok
        (
            session_tokens,
            bucket_name,
            package_name,
            metadata_directory,
        ) = files_hlpr.get_session_tokens(polly_session, repo_id)

        # folder paths
        data_source_folder_path = source_folder_path["data"]
        metadata_source_folder_path = source_folder_path["metadata"]

        # Upload details
        metadata_upload_details = {
            "session_tokens": session_tokens,
            "bucket_name": bucket_name,
            "metadata_directory": metadata_directory,
        }
        data_upload_details = {
            "session_tokens": session_tokens,
            "bucket_name": bucket_name,
            "package_name": package_name,
        }

        # list of list which will store all the results
        # at last assign it to a dataframe
        result_list = []
        file_status_dict = {}

        # data_file_list also passed because the metadata files
        # which have been skipped in the ingestion -> its corresponding 
        # data files also need to be removed from the list
        file_status_dict, data_file_list = files_hlpr.upload_metadata_in_add(
            polly_session,
            repo_id,
            priority,
            metadata_file_list,
            metadata_upload_details,
            metadata_source_folder_path,
            file_status_dict,
            data_metadata_mapping,
            data_file_list
        )

        file_status_dict = files_hlpr.upload_data_in_add(
            repo_id,
            data_file_list,
            data_upload_details,
            data_source_folder_path,
            file_status_dict,
            polly_session,
        )

        # iterating the status dict
        # generating appropriate messages
        data_upload_results_df = pd.DataFrame()

        if file_status_dict:
            result_list = files_hlpr.generating_response_from_status_dict(
                file_status_dict, result_list
            )

            # generating DF
            data_upload_results_df = pd.DataFrame(
                result_list, columns=["File Name", "Message"]
            )
            # print message before delay
            print(const.WAIT_FOR_COMMIT)
            # delay added after the files are uploaded
            # before commit API is hit
            time.sleep(30)
            files_hlpr.commit_data_to_repo(polly_session, repo_id)
            files_hlpr.print_dataframe(800, 800, 1200, data_upload_results_df)

        if validation:
            print("\n")
            print("-----Files which are Not Validated-------")
            helpers.display_df_from_list(
                files_hlpr.dataset_level_metadata_files_not_uploaded,
                "Invalid Metadata Files",
            )
            print("\n")
            helpers.display_df_from_list(
                files_hlpr.data_files_whose_metadata_failed_validation,
                "Invalid Data Files",
            )

        # reset global variables storing validation results
        # flushes out the previous state of variables and creates
        # new state
        files_hlpr.reset_global_variables_with_validation_results()
        return data_upload_results_df

    def update_datasets(
        self,
        polly_session,
        repo_id: int,
        source_folder_path: dict,
        priority="low",
        file_mapping=[],
        validation=False,
    ):
        pass

    def delete_datasets(
        self, polly_session, repo_id: int, dataset_ids: list, dataset_file_path_dict={}
    ):
        pass

    def get_all_file_paths(
        self, polly_session, repo_id: int, dataset_id: str, internal_call=False
    ):
        pass
