#!/usr/bin/env python3


def inner_function(a: str):
    try:
        x = 1 / 0
    except Exception as err:
        print("EEEEEEE")
        raise err
        # return err


def main():
    try:
        for i in range(1, 10, 1):
            inner_function("abc")
    except Exception as err:
        print("ac,hfbkvyuafv")
        # print(err)
        # raise err

    # inner_function("abc")


if __name__ == "__main__":
    main()


from io import StringIO
import sys
import inspect


class Capturing(list):
    def __enter__(self):
        self._stdout = sys.stdout
        sys.stdout = self._stringio = StringIO()
        return self

    def __exit__(self, *args):
        self.extend(self._stringio.getvalue().splitlines())
        del self._stringio  # free up some memory
        sys.stdout = self._stdout


def test():
    valid_function = []
    help_present_hai = []
    help_not_present = []
    for i in inspect.getmembers(
        omixatlas, predicate=inspect.ismethod
    ):  # this is my condition list
        if not i[0].startswith(
            "_"
        ):  # this is the mechanism to choose the right function
            # valid_function.append(i[0])
            result = help(i[1])


docs_present_omixatlas = []
with Capturing() as output:
    test()
# print('output:', output)
for i in output:
    if "Help on method" in i:
        method = i.replace("Help on method", "").split("in module")[0].strip()
        docs_present_omixatlas.append(method)
docs_present_omixatlas
# print(len(docs_present_omixatlas))

omixatlas_memebers = []
for i in inspect.getmembers(omixatlas, predicate=inspect.ismethod):
    if not i[0].startswith("_"):
        omixatlas_memebers.append(i[0])
        print(i[0])
print(len(omixatlas_memebers))

______________


def test(class_name):
    """
    fucntion which will call the help on the members of the class
    """
    valid_function = []
    help_present_hai = []
    help_not_present = []
    for i in inspect.getmembers(
        class_name, predicate=inspect.ismethod
    ):  # this is my condition list
        if not i[0].startswith(
            "_"
        ):  # this is the mechanism to choose the right function
            # valid_function.append(i[0])
            result = help(i[1])


for class_name in ["Polly", "omixatlas", "workspaces", "cohort", "curation", "session"]:
    print("checking for class: " + class_name)
    class_members = []
    for i in inspect.getmembers(class_name, predicate=inspect.ismethod):
        if not i[0].startswith("_"):
            class_members.append(i[0])

    docs_present_omixatlas = []
    with Capturing() as output:
        test(class_name=class_name)
        # print('output:', output)
        for i in output:
            if "Help on method" in i:
                method = i.replace("Help on method", "").split("in module")[0].strip()
                docs_present_omixatlas.append(method)
    if len(docs_present_omixatlas) != len(class_members):
        print(f"ERROR FOR :{class_name}")


def _get_data_file_for_metadata_file(
    self,
    repo_id: str,
    metadata_file_name: str,
    data_metadata_mapping: dict,
    destination_folder_path: str,
) -> str:
    """Give the data file name for corresponding metadata file

    Args:
        repo_id (str): Repo id of the omixatlas
        metadata_file_name(str): Name of the metadata file
        data_metadata_mapping (dict): Dict containing the mapping of data and metadata files

    Returns:
        Data File Name with Extension
    """
    file_name = pathlib.Path(metadata_file_name).stem
    # fetching data file for corresponding metadata file name
    data_file_name = data_metadata_mapping.get(file_name, "")
    # in order to reuse this function for update dataset wherein a valid case
    # is : just a metadata file is present in source folder and no corresponding
    # data file is present in source folder.
    # in this case file will not be present in data_metadata mapping dict

    if not data_file_name:
        try:
            corresponding_data_file_names = (
                self._get_data_file_from_oa_for_metadata_update(
                    repo_id, metadata_file_name
                )
            )
            possible_data_file = ""

            if not corresponding_data_file_names:
                data_file_name_without_path = ""
                # TODO: print warnig that no such file was present in the OA
            else:
                for data_file in corresponding_data_file_names:
                    # loop
                    # comparing dir path of the file in OA to the provided destination folder path.
                    if os.path.normpath(os.path.dirname(data_file)) == os.path.normpath(
                        destination_folder_path
                    ):
                        possible_data_file = data_file
                if not possible_data_file:
                    # print("****possible_data_file is empty****")
                    warnings.simplefilter("always", UserWarning)
                    warnings.formatwarning = (
                        lambda msg, *args, **kwargs: f"WARNING: {msg}\n"
                    )
                    # case1: if no dest provided on add, but new in dest in update
                    # case2: if dest on add is different from dest in update
                    # case3: if dest in add and no dest in update - if only 1 folder - take that as the dest folder
                    valid_folder_list = helpers.get_folder_list_from_list_of_filepaths(
                        corresponding_data_file_names
                    )
                    # if file is present in only one folder in the OA
                    if len(valid_folder_list) == 1:
                        if os.path.normpath(destination_folder_path) == ".":
                            # case3: if dest in add and no dest in update - if only 1 folder - take that as the dest folder
                            # no warning that we are taking this folder as destination folder.
                            # print("warning that we are taking this folder as destination folder. ")
                            updated_destination_folder_path = valid_folder_list[0]
                            return data_file_name, updated_destination_folder_path
                        elif (
                            os.path.normpath(os.path.dirname(valid_folder_list[0]))
                            == "."
                        ):
                            # case 1: if no dest provided on add, but new in dest in update
                            warnings.warn(
                                "The dataset couldn’t be found in the destination folder you provided. "
                                + "Instead, it’s in the root directory. Please use the function without"
                                + " any destination folder path input."
                                + " \nFor any questions, please reach out to polly.support@elucidata.io. "
                            )
                    if len(valid_folder_list) > 1:
                        if os.path.normpath(destination_folder_path) == ".":
                            warnings.warn(
                                "The metadata for "
                                + metadata_file_name
                                + " couldn't be updated."
                                + "Sorry, this Dataset ID was found in the following folders:\n "
                                + str(valid_folder_list)
                                + ".Please pick the appropriate destination folder and try updating the data again."
                            )
                        else:
                            warnings.warn(
                                "The metadata for "
                                + metadata_file_name
                                + " couldn't be updated."
                                + "The dataset couldn’t be found in the destination folder you provided."
                                + "Instead, we found this data in the following folders:"
                                + str(valid_folder_list)
                                + "Please pick the appropriate destination folder and try updating the data again."
                                + ".\n For any questions, please reach out to polly.support@elucidata.io. "
                            )

                data_file_name_without_path = os.path.basename(possible_data_file)
        except Exception as err:
            raise err
        return data_file_name_without_path, ""
    else:
        return data_file_name, ""
