metadata_upload_url = {
    "metadata_upload_url": {
    "url": "https://discover-test-datalake-v1.s3.amazonaws.com/",
    "fields": {
        "key": "ingestion_test_1/data/.metadata/1654775138698_metadata.json",
        "x-amz-algorithm": "AWS4-HMAC-SHA256",
        "x-amz-credential": "ASIARBT2ZRFJONAV6KE4/20220609/ap-southeast-1/s3/aws4_request",
        "x-amz-date": "20220609T114538Z",
        "x-amz-security-token": "FwoGZXIvYXdzEB0aDFFhwfkaD6t7ZJY3IiLIAb+f5mFsmXc5PkCKKKkUzUYt4ZNzpN20XT6yByvLfK8GtJnGUcPk5zj3MShau/J/8y2o9wIyNPrin2+KOXDNJUeAf6Ln74SYLegROVV1pWo+w8fp/Z5DeL6o7uMr4zMz2vq2P6mHt2Woz+BEeCTCo1ixi7IHSxOiiBho2dfu3KaJ6PXZlboLetDD7thD4p/ScbTzmAk3mDPg+/rAzT/WphAwOSudRsuLVsPu/KoaJenhKQFOo5sb7A9LJcduGoA4qJEGOhaEK/siKOK6h5UGMi1s9KMcacMRFNSbfLiQ+TafdVc2JktrVq4dqA/Biw3GsfRQNZj3wevbRWcJcCk=",
        "policy": "eyJleHBpcmF0aW9uIjogIjIwMjItMDYtMDlUMTI6NDU6MzhaIiwgImNvbmRpdGlvbnMiOiBbeyJidWNrZXQiOiAiZGlzY292ZXItdGVzdC1kYXRhbGFrZS12MSJ9LCB7ImtleSI6ICJpbmdlc3Rpb25fdGVzdF8xL2RhdGEvLm1ldGFkYXRhLzE2NTQ3NzUxMzg2OThfbWV0YWRhdGEuanNvbiJ9LCB7IngtYW16LWFsZ29yaXRobSI6ICJBV1M0LUhNQUMtU0hBMjU2In0sIHsieC1hbXotY3JlZGVudGlhbCI6ICJBU0lBUkJUMlpSRkpPTkFWNktFNC8yMDIyMDYwOS9hcC1zb3V0aGVhc3QtMS9zMy9hd3M0X3JlcXVlc3QifSwgeyJ4LWFtei1kYXRlIjogIjIwMjIwNjA5VDExNDUzOFoifSwgeyJ4LWFtei1zZWN1cml0eS10b2tlbiI6ICJGd29HWlhJdllYZHpFQjBhREZGaHdma2FENnQ3WkpZM0lpTElBYitmNW1Gc21YYzVQa0NLS0trVXpVWXQ0Wk56cE4yMFhUNnlCeXZMZks4R3RKbkdVY1BrNXpqM01TaGF1L0ovOHkybzl3SXlOUHJpbjIrS09YRE5KVWVBZjZMbjc0U1lMZWdST1ZWMXBXbyt3OGZwL1o1RGVMNm83dU1yNHpNejJ2cTJQNm1IdDJXb3orQkVlQ1RDbzFpeGk3SUhTeE9paUJobzJkZnUzS2FKNlBYWmxib0xldEREN3RoRDRwL1NjYlR6bUFrM21EUGcrL3JBelQvV3BoQXdPU3VkUnN1TFZzUHUvS29hSmVuaEtRRk9vNXNiN0E5TEpjZHVHb0E0cUpFR09oYUVLL3NpS09LNmg1VUdNaTFzOUtNY2FjTVJGTlNiZkxpUStUYWZkVmMySmt0clZxNGRxQS9CaXczR3NmUlFOWmozd2V2YlJXY0pjQ2s9In1dfQ==",
        "x-amz-signature": "44eb55ded3a662e2af45c5dd10ba59c6aa355ee29640f7cca34f6c7824e2cf65"
            }
        }
    }


# expired url fetching code
# from polly.expired_token import metadata_upload_url
# print("---------metadata upload url------")
# print(metadata_upload_url)
# metadata_upload_details = metadata_upload_url["metadata_upload_url"]

data_upload_url = {
    "data_upload_url": {
        "url": "https://discover-test-datalake-v1.s3.amazonaws.com/",
        "fields": {
            "key": "ingestion_test_1/data/transcriptomics_90/${filename}",
            "x-amz-algorithm": "AWS4-HMAC-SHA256",
            "x-amz-credential": "ASIARBT2ZRFJBR4OVIU5/20220616/ap-southeast-1/s3/aws4_request",
            "x-amz-date": "20220616T050620Z",
            "x-amz-security-token": "FwoGZXIvYXdzEL///////////wEaDBCVczU4CN3WX4G6miLIAclz/cR4ZGHCBwl5sZ+y7MKNtoc/q4OLYtq6QVyuknblyQK1oxvCTEmMkPXcAyEQRa0LRJfvytJmSwFuRhp5FCidbSgj/1nuIMZiIMmNkxoy/wQsRh0gtdMu9BZDIHpVRyw2nP47AhN/vxd8DT57uTgazVEUeBydva6Rs/BNbhWl/lGVCJ/o6lfar9Cmaq+X0R+Lput6pZA9o3lUBohP5MsXUvFt+8/fuCo/u5QRWJysUWYIuzs31ee/9CCiPtcus9odbxj3M1jEKMz0qpUGMi3Mw9UtNPfLV7xAR5E9EByKDRHjRc1XOaGO7Cu+i1zXVtO1D03w+3AtFzzatyo=",
            "policy": "eyJleHBpcmF0aW9uIjogIjIwMjItMDYtMTZUMDY6MDY6MjBaIiwgImNvbmRpdGlvbnMiOiBbeyJidWNrZXQiOiAiZGlzY292ZXItdGVzdC1kYXRhbGFrZS12MSJ9LCBbInN0YXJ0cy13aXRoIiwgIiRrZXkiLCAiaW5nZXN0aW9uX3Rlc3RfMS9kYXRhL3RyYW5zY3JpcHRvbWljc185MC8iXSwgeyJ4LWFtei1hbGdvcml0aG0iOiAiQVdTNC1ITUFDLVNIQTI1NiJ9LCB7IngtYW16LWNyZWRlbnRpYWwiOiAiQVNJQVJCVDJaUkZKQlI0T1ZJVTUvMjAyMjA2MTYvYXAtc291dGhlYXN0LTEvczMvYXdzNF9yZXF1ZXN0In0sIHsieC1hbXotZGF0ZSI6ICIyMDIyMDYxNlQwNTA2MjBaIn0sIHsieC1hbXotc2VjdXJpdHktdG9rZW4iOiAiRndvR1pYSXZZWGR6RUwvLy8vLy8vLy8vL3dFYURCQ1ZjelU0Q04zV1g0RzZtaUxJQWNsei9jUjRaR0hDQndsNXNaK3k3TUtOdG9jL3E0T0xZdHE2UVZ5dWtuYmx5UUsxb3h2Q1RFbU1rUFhjQXlFUVJhMExSSmZ2eXRKbVN3RnVSaHA1RkNpZGJTZ2ovMW51SU1aaUlNbU5reG95L3dRc1JoMGd0ZE11OUJaRElIcFZSeXcyblA0N0FoTi92eGQ4RFQ1N3VUZ2F6VkVVZUJ5ZHZhNlJzL0JOYmhXbC9sR1ZDSi9vNmxmYXI5Q21hcStYMFIrTHB1dDZwWkE5bzNsVUJvaFA1TXNYVXZGdCs4L2Z1Q28vdTVRUldKeXNVV1lJdXpzMzFlZS85Q0NpUHRjdXM5b2RieGozTTFqRUtNejBxcFVHTWkzTXc5VXROUGZMVjd4QVI1RTlFQnlLRFJIalJjMVhPYUdPN0N1K2kxelhWdE8xRDAzdyszQXRGenphdHlvPSJ9XX0=",
            "x-amz-signature": "57e3771549e6d7dab896cd10526ba11971cf9f583c1af760b4d9a9e4c0f6301f"
        }
    }
}


# expired metadata url fetching code
# from polly.expired_token import data_upload_url
# data_upload_details = data_upload_url["data_upload_url"]