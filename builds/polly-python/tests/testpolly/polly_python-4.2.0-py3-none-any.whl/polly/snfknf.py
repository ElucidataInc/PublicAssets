from polly.auth import Polly
from polly.atlas import Atlas

Polly.auth(
    token="ZjY1YzNkZjFjZjo6NzdkYzdiZDMwZGZhMDhkNGRlNGFlZDhkY2Q2N2MxNjQxZTllOWFhYQ==",
    env="testpolly",
)

Atlas.delete_atlas(atlas_id="test_create_atlas")
Atlas.delete_atlas(atlas_id="test_list_atlas")
Atlas.delete_atlas(atlas_id="test_delete_atlas")
