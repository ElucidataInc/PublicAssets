# from polly.atlas import Atlas, Table

# from polly.auth import Polly


# Polly.auth(
#     token="YzExMWY1ZmRhZTo6NTlmZDA2MjcwNmIyMTM5NDY0NDljOTRhMzBlYWQzYjcxOWMwMDE2ZA==",
#     env="devpolly",
# )


# atlas = Atlas(atlas_id="test_all_data_type")

# rows = [{"patient_id": 9, "age": 45}]
# table = atlas.get_table(table_name="patient").add_rows(rows=rows)

# import requests
# import os
# import json

# results_dir = "./query_results"
# os.makedirs(results_dir, exist_ok=True)

# response = requests.get(
#     "https://polly-kg-dev-query-results-v1.s3.amazonaws.com/1/1673936381/3817ff9a-1455-41f5-b103-67349593e8fc.json?AWSAccessKeyId=ASIAQZOJYX3LOVPKKB5A&Signature=gaU49E7L2nN4wNQwmam0tNoWRM0%3D&x-amz-security-token=IQoJb3JpZ2luX2VjELv%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaDmFwLXNvdXRoZWFzdC0xIkcwRQIhANd%2Bo%2F158yy60brQvsJ2RNxczYHT5QQu8GJKald2f3YdAiBG5PS0TQSGSs8C522S%2FyVtd6x7sLfINVV9hz29s5ZF2CqXAwik%2F%2F%2F%2F%2F%2F%2F%2F%2F%2F8BEAMaDDA1NDY0NzExMTM4MiIMB0YGij6Fceph1xj5KusCcqUNxOpdUZ8AzA2fh7O5peu9vfMzk%2B2UN4K4i9qIDo3OfNZUGwMr7rOB2d7NhBKdQSLfMPFAWmFNvmWoYOQ2zHBnwFIdZq%2F62PGwsQXPUH1lrZRvB1mvKAbcHPoIGMCUE5XHJIoal3fmlAx6dkF%2Fn8%2B1qwSlYspnyljgmYSIG5FW%2FUKCcy3WPFibyqTqnah4nYSjL2pxM3Kebm%2FMwZRKUAZWdvq2ICso0EEdMqgNrgHMPoUw%2B7p0UHHisu3ok3a2DkXVpJ8bz5pyBMsstM%2B8XeHl68fTq6W%2FA78Q67FwiTqqmpNBKxGSqdmMEb3xxgrSXNMx8A20ynuNHRGeLVVstraSuL6MQzrnG%2BmjKsY64MJGqQj8assOdIjfw6YQcpdwfKGvUaOVZb5AtoRl9BaYLKVZPZKOsIjRwj4jzmqhUS5aoxC4XyaAI%2Btbd1AXqrjMwiM9ElBpyJul%2FwwMsFr9IWjjuSc7x3LyfVDMMJzez8IGOp0BHFMPt9qDYIpaC6gix9Xs%2F04GGU%2BFfl0DjpUAh3aVtoE%2BKt%2FOCvFeaqwVoTdVxbRV3C%2B4SuqT85gfz9lUdWWZRKYYB%2F%2Fim2VWfpkD4FsV6D56q3yz6MiqXqNo98RUzJeBqfpthpx8hN%2FkSrWQSGJhJcALtcbpfthWv9rrBkgvO%2FuLMyr0X1N8uwai2fEbl9bF3HsgE4vQ6lWOm7CXSQ%3D%3D&Expires=1750334842"
# )
# with open(os.path.join(results_dir, "1.json"), "w") as f:
#     json.dump(response.json(), f, indent=4)

from polly.polly_kg import PollyKG

kg = PollyKG(
    env="devpolly",
    token="YzExMWY1ZmRhZTo6NTlmZDA2MjcwNmIyMTM5NDY0NDljOTRhMzBlYWQzYjcxOWMwMDE2ZA==",
)

kg.run_query(query="MATCH (n) RETURN n LIMIT 10", query_type="CYPHER")
