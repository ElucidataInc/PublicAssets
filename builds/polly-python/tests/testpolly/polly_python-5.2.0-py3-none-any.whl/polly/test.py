from polly.atlas import Atlas
from polly.auth import Polly

Polly.auth(
    token="MGZmYWJiZjY4Mjo6NjUxM2ExZTk5NmYzZWNhZmJlZGNiMGQ2NjBmZWIyYzE4ZDkxOWE4Yg==",
    env="testpolly",
)
print(Atlas.list_atlases())

Atlas.create_atlas(atlas_id="ecommerce_v3", atlas_name="Test Atlas")
