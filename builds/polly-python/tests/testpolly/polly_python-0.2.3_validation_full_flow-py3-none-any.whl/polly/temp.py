
def describe(self, schema_type: str, schema: dict):
        """Print information about the fields in the matrix table.

        Note
        ----
        The `widget` argument is **experimental**.

        Parameters
        ----------
        handler : Callable[[str], None]
            Handler function for returned string.
        widget : bool
            Create an interactive IPython widget.
        """

        def format_type(typ):
            return typ.pretty(indent=4).lstrip()
        
        schema_data = schema['data']['attributes']['schema']

        if schema_type == 'files':
            global_fields = ''.join("\n    '{name}': {type}".format(
                name=key, type=format_type(val)) for key, val in schema_data)
            row_fields = '\n    None'
            col_fields = '\n    None'

        elif schema_type == 'gct_metadata':
            col_fields = ''.join("\n    '{name}': {type}".format(
                name=key, type=format_type(val)) for key, val in schema_data)
            global_fields = '\n    None'
            row_fields = '\n    None'
        
        elif schema_type == 'gct_metadata_row':
            row_fields = ''.join("\n    '{name}': {type}".format(
                name=key, type=format_type(val)) for key, val in schema_data)
            global_fields = '\n    None'
            col_fields = '\n    None'
        



        # if len(self.globals) == 0:
        #     global_fields = '\n    None'
        # else:
        #     global_fields = ''.join("\n    '{name}': {type}".format(
        #         name=f, type=format_type(t)) for f, t in self.globals.dtype.items())

        # if len(self.row) == 0:
        #     row_fields = '\n    None'
        # else:
        #     row_fields = ''.join("\n    '{name}': {type}".format(
        #         name=f, type=format_type(t)) for f, t in self.row.dtype.items())

        # row_key = '[' + ', '.join("'{name}'".format(name=f) for f in self.row_key) + ']' \
        #     if self.row_key else None

        # if len(self.col) == 0:
        #     col_fields = '\n    None'
        # else:
        #     col_fields = ''.join("\n    '{name}': {type}".format(
        #         name=f, type=format_type(t)) for f, t in self.col.dtype.items())

        # col_key = '[' + ', '.join("'{name}'".format(name=f) for f in self.col_key) + ']' \
        #     if self.col_key else None

        # if len(self.entry) == 0:
        #     entry_fields = '\n    None'
        # else:
        #     entry_fields = ''.join("\n    '{name}': {type}".format(
        #         name=f, type=format_type(t)) for f, t in self.entry.dtype.items())

        s = '----------------------------------------\n' \
            'Global fields:{g}\n' \
            '----------------------------------------\n' \
            'Column fields:{c}\n' \
            '----------------------------------------\n' \
            'Row fields:{r}\n' \
            '----------------------------------------\n'.format(g=global_fields,
                                                              r=row_fields,
                                                              c=col_fields)
        print(s)


# def visualize_schema_tabular(self, schema: dict):
    #     """
    #         Makes a tabular format representation of the schema dict
    #     """
    #     printTable(schema)

    
    # def printTable(self, myDict: dict, colList=None, sep='\uFFFA'):
    #     """ 
    #         Pretty print a list of dictionaries (myDict) as a dynamically sized table.
    #         If column names (colList) aren't specified, they will show in random order.
    #         sep: row separator. Ex: sep='\n' on Linux. Default: dummy to not split line.
    #     """
    #     if not colList: colList = list(myDict[0].keys() if myDict else [])
    #     myList = [colList] # 1st row = header
    #     for item in myDict: myList.append([str(item[col] or '') for col in colList])
    #     colSize = [max(map(len,(sep.join(col)).split(sep))) for col in zip(*myList)]
    #     formatStr = ' | '.join(["{{:<{}}}".format(i) for i in colSize])
    #     line = formatStr.replace(' | ','-+-').format(*['-' * i for i in colSize])
    #     item=myList.pop(0); lineDone=False
    #     while myList or any(item):
    #         if all(not i for i in item):
    #             item=myList.pop(0)
    #             if line and (sep!='\uFFFA' or not lineDone): print(line); lineDone=True
    #             row = [i.split(sep,1) for i in item]
    #             print(formatStr.format(*[i[0] for i in row]))
    #             item = [i[1] if len(i)>1 else '' for i in row]

# token = "eyJjdHkiOiJKV1QiLCJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiUlNBLU9BRVAifQ.G8ZXMcoHzj3nI1nglOFm2i1q8n-Zfb9gl5krrHpQG3bSO8BpPSd_P--nZdr3dGrOAB-zMEARd1J8FTBx4GSom3Wb5M6pxSnj3FMZIt3iJyTlC71qKdlGgtWuOPAv0S7UafEGxlKRJ-YiP6bu0Q9d7oLMYkTxfoQjPEV5bHcs4KP9KzZ6O34RMBVz0QQY_6UuXfkAi7MeSRggI2sFuX3JB04ZYajk-aoh5tdzh2iFPpccrYO6KLAhGYVvUCj6Dk5DgGQrO-oR4Qq9MxHLyGX5NCq8GQzpKkd3yEPSq_s2dB6Rv27S5GB9WXax9fsy65Ajh6kaZ52ES0mktvQxOC7CkQ.YcOjxvMlYke5vcjR.r_nyouv2eobL0OxXWziT2V0H6e--clybZsU82CZxxrRPFoTp3XV8kMT69Cjee4RY8IThIqgWXj0W1X8bhZfprTgoRY7hfrKzxgczBeSixH9i6CwhSULiXV6swIPvHqraGCGs-D0lfS6GbuHJ3kHdX_FmSJEzszst5blQy4agTZgE8EYO9QHbCip5i88hBmvL4aUmfRfZ1KwUOtgXbeaigR95oWBqFs7pOYRgzTwdUD18xqQXCuH18AsJo_40sO62joMijKP1oY5DjHt3MHk5Ou-rMfpGolOMno1K5mHsHd3ZTolfbw02t4tedDXCXGml1d9xmDNK3bTo-Wyjp_8fuIzBW5g6IQCvOarstvm0jKELWnERf9QekenmAm6z2K37uKzickG7YpnYvwgVjghn_AhaK6mLzEoNuvAyQlqkm6XhdktV13AgFEa43RjdXZkIaob41dpa_HeqF27xKaMNYI68IGDNuZd_CJzmQmUQdp5-_SIXlNElr6OKKvtd2YC9e3HqsNPexcs-KKrs6HTLNWI955ZA-d5b4gBdcv4u_3oGpapjLlh476b_sVywRaDX-87kkKvkqaFMcK2CrzCI3lQaHJLioFnTT_E647vYcrfDUCXbyGww52HGkD7YPdVSoEXXyZQg-2pkfBc9GryJ814kD60-2gA1XecqQVFG6bBRzbzxG42zjfI4GQcntOUhYG1LY6WYIUVaZKgUqaORzsicG-A_m0cujw0285AsyCNQPkoPyuZzlZxzUqfxsbps5WEvTCTdKVXV9Hi0exnxhOw6TCwqDDtlNx9WyORCNHCDUvh2Sb5fRvPxTLn1MJ5qADbLDS4FVX5g5hC1jbxZfPT-J647LCtkB_wr_S40pGmOoWitBbz0_kEZem_hXJgv2sHYJcYKtllXwJTbsOBZHLmNzgv4GkbX0zRPghFDL23UkyZFWpiEPoEhzYUHzH3n-7xVZM5yGGX87bgPVfDG8foGzcy76zjZPJf1kySMU4PZQSLdAgLzwcSXphkQDGR5GuhTI3GbJig4jXf6pjGqIEUEzDgRK5IlVXhhPrin6Zca-66XDhfPA2KSXj_QVms189oYPIeia27vdzizGEuweXdBeFNssRtAkUZsYnK2ZSpFUfAygi64onNnwTlSjChVStkft5yG5D6FHQdiSTALZ4eT5AThG7YktNPKSOeGtdLAXJU4qTiSCTrOnqtV7XDMsSsDR6EQyDPUzlEEsv5kR2R6ZB8yHbqLQE4PxB5YxEDjhjywcO9VFurFDVoBu2k7hZ12E4K3WvX-Kjy4fPLbSkcY_cM2ZI3XrIG_SIvY4DQMRL0QxVTeXa47f9vLjQc7z_EtiO2or-xz.15oKPoz2WqWKCaBhEY7Umw"

# schema_viz_obj = SchemaVisualization(token)

# resp = schema_viz_obj.get_schema("1622526550765", "gct_metadata")

# print('------resp--------')
# print(resp)