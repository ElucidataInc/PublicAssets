PARAM_EXCEPTION = "parameter passed is either empty or wrong datatype"
PARAM_EXCEPTION_TITLE = "parameter error"

WRONG_PARAMS_EXCEPTION = "Incorrect value of param passed"
WRONG_PARAMS_EXCEPTION_TITLE = "parameter error"

API_ERROR_EXCEPTION_TITLE = "API ERROR"
API_ERROR_EXCEPTION = ""

INCORRECT_DATA = "Data is Incorrect"

BAD_REQUEST_CODE = "bad_req"
BAD_REQUEST_TITLE = "Bad Request"
BAD_REQUEST_DETAIL = "Server could not understand the request due to invalid" " syntax"

UNSUPPORTED_MEDIA_TYPE_CODE = "unsupported_media_type"
UNSUPPORTED_MEDIA_TYPE_TITLE = "Unsupported media type"
UNSUPPORTED_MEDIA_TYPE_DETAIL = (
    "Server accepts "
    "application/vnd.api+json without any media type "
    "parameters as its Content-Type. Please make sure "
    "you are providing the correct Content-type"
)

FORBIDDEN_CODE = "forbidden"
FORBIDDEN_TITLE = "Access denied"
FORBIDDEN_DETAIL = "Access denied for requested resource"

INTERNAL_SERVER_ERROR_CODE = "internal_server_error"
INTERNAL_SERVER_ERROR_TITLE = "Internal Server Error"
INTERNAL_SERVER_ERROR_DETAIL = (
    "Internal Server Error." " Please contact system administrator"
)

METHOD_NOT_ALLOWED_CODE = "method_not_allowed"
METHOD_NOT_ALLOWED_TITLE = "Method not allowed"
METHOD_NOT_ALLOWED_DETAIL = "{} method not allowed for resource - {}"

NOT_FOUND_CODE = "resource_not_found"
NOT_FOUND_TITLE = "Resource not found"
NOT_FOUND_DETAIL = "Requested resource does not exist"

NOT_IMPLEMENTED_CODE = "method_not_implemented"
NOT_IMPLEMENTED_TITLE = "Method not implemented"
NOT_IMPLEMENTED_DETAIL = "{} method not implemented for resource - {}"

PAYLOAD_TOO_LARGE_CODE = "payload_too_large"
PAYLOAD_TOO_LARGE_TITLE = "Payload too large"
PAYLOAD_TOO_LARGE_DETAIL = (
    "the request entity is larger than limits defined" " by server"
)

DATABASE_OPERATION_ERROR_CODE = "database_operation_failed"
DATABASE_OPERATION_ERROR_TITLE = "Database Operation - {} failed for table -" " {}"
DATABASE_OPERATION_ERROR_DETAIL = (
    "Not able to perform database operation on" " selected Resource"
)

INVALID_PAYLOAD_CODE = "invalid_payload"
INVALID_PAYLOAD_TITLE = "Invalid Payload"
INVALID_PAYLOAD_DETAIL = "Parameters passed into the request are" "invalid or missing"

UNPROCESSABLE_ENTITY_CODE = "unprocessable_entity"
UNPROCESSABLE_ENTITY_TITLE = "Unable to process the request"
UNPROCESSABLE_ENTITY_DETAIL = (
    "The request was well-formed but was unable" "to be followed due to semantic errors"
)

CONFLICT_CODE = "conflict"
CONFLICT_TITLE = "Conflict with current state of the server."
CONFLICT_DETAIL = "The request could not be completed due to a conflict with \
    the current state of the resource."


BAD_GATEWAY_CODE = "bad_gateway"
BAD_GATEWAY_TITLE = "Received an invalid response from the upstream service"


GATEWAY_TIMEOUT_CODE = "gateway_timeout"
GATEWAY_TIMEOUT_TITLE = "Gateway Timeout"
GATEWAY_TIMEOUT_DETAIL = "Request timed out"
