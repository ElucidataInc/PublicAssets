class IReporting:
    def __init__(self):
        pass

    def link_report(
        self,
        polly_session,
        repo_key: str,
        dataset_id: str,
        workspace_id: int,
        workspace_path: str,
        access_key: str,
    ):
        pass

    def link_report_url(
        self, polly_session, repo_key: str, dataset_id: str, url_to_be_linked: str
    ):
        pass

    def fetch_linked_reports(self, polly_session, repo_key: str, dataset_id: str):
        pass

    def delete_linked_reports(
        self, polly_session, repo_key: str, dataset_id: str, report_id: str
    ):
        pass
