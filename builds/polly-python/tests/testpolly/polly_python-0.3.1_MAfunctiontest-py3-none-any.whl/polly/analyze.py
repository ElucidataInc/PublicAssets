from polly.auth import Polly
from polly import helpers
from polly import constants as const
from polly.omixatlas import OmixAtlas
from polly.jobs import jobs
from polly.workspaces import Workspaces
from polly.errors import paramException
from polly.tracking import Track
from polly import omixatlas_hlpr
from polly.constants import COHORT_SUPPORTED_DATATYPES, COHORT_SUPPORTED_DATASOURCES

import pandas as pd
import plotly.express as px
import json
import numpy as np


class Analyze:
    """
    The Analyze class contains functions which can be used to identify cohorts in datasets, \
    perform differential expression and pathway analysis, and execute meta-analysis workflows.\
    Args:
        token (str): Authentication token from polly
    Usage:
        from polly.analyze import Analyze

        analysis = Analyze(token)
    """

    def __init__(self, token=None, env="", default_env="polly") -> None:
        # check if COMPUTE_ENV_VARIABLE present or not
        # if COMPUTE_ENV_VARIABLE, give priority
        env = helpers.get_platform_value_from_env(
            const.COMPUTE_ENV_VARIABLE, default_env, env
        )
        self.session = Polly.get_session(token, env=env)
        self.omixatlas_obj = OmixAtlas()
        self.job_obj = jobs()
        self.workspace_obj = Workspaces()
        self.elastic_url = (
            f"https://api.datalake.discover.{self.session.env}.elucidata.io/elastic/v2"
        )

    @Track.track_decorator
    def identify_cohorts(self, repo_key: str, dataset_id: str) -> pd.DataFrame:
        """
        This function is used to get the cohorts that can be created from samples in a GEO dataset.
        Please note: Currently only Bulk RNASeq datasets from GEO source are supported.
        If results are generated for other datatypes or datasource, they may be inaccurate.
        If you want to use this functionality for any other data type and source,
        please reach out to polly.support@elucidata.io
        Args:
            repo_key (int/str): repo_id or repo_name in str or int format
            dataset_id (str): dataset_id of the GEO dataset. eg. "GSE132270_GPL11154_raw"
        Returns:
            Dataframe showing values of samples across factors/cohorts.
        """
        # param checks
        omixatlas_hlpr.parameter_check_for_dataset_id(dataset_id)
        omixatlas_hlpr.parameter_check_for_repo_id(repo_key)
        repo_key = omixatlas_hlpr.make_repo_id_string(repo_key)

        # Get dataset level metadata and check if datatype is supported
        response_omixatlas = self.omixatlas_obj.omixatlas_summary(repo_key)
        data = response_omixatlas.get("data", "")
        index_name = data.get("indexes", {}).get("files", "")
        if index_name is None:
            raise paramException(
                title="Param Error", detail="Repo entered is not an omixatlas."
            )
        elastic_url = f"{self.elastic_url}/{index_name}/_search"
        query = helpers.elastic_query(index_name, dataset_id)
        metadata = helpers.get_metadata(self, elastic_url, query)
        source_info = metadata.get("_source", "")
        if (source_info["data_type"] not in COHORT_SUPPORTED_DATATYPES) or (
            source_info["dataset_source"] not in COHORT_SUPPORTED_DATASOURCES
        ):
            raise paramException(
                title="Param Error",
                detail="Only Bulk RNA Seq datasets that are from GEO are supported",
            )

        # Get sample level metadata
        col_metadata = self.omixatlas_obj.get_metadata(repo_key, dataset_id, "samples")
        # Index should be sample IDs which are available in geo_accession
        col_metadata = col_metadata.set_index("geo_accession")

        # Remove curated columns
        col_metadata = col_metadata.loc[
            :, ~col_metadata.columns.str.contains("curated", case=False)
        ]
        # Remove column with cohorts information if it exists
        col_metadata = col_metadata.drop(
            ["sample_characteristics"], axis=1, errors="ignore"
        )
        # Keeps only columns with more than 1 unique value
        col_metadata = col_metadata.loc[:, col_metadata.nunique() > 1]
        # Remove columns like sample id etc that has all unique values
        col_metadata = col_metadata.loc[:, col_metadata.nunique() != len(col_metadata)]
        # Fix for 'None entries cannot have not-None children' error in sunburst
        col_metadata = col_metadata.fillna("notgiven")

        # Get list of columns to plot in sunburst, in ascending order of nunique() values
        df = col_metadata
        df = pd.DataFrame(df.nunique()).reset_index()
        df = df.sort_values(by=[0])
        lst = df["index"].to_list()
        print("Factors based on which cohorts can be created for this dataset:", lst)

        # Plot sunburst
        fig = px.sunburst(col_metadata, path=lst)
        fig.show()
        return col_metadata[lst]

    def _get_control_perturbation_ids(
        self, col_metadata_df: pd.DataFrame, design_formula: str
    ) -> list:
        """Given a design formula (control or perturbation), return the list of sample_ids
        from the sample level metadata (col_metadata) that are either control or perturbation,
        depending on design formula.

        Args:
            col_metadata_df (pd.DataFrame): The sample level metadata from identify_cohorts
            design_formula (str): design_formula_control or design_formula_perturbation

        Returns:
            list: list of sample_ids that are either control or perturbation
        """
        sample_ids = []
        sample_filters = design_formula.split("+")
        for filter in sample_filters:
            column, values = filter.split(":")
            if "&" in values:
                values = values.split("&")
                sample_filter = col_metadata_df[column].isin(values)
            else:
                sample_filter = col_metadata_df[column] == values
            # Add sublists to list with boolean values for each condition
            sample_ids.append([sample_filter])
        # Logical AND of all bool values in sublist
        sample_ids = np.all(sample_ids, axis=0)
        # Get sample IDs corresponding to logical AND indices
        sample_ids = col_metadata_df[sample_ids.T].sample_id

        return sample_ids

    def _parse_design_formula(
        self, repo_key: str, dataset_id: str, design_formulas: list
    ) -> pd.DataFrame:
        """Creates the cohort df for a dataset that is required for meta analysis.

        Args:
            repo_key (int/str): repo_id or repo_name in str or int format
            dataset_id (str): dataset_id of the GEO dataset. eg. "GSE132270_GPL11154_raw"
            design_formula_control (str): design formula for control samples
            design_formula_perturbation (str): design formula for perturbation samples
            samples_to_remove (list, optional): List of samples to omit, if any. Defaults to [].

        Returns:
            DataFrame: cohort df with three columns ['dataset_id', 'sample_id', 'kw_condition']\
            'kw_condition' has value 'control' or 'perturbation' based on the design formula.
        """
        col_metadata = self.omixatlas_obj.get_metadata(repo_key, dataset_id, "samples")

        # Create design formula dataframe for this dataset ID
        cohort_df = pd.DataFrame(columns=["dataset_id", "sample_id", "kw_condition"])
        cohort_df["sample_id"] = col_metadata["geo_accession"]
        cohort_df["dataset_id"] = dataset_id

        # Extract control and perturbation sample IDs
        control_ids = self._get_control_perturbation_ids(
            col_metadata, design_formulas[0]
        )
        perturbation_ids = self._get_control_perturbation_ids(
            col_metadata, design_formulas[1]
        )

        cohort_df["kw_condition"] = "None"
        cohort_df.loc[
            cohort_df["sample_id"].isin(control_ids), "kw_condition"
        ] = "control"
        cohort_df.loc[
            cohort_df["sample_id"].isin(perturbation_ids), "kw_condition"
        ] = "perturbation"

        return cohort_df

    @Track.track_decorator
    def run_meta_analysis(
        self,
        repo_key: str,
        workspace_id: int,
        analysis_name: str,
        design_formulas: dict,
        samples_to_remove=[],
    ):
        """
        Use this function to execute the Polly DIY Meta-Analysis Pipeline.
        Args:
            repo_key (int/str): repo_id or repo_name in str or int format
            workspace_id (int): the workspace in which the datasets and results should be stored
            analysis_name (str): name of your analysis, eg. "meta-analysis parkinson's first pass".\
            The reports, datasets, and results will be stored in a folder with this name.
            design_formulas (dict): key:value pair of atleast 5 dataset ids and a list of design formulas.\
            eg. dataset_id:[design formula control, design formula perturbation]
            samples_to_remove (list, optional): List of samples to omit, if any. Defaults to [].
        """
        dataset_ids = list(design_formulas.keys())

        # param checks
        omixatlas_hlpr.parameter_check_for_list_dataset_ids(dataset_ids)
        omixatlas_hlpr.parameter_check_for_repo_id(repo_key)
        repo_key = omixatlas_hlpr.make_repo_id_string(repo_key)
        omixatlas_hlpr.str_params_check([workspace_id, analysis_name])

        # parse design formula to get cohort df
        cohort_dfs = []
        for dataset, design_formula in design_formulas.items():
            df = self._parse_design_formula(repo_key, dataset, design_formula)
            cohort_dfs.append(df)
        cohort_df = pd.concat(cohort_dfs)

        # remove samples from above df if any
        cohort_df = cohort_df[~cohort_df["sample_id"].isin(samples_to_remove)]

        # save cohort df as csv to workspace
        cohort_csv_path = analysis_name + "_cohorts.csv"
        cohort_df.to_csv(analysis_name + "_cohorts.csv")
        self.workspace_obj.upload_to_workspaces(
            workspace_id, cohort_csv_path, cohort_csv_path
        )

        # create job.json and submit polly job
        job_dict = {
            "image": "docker.polly.elucidata.io/elucidatarnd/polly-python",
            "tag": "meta_analysis_v1",
            "name": "Polly DIY pipeline: Meta Analysis",
            "machineType": "mi5xlarge",
            "env": {
                "POLLY_WORKSPACE_ID": workspace_id,
                "DATASET_IDS": dataset_ids,
                "SOURCE_OMIXATLAS": repo_key,
                "ANALYSIS_NAME": analysis_name,
                "COHORT_CSV_PATH": cohort_csv_path,
            },
        }

        job_json = json.dumps(job_dict, indent=4)
        job_path = "/import/" + analysis_name + "_job.json"
        with open(job_path, "w") as input:
            input.write(job_json)

        self.job_obj.submit_job(workspace_id, job_path)
        print(
            "Meta-Analysis Job submitted. You may further use job_status() and job_logs()."
        )
