import boto3
import os
import sys
import hmac, hashlib, base64
from jose import jwt
import json
import requests
from cryptography.hazmat.primitives import serialization




def main_fun():
    region="ap-southeast-1"
    user_pool_id = "ap-southeast-1_I7JwKheEV"
    id_token = "eyJraWQiOiJwK2phTWJLV3NsQTJZTzF3cTVINDdtZ25NTGRVY2VseFpCY0prMkQxYVc0PSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI4MGY0MDM4MS1mZjU2LTQzZjAtOTQ2Yy1jNmI5MmI3MGRmNjAiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiY3VzdG9tOm9yZ2FuaXphdGlvbl9uYW1lIjoiZWx1Y2lkYXRhIiwiaXNzIjoiaHR0cHM6XC9cL2NvZ25pdG8taWRwLmFwLXNvdXRoZWFzdC0xLmFtYXpvbmF3cy5jb21cL2FwLXNvdXRoZWFzdC0xX0k3SndLaGVFViIsInBob25lX251bWJlcl92ZXJpZmllZCI6ZmFsc2UsImNvZ25pdG86dXNlcm5hbWUiOiI4MGY0MDM4MS1mZjU2LTQzZjAtOTQ2Yy1jNmI5MmI3MGRmNjAiLCJhdWQiOiIxOWNmMGN0NGdxMHY3bGJsaHV0cGpkdjJ2YiIsImV2ZW50X2lkIjoiMzg2YTA3OWQtOTJlNC00ZWIxLWE4MmMtZmM4OTIwNzkxNDY3IiwidG9rZW5fdXNlIjoiaWQiLCJhdXRoX3RpbWUiOjE2NjQ4ODI5MjYsIm5hbWUiOiJNYXlhbmsiLCJjdXN0b206bGFzdG5hbWUiOiJTYXVyYWJoIiwiZXhwIjoxNjY0ODg2NTI2LCJpYXQiOjE2NjQ4ODI5MjYsImVtYWlsIjoibWF5YW5rLnNhdXJhYmhAZWx1Y2lkYXRhLmlvIn0.KlKRJDwmhHrsTtYFEbNqpy4y6p5Ol6Kptdhpnc-kHyaZq9Bx3wGEaS8qOZAWK3i1VZtaTgNdoTGVPyMuT_1piFSAgHLEaOKKfDkNsL9bxFBut9-rxPVhqp4uPk2bgFXBTVqkiNrkoC4sxN2Jx5-RTVMI-A2B9RsHnVd1rKopBCUurMzhDHIDagVNPSZ4BbbkikNFLUh94dI1okkqKa1ltR-BM7KTAXOmeJGsWKioy1kjSJM7LV0KDdzuXU5P0zs6CDq0C2M9HZLdn4JXsGmBcRnuLfjrrRXAvlGsDLj_v-dU36K5yGgQaNGalvQd0TSlgdQ4XinSjtu2E_TYOmq_qA"

    refresh_token = "eyJjdHkiOiJKV1QiLCJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiUlNBLU9BRVAifQ.dKyd3FKWlzHMXiBET-0zVpofnU4RrTph8qiQd0yn2eUpuWIzHT05_RMx757ZOg3jzzjGOPfL3Hm4SxSl4P7XOV6OPuNNSDKt2WXWm7WfE9chAHbNbLVhauyLJDzE9fq1bB6keqG1nzcHxwzVDCA76bHwYdfBqv0_iCduSvfS3NvjtaaAlW34hZldjOhOLKuayJsu7wSlem5EGVRYzD9Cxen2RRfh5khg6L7HeQRI9NOLXmvJQqfEmwTdfXklmQ0t3ruxAkTHPsD6usaF5WoTmZ47EKDLIdL7GYaaKZW9l6BkxE4bVry32lqXK0crvTSRIcXAlCTlBy0Kt6HAMsvmMQ.Y7xq-6xMguRj7Wjj.CfBCrJvIYFGLFpE9Mv6UbK1uOwOEc-3miaQqT7DJb6KmJWOjX20EBVAsx5UXgUf2Cn2916mohztAFdtRxr_ISy8oqZZ142sJvmchHtGCSWc9BrpigHl9PEsK6EMowDDBLxKxDjnn6VnM7ZzeTvH16bfCKHMeg1GZMuedvDkIIs6XX8z9A24cxRw10oAPRy2npwW2oqJazsG-I33HagmA1hTfeTTrBd9sDzcLIQqF3d55qp8Def-IDB6KdEEFr2e5O4nQ8J5FXc4i0ZA7cKoK5Kel9wJ99uqLmrw4ZsE27CVHMAWK4bNcoqoQpftip8uYQsrbu_eZfGJWh0iApYCkphtuRqKJ7aJQ2GX0dWyVJ3p05HuQO899yFKw1LcSM4CPVqTkQ46UtYQS3tzX7h-aLW-RClOfx7P1X3OzTRuk2OLpgB_SxZvuTpEyvMnkOyLjJzr7hdsqJE9GUWoNq-CcLZIzCSS7tpXql9zGpoWamE-K9N-4pHbgOLodIDfBg-Z7oku2e2JLJ2Z-X_l6Nn_oXqWD4hrSwv8gMUNSQmweseLY5sEVEJahMduBVuLJvvO-CWz8lBNKiUNewcEJpxLjyj3oiJQsfkLvXghANNEGBRQ7JG40VIPq7Zz9srRbTBYrlIb0jM7Ke8UOKY-_lTt_0Pjl2691wqQxL_9IvX576JsFMmuRIxgOEaqx5ExDE3VpCkdePA-aL6lG6k8Yq70nMFFfRtInWi5c5TQXp7GDKqTApMMM11UTq7UbpvobmXdZA4AnptVG9l2Mi9LaFpV3pNlS1XuXG2q--n6C6xeeyCd7vi1A60kFList40hBgzRUE5cHX3HKKfjZq2d_XowW705y09Jpv6DnUSSVqcJBavTNhR5nLWx5Lvv-4OJMeDkHM9eWHw5viLrzRxapSgOJM691m0wvrwHlYxJX2NRLdklg9YJsRtvznEE1bdtGLmACJwl6iwPUhGjcGbSsUnptOAMkT_jVAiDOrh5uR8aXPyIzyPM_PEBZREWicRBtm12GUqOn8Yny6ZR48O1hRX_jfuwcjgl0wRTeyJ85fleWnwMRS3e9kaC1hK1t7jizNLITrnwWAdZXQygxLeHQsTSHM5rLXCBJDV9druSx3yofO68ur7FEwvjjDsnbyC_9SvcxHXWdc7-yZbYsvVmw1LrQoD3AlRbgaIt2B-kFKN-Esvl3UD2Kxtg1__JNLFDNukiol1R064P3BDjZ7xKzkG2HP3J7BxPLck8pLs2fQ7hXaZQ0VupfNelUh7beKxsnw_-drihEWtdFdK_8GG-ZzMQxCQ1IQjK0p-nt-2-m-yYBM6zNT3sX4BwcRWRXB83p6WL0NIt6Fw5DthOF.qDbEKEA1yn8u0Y0C98DMYQ"

        
    print('---------after client_id_is_valid-------')
    ## Getting Headers
    headers = jwt.get_unverified_header(id_token)

    print('---------headers--------')
    print(headers)
    ## Getting Pool Url
    verify_url = ("https://cognito-idp.{}.amazonaws.com/{}".format(
            region, user_pool_id))

    ## Getting Key Identifier
    kid = "p+jaMbKWslA2YO1wq5H47mgnMLdUcelxZBcJk2D1aW4="

    ## Getting JWT token Validation Dictionary
    keys = aws_key_dict(region, user_pool_id)

    ## Making a argumets dictionary
    kargs = {"issuer": verify_url}
    kargs["options"] = {'verify_at_hash': False}
    kargs["audience"] = "19cf0ct4gq0v7lblhutpjdv2vb"

    ## Get Public Key
    public_key = get_public_key(keys, kid)

    print('------------public key----------')
    print(public_key)

    decoded_token = jwt.decode(id_token, public_key, **kargs)
    print(decoded_token)

def get_public_key(keys, kid):
    """
    Getting public key in pem format from Id Token

    Parameters
    ----------
    keys: Dict
        JWT headers keys
    kid: String
        public key identifier

    Returns
    ----------
    pubk_bytes: String (PEM)
        Public key in pem format
    """

    
    key = keys[kid]
    return key



def aws_key_dict(region, user_pool_id):
    """
    Fetches the AWS JWT validation file (if necessary) and then converts
    this file into a keyed dictionary that can be used to validate a web-token
    we've been passed

    Parameters
    ----------
    aws_user_pool: String
        AWS Cognito user pool ID
    aws_region: String
        AWS Cognito user pool region

    Returns:
    -------
    dict:
        Contains decoded token dict
    """
    filename = '/tmp/' + 'aws_{}.json'.format(user_pool_id)

    if not os.path.isfile(filename):
        # If we can't find the file already, try to download it.
        aws_data = requests.get(
            ("https://cognito-idp.{}.amazonaws.com/{}".format(
        region, user_pool_id)) + '/.well-known/jwks.json')
        aws_jwt = json.loads(aws_data.text)
        with open(filename, 'w+') as json_data:
            json_data.write(aws_data.text)
            json_data.close()

    else:
        with open(filename) as json_data:
            aws_jwt = json.load(json_data)
            json_data.close()

    # We want a dictionary keyed by the kid, not a list.
    result = {}
    for item in aws_jwt['keys']:
        result[item['kid']] = item

    return result


main_fun()