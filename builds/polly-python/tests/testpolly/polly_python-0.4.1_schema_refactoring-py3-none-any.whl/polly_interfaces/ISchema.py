class ISchema:
    def __init__(self):
        pass

    def insert_schema(self, polly_session, repo_key, body: dict):
        pass

    def update_schema(self, polly_session, repo_key, body: dict):
        pass

    def replace_schema(self, polly_session, repo_key, body: dict):
        pass

    def validate_schema(self, polly_session, body: dict):
        pass

    def get_schema(
        self,
        polly_session,
        repo_key,
        schema_level=[],
        source="",
        data_type="",
        return_type="dataframe",
    ):
        pass
