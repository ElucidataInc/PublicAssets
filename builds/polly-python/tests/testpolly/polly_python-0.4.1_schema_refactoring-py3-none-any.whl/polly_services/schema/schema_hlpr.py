from polly.errors import paramException
from polly_services import polly_services_hlpr
import json
from polly import constants as const


def schema_param_check(repo_key: str, body: dict):
    """Do sanity checks for the parameters passed in schema functions

    Args:
        repo_key (str): _description_
        body (dict): _description_
    Raises:
        paramError: In case of any issue with the parameter
    """
    try:
        if not body or not isinstance(body, dict):
            raise paramException(
                title="Param Error",
                detail="body should not be empty and it should be of type dict",
            )
        polly_services_hlpr.parameter_check_for_repo_id(repo_key)
    except Exception as err:
        raise err


def schema_update_replace_hlpr(polly_session, repo_key: str, body: dict):
    """Helper function for schema writing.
    => Sanity checks on body
    => prepare url
    => convert body to json

    Args:
        polly_session (_type_): _description_
        repo_key (str): _description_
        body (dict): _description_
    """
    try:
        repo_id = body.get("data").get("attributes").get("repo_id")
        repo_key = polly_services_hlpr.make_repo_id_string(repo_key)
        compare_repo_key_and_repo_id(repo_key, repo_id)

        schema_type = body.get("data", "").get("attributes", "").get("schema_type", "")
        schema_base_url = f"{polly_session.discover_url}/repositories"
        schema_url = f"{schema_base_url}/{repo_key}/schemas/{schema_type}"
        body = json.dumps(body)
        return schema_url, body
    except Exception as err:
        raise err


def schema_write_result_hlpr(resp):
    """Print the appropriate status based on schema write result

    Args:
        resp (json): write response of schema put/patch operation
    """

    schema_update_verdict = (
        resp.get("data", {}).get("attributes", {}).get("schema_update_verdict", "")
    )
    # There are 3 cases for schema updation using patch or put operation
    # In case 1 -> if user changes attributes in the field
    # other than `original_name`, `type`, `is_array`, `is_keyword`
    # `is_searchable`
    # In those cases -> schema update is performed instantly
    # In the schema_update_verdict key -> value is none

    # In case 2 -> If user renames a field or drops a field
    # from the schema -> then schema updation job happens
    # In the schema_update_verdict key -> value is schema_update

    # In case 3 -> if for any field 1 of
    # `is_searchable`
    # `original_name`, `type`, `is_array`, `is_keyword` is changed
    # or a source or datatype is added or renamed or dropped
    # schema reingestion job takes place
    # In the schema_update_verdict key -> value is reingestion

    # SCHEMA_VERDICT_DICT
    # {"schema_update": SCHEMA_UPDATE_SUCCESS, "no_change": SCHEMA_NO_CHANGE_SUCCESS,
    # "reingeston": SCHEMA_REINGEST_SUCCESS}
    # if schema_update_verdict from API matches any of the keys in the dict then
    # its corresponding value will be printed

    schema_update_verdict_val = const.SCHEMA_VERDICT_DICT.get(schema_update_verdict, "")
    if schema_update_verdict_val:
        print(schema_update_verdict_val)
    else:
        print(const.SCHEMA_UPDATE_GENERIC_MSG)


def validate_schema_param_check(body: dict):
    """Do Sanity check for body passed for validate schema

    Args:
        body (dict): payload to be validated
    """

    if "data" not in body:
        raise paramException(
            title="Param Error",
            detail="schema_dict not in correct format, attributes key not present."
            + "Please recheck the schema dict format and values.",
        )

    data = body["data"]
    if "attributes" not in data:
        raise paramException(
            title="Param Error",
            detail="schema_dict not in correct format, attributes key not present."
            + "Please recheck the schema dict format and values.",
        )
    attributes = data["attributes"]
    if "repo_id" not in attributes:
        raise paramException(
            title="Param Error",
            detail="schema_dict not in correct format, repo_id key not present."
            + "Please recheck the schema dict format and values.",
        )

    if "schema" not in attributes:
        raise paramException(
            title="Param Error",
            detail="schema_dict not in correct format, schema key not present."
            + "Please recheck the schema dict format and values.",
        )


def compare_repo_key_and_repo_id(repo_key: str, id: str):
    """Compare repo_key in params and repo_id in the payload
    if repo_key is repo_id => check the equality of repo_key and repo_id
    if repo_key is repo_name => fetch repo_id for the repo and then check equality

    Args:
        repo_key (str): repo_id/repo_name for the repository
        repo_id (str): repo_id in the payload
    """
    repo_id = ""
    if repo_key.isdigit():
        # repo_key is repo_id
        repo_id = repo_key
    else:
        # repo key is repo name
        # fetch the repo id
        repo_data = polly_services_hlpr.get_omixatlas(repo_key)
        repo_id = repo_data["data"]["attributes"]["repo_id"]

    polly_services_hlpr.compare_repo_id_and_id(repo_id, id)
