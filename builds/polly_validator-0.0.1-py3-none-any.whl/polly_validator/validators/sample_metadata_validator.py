import traceback as tb

import pandas as pd
from pydantic import ValidationError
from tabulate import tabulate

from polly_validator.settings import POLLY_ENV_LIST
from polly_validator.utility.helper import build_field_name_to_original_name_mapping, get_schema_from_api, \
    modify_metadata_as_per_mapping, print_exception, schema_correction
from polly_validator.validators.schema_constructors.sample_level import build_schema_for_repo


def check_metadata_for_errors(repo, schema_df, metadata_list, env, auth_token, validate_on='value', file_type=None,
                              print_table=False):
    """
    Utility to return errors for a list of sample level metadata dicts
    Args:
        repo: name of repo
        schema_df: schema df of the repo
        metadata_list: list of dicts containing the sample level metadata to be checked
        env:
        auth_token:
        validate_on: level of checks to do, level='schema', 'value'
        file_type: file type to disambiguate which schema to fetch
        print_table: flag to print the results as a table on cli or not

    Returns:
        error_df :  errors as an error df
        status: Status for if the given metadata passed all checks or not as a dict
    """
    errors_all, status_all = [pd.DataFrame(columns=['Field', 'Error Message', 'Error Type', 'Repo',
                                                    'src_dataset_id', 'data_id', 'sample_id'])], {}
    try:
        # Parameter checks:
        if not repo:
            raise Exception('Repo name not entered or is an empty string.')
        if schema_df is None or schema_df.empty:
            raise Exception('Schema Dataframe name not entered/empty dataframe passed')
        if metadata_list is None or len(metadata_list) == 0:
            raise Exception('Metadata list is None or is an empty list.')
        if env == '' or env is None or env not in POLLY_ENV_LIST:
            raise Exception(f'Invalid value passed for "env" argument: {env}')
        if auth_token is None or auth_token == '':
            raise Exception(f'Authentication token/key is None or empty string.')

        # schema df format check
        if sorted(schema_df.columns) != ['column_name', 'column_type']:
            raise Exception(f'Invalid format for Schema DF passed: {schema_df.columns}'
                            f'\nShould be of the format ["column_name", "column_type"')
        metadata_list = modify_metadata_as_per_mapping(metadata_list, repo, 'sample', env, auth_token, file_type)
        if metadata_list is None:
            raise Exception('Error modifying metadata as per mapping from schema.')
        for index, metadata in enumerate(metadata_list):
            errors, status = validate_sample_metadata(repo, schema_df, metadata, validate_on)
            if errors.empty and status is False:
                if 'sample_id' in metadata:
                    print(f'Error validating metadata: {metadata["sample_id"]}')
                else:
                    print((f'Error validating metadata, index: {index}'))
            errors_all.append(errors)
            if 'sample_id' in metadata:
                status_all[metadata['sample_id']] = status
            else:
                status_all[index] = status
        error_df = pd.concat(errors_all, ignore_index=True)
        # Step 1
        schema_dict = get_schema_from_api(repo, 'sample', env, auth_token, file_type)
        if schema_dict is None:
            raise Exception('Error getting schema from API')
        # Step 2
        field_name_mapping = build_field_name_to_original_name_mapping(schema_dict)
        if field_name_mapping is None:
            raise Exception('Error creating field name to original name mapping')
        error_df['Original Name'] = error_df['Field'].apply(lambda row: field_name_mapping[row])
        if print_table:
            # 'print_table' is True: returns formatted table for the command line
            print(tabulate(error_df, headers="keys", tablefmt="fancy_grid"))
        return error_df, status_all
    except Exception:
        print(tb.format_exc())
        print_exception()
        return pd.DataFrame(), {}


def validate_sample_metadata(repo, schema_df, metadata, level='value'):
    """
    Validation per item of sample metadata
    Args:
        repo:
        schema_df:
        metadata:
        level:

    Returns:
        collected_errors: errors collected for the single sample metadata
        status: boolean status for if the sample passed the checks with no errors or not.
    """
    schema_errors = pd.DataFrame(columns=['Field', 'Error Message', 'Error Type', 'Repo',
                                     'src_dataset_id', 'data_id', 'sample_id'])
    value_errors = pd.DataFrame(columns=['Field', 'Error Message', 'Error Type', 'Repo',
                                              'src_dataset_id', 'data_id', 'sample_id'])
    collected_errors = pd.DataFrame(columns=['Field', 'Error Message', 'Error Type', 'Repo',
                                             'src_dataset_id', 'data_id', 'sample_id'])
    try:
        schema, schema_with_validators = build_schema_for_repo(schema_df)
        if not schema or not schema_with_validators:
            raise Exception(f'Error building pydantic classes. {tb.format_exc()}')
        if level == 'schema':
            try:
                schema(**metadata)
            except ValidationError as s_errors:
                schema_errors = pd.DataFrame(s_errors.errors())
                # Rename columns to our desired names
            if not schema_errors.empty:
                schema_errors.rename(columns={'loc': 'Field',
                                         'msg': 'Error Message',
                                         'type': 'Error Type'}, inplace=True)
                schema_errors['Repo'] = repo
                if 'src_dataset_id' in metadata:
                    if isinstance(metadata['src_dataset_id'], list):
                        schema_errors['src_dataset_id'] = metadata['src_dataset_id'][0]
                    else:
                        schema_errors['src_dataset_id'] = metadata['src_dataset_id']
                else:
                    schema_errors['src_dataset_id'] = 'NA'
                schema_errors['data_id'] = metadata['data_id']
                if 'sample_id' in metadata:
                    if isinstance(metadata['sample_id'], list):
                        schema_errors['sample_id'] = metadata['sample_id'][0]
                    else:
                        schema_errors['sample_id'] = metadata['sample_id']
                else:
                    schema_errors['sample_id'] = 'NA'
                schema_errors['Field'] = schema_errors['Field'].apply(lambda row: row[0])
                if 'ctx' in schema_errors.columns:
                    schema_errors.drop(['ctx'], axis=1, inplace=True)
                schema_errors.drop_duplicates(inplace=True)
                return schema_errors, False
            else:
                return collected_errors, True
        elif level == 'value':
            """Step 1. Check only for schema"""
            try:
                schema(**metadata)
            except ValidationError as s_errors:
                schema_errors = pd.DataFrame(s_errors.errors())
                # Rename columns to our desired names
                schema_errors.rename(columns={'loc': 'Field',
                                         'msg': 'Error Message',
                                         'type': 'Error Type'}, inplace=True)
                errors_to_correct = s_errors.errors()
                # Perform intermediate in-memory corrections
                if errors_to_correct:
                    metadata = schema_correction(metadata, errors_to_correct)

            """Step 2. Check for value checks with corrected schema"""
            try:
                schema_with_validators(**metadata)
            except ValidationError as v_errors:
                value_errors = pd.DataFrame(v_errors.errors())
                # Rename columns to our desired names
                value_errors.rename(columns={'loc': 'Field',
                                                  'msg': 'Error Message',
                                                  'type': 'Error Type'}, inplace=True)
            # If some errors are found in any of the two checks. Concatenate them together.
            collected_errors = pd.concat([schema_errors, value_errors], ignore_index=True)
            if 'ctx' in collected_errors.columns:
                collected_errors.drop(['ctx'], axis=1, inplace=True)
            collected_errors.drop_duplicates(inplace=True)
            collected_errors['Repo'] = repo
            if 'src_dataset_id' in metadata:
                if isinstance(metadata['src_dataset_id'], list):
                    collected_errors['src_dataset_id'] = metadata['src_dataset_id'][0]
                else:
                    collected_errors['src_dataset_id'] = metadata['src_dataset_id']
            else:
                collected_errors['src_dataset_id'] = 'NA'
            if 'data_id' in metadata:
                collected_errors['data_id'] = metadata['data_id']
            else:
                collected_errors['data_id'] = 'NA'
            if 'sample_id' in metadata:
                if isinstance(metadata['sample_id'], list):
                    collected_errors['sample_id'] = metadata['sample_id'][0]
                else:
                    collected_errors['sample_id'] = metadata['sample_id']
            else:
                collected_errors['sample_id'] = 'NA'
            collected_errors['Field'] = collected_errors['Field'].apply(lambda row: row[0])
            if not collected_errors.empty:
                return collected_errors, False
            else:
                return collected_errors, True
        else:
            raise Exception(f'Invalid value for argument "level": {level} ')
    except Exception as e:
        print(tb.format_exc())
        print_exception()
        return pd.DataFrame(), False
