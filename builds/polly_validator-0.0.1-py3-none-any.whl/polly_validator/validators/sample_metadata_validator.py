import traceback as tb

import pandas as pd
from pydantic import ValidationError
from tabulate import tabulate

from polly_validator.utility.helper import build_field_name_to_original_name_mapping, get_schema_from_api, \
    modify_metadata_as_per_mapping, print_exception, schema_correction
from polly_validator.validators.schema_constructors.sample_level import build_schema_for_repo


def check_metadata_for_errors(repo, schema_df, metadata_list, env, auth_token, validate_on='value', print_table=False):
    """
    Utility to return errors for a list of sample level metadata dicts
    Args:
        repo: name of repo
        schema_df: schema df of the repo
        metadata_list: list of dicts containing the sample level metadata to be checked
        env:
        auth_token:
        validate_on: level of checks to do, level='schema', 'value'
        print_table: flag to print the results as a table on cli or not

    Returns:
        error_df :  errors as an error df
        status: Status for if the given metadata passed all checks or not as a dict
    """
    errors_all, status_all = [pd.DataFrame(columns=['Field', 'Error Message', 'Error Type', 'Repo',
                                                    'src_dataset_id', 'data_id', 'sample_id'])], {}
    metadata_list = modify_metadata_as_per_mapping(metadata_list, repo, 'sample', env, auth_token)
    for index, metadata in enumerate(metadata_list):
        errors, status = validate_sample_metadata(repo, schema_df, metadata, validate_on)
        errors_all.append(errors)
        if 'sample_id' in metadata:
            status_all[metadata['sample_id']] = status
        else:
            status_all[index] = status
    error_df = pd.concat(errors_all, ignore_index=True)
    # Step 1
    schema_dict = get_schema_from_api(repo, 'sample', env, auth_token)
    # Step 2
    field_name_mapping = build_field_name_to_original_name_mapping(schema_dict)
    error_df['Original Name'] = error_df['Field'].apply(lambda row: field_name_mapping[row])
    if print_table:
        # 'print_table' is True: returns formatted table for the command line
        print(tabulate(error_df, headers="keys", tablefmt="fancy_grid"))
    return error_df, status_all


def validate_sample_metadata(repo, schema_df, metadata, level='value'):
    """
    Validation per item of sample metadata
    Args:
        repo:
        schema_df:
        metadata:
        level:

    Returns:
        collected_errors: errors collected for the single sample metadata
        status: boolean status for if the sample passed the checks with no errors or not.
    """
    error_df = pd.DataFrame(columns=['Field', 'Error Message', 'Error Type', 'Repo',
                                     'src_dataset_id', 'data_id', 'sample_id'])
    additional_errors = pd.DataFrame(columns=['Field', 'Error Message', 'Error Type', 'Repo',
                                              'src_dataset_id', 'data_id', 'sample_id'])
    collected_errors = pd.DataFrame(columns=['Field', 'Error Message', 'Error Type', 'Repo',
                                             'src_dataset_id', 'data_id', 'sample_id'])
    try:
        schema, schema_with_validators = build_schema_for_repo(schema_df)
        if not schema or not schema_with_validators:
            raise Exception(f'Error building pydantic classes. {tb.format_exc()}')
        if level == 'schema':
            try:
                schema(**metadata)
            except ValidationError as schema_errors:
                error_df = pd.DataFrame(schema_errors.errors())
                # Rename columns to our desired names
            if not error_df.empty:
                error_df.rename(columns={'loc': 'Field',
                                         'msg': 'Error Message',
                                         'type': 'Error Type'}, inplace=True)
                error_df['Repo'] = repo
                if 'src_dataset_id' in metadata:
                    if isinstance(metadata['src_dataset_id'], list):
                        error_df['src_dataset_id'] = metadata['src_dataset_id'][0]
                    else:
                        error_df['src_dataset_id'] = metadata['src_dataset_id']
                else:
                    error_df['src_dataset_id'] = 'NA'
                error_df['data_id'] = metadata['data_id']
                if 'sample_id' in metadata:
                    if isinstance(metadata['sample_id'], list):
                        error_df['sample_id'] = metadata['sample_id'][0]
                    else:
                        error_df['sample_id'] = metadata['sample_id']
                else:
                    error_df['sample_id'] = 'NA'
                error_df['Field'] = error_df['Field'].apply(lambda row: row[0])
                error_df.drop_duplicates(inplace=True)
                return error_df, False
        elif level == 'value':
            """Step 1. Check only for schema"""
            try:
                schema(**metadata)
            except ValidationError as schema_errors:
                error_df = pd.DataFrame(schema_errors.errors())
                # Rename columns to our desired names
                error_df.rename(columns={'loc': 'Field',
                                         'msg': 'Error Message',
                                         'type': 'Error Type'}, inplace=True)
                errors_to_correct = schema_errors.errors()
                # Perform intermediate in-memory corrections
                if errors_to_correct:
                    metadata = schema_correction(metadata, errors_to_correct)

            """Step 2. Check for value checks with corrected schema"""
            try:
                schema_with_validators(**metadata)
            except ValidationError as value_errors:
                additional_errors = pd.DataFrame(value_errors.errors())
                # Rename columns to our desired names
                additional_errors.rename(columns={'loc': 'Field',
                                                  'msg': 'Error Message',
                                                  'type': 'Error Type'}, inplace=True)
            # If some errors are found in any of the two checks. Concatenate them together.
            collected_errors = pd.concat([error_df, additional_errors], ignore_index=True)
            collected_errors.drop_duplicates(inplace=True)
            collected_errors['Repo'] = repo
            if 'src_dataset_id' in metadata:
                if isinstance(metadata['src_dataset_id'], list):
                    collected_errors['src_dataset_id'] = metadata['src_dataset_id'][0]
                else:
                    collected_errors['src_dataset_id'] = metadata['src_dataset_id']
            else:
                collected_errors['src_dataset_id'] = 'NA'
            if 'data_id' in metadata:
                collected_errors['data_id'] = metadata['data_id']
            else:
                collected_errors['data_id'] = 'NA'
            if 'sample_id' in metadata:
                if isinstance(metadata['sample_id'], list):
                    collected_errors['sample_id'] = metadata['sample_id'][0]
                else:
                    collected_errors['sample_id'] = metadata['sample_id']
            else:
                collected_errors['sample_id'] = 'NA'
            collected_errors['Field'] = collected_errors['Field'].apply(lambda row: row[0])
            return collected_errors, False
        else:
            raise Exception(f'Invalid value for argument "level": {level} ')
    except Exception as e:
        print(tb.format_exc())
        print_exception()
        return pd.DataFrame(), False
    return collected_errors, True
