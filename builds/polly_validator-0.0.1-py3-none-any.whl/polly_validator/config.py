CONFIG = {
    "run_dataset_level_validations": True,
    "run_sample_level_validations": True,
    "repos_for_dataset_level_validation": [
        "pcd",
        "teddy",
        "lincs",
        "geo_raw_counts"
    ],
    "repos_for_sample_level_validation": [
        "pcd",
        "teddy",
        "lincs",
        "geo_raw_counts"
    ],

    "last_commit_for_obo_ontology_files": "39312b6",
    "last_commit_for_compressed_ontology_files": "feff3be",
    "env": ["polly", "devpolly", "testpolly"],

    "dataset_errors_table_name": "DatasetLevelErrors",
    "sample_errors_table_name": "SampleLevelErrors",
    "job_details": {
        "image": "docker.polly.elucidata.io/elucidatarnd/qa_repo",
        "tag": "",
        "machineType": "ci2xlarge",
        "env": {
            "PROJECT_DIR": "polly_validator",
            "DB_NAME": "150_samples_batch_1.db"
        },
        "name": "QA Validation Error Collection"
    }
}
