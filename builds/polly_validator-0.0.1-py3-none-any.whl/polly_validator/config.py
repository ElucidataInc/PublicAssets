CONFIG = {
    "run_dataset_level_validations": True,
    "run_sample_level_validations": False,
    "repos_for_dataset_level_validation": [
        "sc_data_lake",
    ],
    "repos_for_sample_level_validation": [
        "sc_data_lake",
    ],

    "last_commit_for_obo_ontology_files": "39312b6",
    "last_commit_for_compressed_ontology_files": "feff3be",
    "env": ["polly", "devpolly", "testpolly"],

    "dataset_errors_table_name": "DatasetLevelErrors",
    "sample_errors_table_name": "SampleLevelErrors",
    "job_details": {
        "image": "docker.polly.elucidata.io/elucidatarnd/qa_repo",
        "tag": "repo_wise_run",
        "machineType": "mi5xlarge",
        "env": {
            "PROJECT_DIR": "polly_validator",
            "DB_NAME": "repo_wise_sc_data_lake.db"
        },
        "name": "QA Validation Error Collection"
    }
}