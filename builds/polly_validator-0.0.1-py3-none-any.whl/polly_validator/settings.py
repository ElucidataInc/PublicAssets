import base64
import json
import pathlib
import sys
import traceback as tb

import requests as rq
from appdirs import user_config_dir

from polly_validator.config import CONFIG

ROOT_DIR = pathlib.Path(__file__).parent

# Repos to carry out validation for
REPOS_FOR_DATASET_LEVEL_VALIDATION = CONFIG.get('repos_for_dataset_level_validation')
REPOS_FOR_SAMPLE_LEVEL_VALIDATION = CONFIG.get('repos_for_sample_level_validation')

# DB Name
DB_NAME = CONFIG.get('job_details').get('env').get('DB_NAME')

# Declare table names
DATASET_ERRORS_TABLE = CONFIG.get('dataset_errors_table_name', 'Dataset_Errors')
SAMPLE_ERRORS_TABLE = CONFIG.get('sample_errors_table_name', 'Sample_Errors')

# Flags for which validation to run
RUN_DATASET_LEVEL_VALIDATIONS = CONFIG.get('run_dataset_level_validations', True)
RUN_SAMPLE_LEVEL_VALIDATIONS = CONFIG.get('run_sample_level_validations', True)

# Field mapping for referring to when using valid_names.json
FIELD_MAPPING = {'tissue': 'tissue',
                 'curated_tissue': 'tissue',

                 'kw_cell_type': 'cell_type',
                 'curated_cell_type': 'cell_type',

                 'kw_cell_line': 'cell_line',
                 'curated_cell_line': 'cell_line',

                 'disease': 'disease',
                 'curated_disease': 'disease',

                 'kw_drug': 'drug',
                 'curated_drug': 'drug',

                 'organism': 'organism',
                 'curated_organism': 'organism',

                 'kw_data_type': 'data_type',
                 'data_type': 'data_type',
                 }

with open(pathlib.Path(user_config_dir()) / 'polly-validator' / 'valid_names.json', 'r') as fp:
    VALID_NAMES = json.load(fp)

print('Getting predefined values for Data Type and Data Source...')

"""Getting Data Type and Data Source values from a separate repo on GitHub"""
try:
    response_data_types = rq.get(f'https://raw.githubusercontent.com/ElucidataInc/PublicAssets'
                                 f'/master/ipc_library/accepted_data_types.txt')
    if response_data_types.status_code != 200:
        raise Exception("Unable to retrieve data type file from GitHub.")
    VALID_NAMES["data_type"] = base64.b64decode(response_data_types.content).decode('ascii').split('\n')

    response_data_sources = rq.get(f'https://raw.githubusercontent.com/ElucidataInc/PublicAssets/'
                                   f'master/ipc_library/accepted_data_sources.txt')
    if response_data_sources.status_code != 200:
        raise Exception("Unable to retrieve data source file from GitHub.")
    VALID_NAMES['dataset_source'] = base64.b64decode(response_data_sources.content).decode('ascii').split('\n')
except Exception as e:
    print(tb.format_exc())
    exception_type, exception_object, exception_traceback = sys.exc_info()
    filename = exception_traceback.tb_frame.f_code.co_filename
    line_number = exception_traceback.tb_lineno
    print("Exception type: ", exception_type)
    print("File name: ", filename)
    print("Line number: ", line_number)
