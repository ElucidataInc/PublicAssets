import json
import os
import pathlib

ROOT = pathlib.Path(__file__).parent.parent
from polly_validator.settings import CONFIG, ROOT_DIR


def create_job_json():
    """
    Construct a job.json file whilst taking credentials from the ~/.aws/credentials file and AUTH_TOKEN for polly-py
    Returns:

    """
    with open(os.path.expanduser('~/.aws/credentials'), 'r') as fp:
        creds_list = [line.strip() for line in fp]
    job_json = CONFIG['job_details']
    cred_labels = ['aws_access_key_id', 'aws_secret_access_key', 'aws_session_token']
    creds = {label.upper(): c[len(label) + 1:] for label in cred_labels for c in creds_list if c.startswith(label)}
    if 'AUTH_TOKEN' in os.environ:
        creds['AUTH_TOKEN'] = os.environ['AUTH_TOKEN']
    job_json['secret_env'] = creds

    with open(ROOT_DIR / 'validators' / 'job.json', 'w') as fp:
        json.dump(job_json, fp, indent=4)


if __name__ == '__main__':
    create_job_json()
